// Local candidate compilation only. No change to ordinary index/config.
import {resolve,dirname} from 'node:path';import {fileURLToPath} from 'node:url';
import {sourceURLPlugin} from './tools/source-url-plugin.mjs';
const project=dirname(fileURLToPath(import.meta.url)),dist=resolve(project,'dist'),source=resolve(dist,'native_world_selected_s9_boss_source_r3/source');
export default {root:source,base:'/wtstgj/',publicDir:resolve(project,'public-resources'),plugins:[sourceURLPlugin({dist})],define:{'import.meta.env.GEOJE_BETA05_LOCAL':'true'},server:{host:'127.0.0.1',fs:{strict:true,allow:[project]}},build:{outDir:resolve(project,'build-beta05-interior-dev'),emptyOutDir:true,assetsInlineLimit:0,rollupOptions:{input:resolve(source,'beta05-start.html')}}};
