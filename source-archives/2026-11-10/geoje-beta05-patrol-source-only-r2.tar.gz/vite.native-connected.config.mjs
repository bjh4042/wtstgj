import config from './vite.beta05-interior-dev.config.mjs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const project=dirname(fileURLToPath(import.meta.url));
export default {...config,build:{...config.build,outDir:resolve(project,'build-native-houses-r3-final'),emptyOutDir:false,copyPublicDir:false,rollupOptions:{...config.build.rollupOptions,input:['beta05-four-badge-candidate.html','native-restoration.html','native-connected-game.html'].map(name=>resolve(config.root,name))}}};
