import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {parseHTML} from 'linkedom';
import {ORDINARY_PLAY_HELP,appendOrdinaryPlayHelp} from '../dist/native_world_selected_s9_boss_source_r3/source/ui/ordinary-play-help.mjs';

const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const section=title=>ORDINARY_PLAY_HELP.find(([heading])=>heading===title)?.[1];

test('help separates browser saves, manual backup downloads and importing',()=>{
 assert.deepEqual(ORDINARY_PLAY_HELP.map(([title])=>title),[
  '걷기와 달리기','대결과 포획','친구 키우기','회복과 보관함','도구 사용','저장과 다시 시작',
  'PC 백업 파일 만들기','PC 백업으로 이어하기'
 ]);
 const local=section('저장과 다시 시작'),download=section('PC 백업 파일 만들기'),restore=section('PC 백업으로 이어하기');
 assert.match(local,/메뉴 → 저장/);
 assert.match(local,/이 브라우저·주소/);
 assert.match(local,/다른 기기·브라우저·주소로 자동 공유되지 않아요/);
 assert.match(local,/저장 다시 시도/);
 assert.match(local,/사이트 데이터를 지우거나 비공개 창을 닫으면 기록이 사라질 수 있어요/);
 assert.match(download,/버튼이 있는 0\.5 개발 후보/);
 assert.match(download,/대결·연출·저장이 끝난 뒤/);
 assert.match(download,/다운로드 완료와 파일 위치를 직접 확인/);
 assert.match(download,/자동저장해도 이미 받은 백업 파일은 갱신되지 않아요/);
 assert.match(restore,/가져오기 기능이 있는 후보/);
 assert.match(restore,/타이틀 → 옵션 → PC 백업 가져오기 \(\.stm\)/);
 assert.match(restore,/빈 저장 공간이 필요/);
 assert.match(restore,/기존 모험과 원본 파일은 덮어쓰지 않아요/);
 assert.match(restore,/자동으로 합쳐지지 않아요/);
 assert.match(restore,/진행 지역을 지원하지 않는 후보에서는 열 수 없으니/);
 assert.match(restore,/기존 후보의 기록과 원본 백업을 보관/);
});

test('new instructions use actual live labels and do not claim a backup action exists everywhere',async()=>{
 const [entry,title,file,policy]=await Promise.all([
  'world/entry.mjs','ui/beta05-title-menu.mjs','beta05-interior-dev/file-save.mjs','world/beta05-four-badge-profile.mjs'
 ].map(path=>readFile(new URL(path,source),'utf8')));
 assert.match(entry,/appendOrdinaryPlayHelp\(root\.querySelector\('\.world-play'\)\)/);
 assert.match(entry,/if\(pcFileSave\)\{const b=document\.createElement\('button'\);b\.textContent='PC 파일 내보내기 \(\.stm\)'/);
 assert.match(entry,/note\.append\(b\);root\.querySelector\('aside'\)\.prepend\(note\)/);
 assert.match(title,/settingsButton=make\('button','옵션'\)/);
 assert.match(title,/make\('button','PC 백업 가져오기 \(\.stm\)'\)/);
 assert.match(title,/importButton\.onclick=importPanel/);
 assert.match(file,/FILE_EXTENSION='\.stm'/);
 assert.match(policy,/원본 기록은 그대로 남으며 서로 자동으로 합쳐지지 않아요/);
});

test('render retains the shell help hook, readable sections and static-only controls',()=>{
 const {document}=parseHTML('<html><body><section class="world-play"></section></body></html>');
 const parent=document.querySelector('.world-play'),node=appendOrdinaryPlayHelp(parent);
 assert.equal(parent.querySelector(':scope > small[data-ordinary-play-help]'),node);
 assert.equal(node.getAttribute('aria-label'),'처음 여행하는 탐험가를 위한 게임 안내');
 assert.equal(node.style.fontSize,'16px');
 assert.equal(node.style.overflowWrap,'anywhere');
 assert.equal(node.children.length,8);
 for(const [index,child] of [...node.children].entries()){
  assert.equal(child.querySelector('strong').textContent,ORDINARY_PLAY_HELP[index][0]);
  assert.equal(child.lastElementChild.textContent,ORDINARY_PLAY_HELP[index][1]);
 }
 assert.equal(node.querySelector('button,input,select,a,script,iframe'),null);
});

test('opening the help has no storage, file, game state or frozen-copy side effects',()=>{
 const {document,window}=parseHTML('<html><body><section></section></body></html>');
 let calls=0;
 Object.defineProperty(window,'localStorage',{get(){calls++;throw Error('guidance must not read saves')}});
 Object.defineProperty(window,'sessionStorage',{get(){calls++;throw Error('guidance must not read saves')}});
 const before=JSON.stringify(ORDINARY_PLAY_HELP),parent=document.querySelector('section');
 const first=appendOrdinaryPlayHelp(parent);first.remove();
 const second=appendOrdinaryPlayHelp(parent);
 assert.equal(calls,0);
 assert.equal(parent.children.length,1);
 assert.equal(second.textContent,ORDINARY_PLAY_HELP.flat().join(''));
 assert.equal(JSON.stringify(ORDINARY_PLAY_HELP),before);
 assert.equal(Object.isFrozen(ORDINARY_PLAY_HELP),true);
 assert.equal(ORDINARY_PLAY_HELP.every(Object.isFrozen),true);
});
