import test from 'node:test';import assert from 'node:assert/strict';import{parseHTML}from'linkedom';
const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const{mountBeta05Opening}=await import(new URL('ui/beta05-opening-player.mjs',root));
const{createFilmAudio}=await import(new URL('film/film-audio.mjs',root));
function fixture(){const{document}=parseHTML('<html><body><section></section></body></html>');let visible='visible',time=0,n=0,done=0;Object.defineProperty(document,'visibilityState',{get:()=>visible});const timers=new Map,media=[];
 const clock={setTimeout(fn,delay){const id=++n;timers.set(id,{at:time+delay,fn});return id},clearTimeout(id){timers.delete(id)}};
 const player=mountBeta05Opening({host:document.querySelector('section'),clock,now:()=>time,onDone:()=>done++,audioFactory:opts=>createFilmAudio({...opts,audioFactory:src=>{const listeners={};const m={src,plays:0,pauses:0,currentTime:0,addEventListener(k,fn){listeners[k]=fn},removeEventListener(k){delete listeners[k]},play(){this.plays++;return Promise.resolve()},pause(){this.pauses++},removeAttribute(){},load(){},emit(k){listeners[k]?.()},callback(k){return listeners[k]}};media.push(m);return m}})});
 const click=text=>{const b=[...document.querySelectorAll('button')].find(n=>n.textContent===text);assert(b,text);b.click()};
 function tick(ms){const end=time+ms;let limit=100;while(timers.size){const[id,job]=[...timers].sort((a,b)=>a[1].at-b[1].at)[0];if(job.at>end)break;assert(limit-->0);time=job.at;timers.delete(id);job.fn()}time=end}
 return{player,document,media,timers,click,tick,get done(){return done},visibility(v){visible=v;document.dispatchEvent(new document.defaultView.Event('visibilitychange'))}};
}
const flush=()=>Promise.resolve();
test('music starts from gesture, original six shots finish at 28.4s, final title waits for real ended at 42.08s',async()=>{
 const f=fixture();try{f.player.play();f.click('오프닝 음악 재생');await flush();f.tick(28400);assert.equal(f.player.state.index,5);assert.equal(f.player.state.waitingForMusic,true);assert.equal(f.done,0);assert.equal(f.timers.size,0);const shot=f.document.querySelector('.geoje-opening-shot');f.tick(13680);assert.equal(f.document.querySelector('.geoje-opening-shot'),shot);f.media[0].emit('ended');assert.equal(f.done,1);assert.equal(f.player.state.active,false);f.media[0].emit('ended');assert.equal(f.done,1)}finally{f.player.dispose()}
});
test('silent opening retains exact 28.4s and early track completion never extends it',async()=>{
 const f=fixture();f.player.play();f.tick(28400);assert.equal(f.done,1);assert.equal(f.media.length,0);f.player.dispose();
 const g=fixture();g.player.play();g.click('오프닝 음악 재생');await flush();g.tick(1000);g.media[0].emit('ended');g.tick(27400);assert.equal(g.done,1);g.player.dispose();
});
test('late music start waits for actual completion rather than guessed wall-clock duration',async()=>{
 const f=fixture();try{f.player.play();f.tick(20000);f.click('오프닝 음악 재생');await flush();f.tick(8400);assert.equal(f.done,0);assert(f.player.state.waitingForMusic);f.tick(33680);assert.equal(f.done,0);f.media[0].emit('ended');assert.equal(f.done,1)}finally{f.player.dispose()}
});
test('skip or title menu always exits immediately and replay ignores retired track completion',async()=>{
 const f=fixture();try{f.player.play();f.click('오프닝 음악 재생');await flush();const stale=f.media[0].callback('ended');f.tick(28400);f.click('시작 메뉴로');assert.equal(f.done,1);f.player.play();stale();assert.equal(f.done,1);assert.equal(f.player.state.musicFinished,false);f.click('건너뛰기');assert.equal(f.done,2)}finally{f.player.dispose()}
});
test('pause and hidden-tab handling preserve title; end while hidden defers navigation until visible',async()=>{
 const f=fixture();try{f.player.play();f.click('오프닝 음악 재생');await flush();f.tick(28400);f.click('일시정지');const pauses=f.media[0].pauses;assert(pauses>0);f.tick(100000);assert.equal(f.done,0);f.click('계속 보기');await flush();assert(f.media[0].plays>1);f.visibility('hidden');f.media[0].emit('ended');assert.equal(f.done,0);f.visibility('visible');assert.equal(f.done,1)}finally{f.player.dispose()}
});
test('media failure releases waiting title instead of trapping user',async()=>{
 const f=fixture();try{f.player.play();f.click('오프닝 음악 재생');await flush();f.tick(28400);assert(f.player.state.waitingForMusic);f.media[0].emit('error');assert.equal(f.done,1)}finally{f.player.dispose()}
});
