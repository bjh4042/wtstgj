import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs/promises';import {createHash}from'node:crypto';import{parseHTML}from'linkedom';
const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const {mountBeta05Opening}=await import(new URL('ui/beta05-opening-player.mjs',root));
const {createFilmAudio,FILM_AUDIO_SLOTS}=await import(new URL('film/film-audio.mjs',root));
const {OPENING_MUSIC_SLOTS,OPENING_MUSIC_SHA256}=await import(new URL('ui/beta05-opening-music.mjs',root));
function fixture({reject=false,pending=false}={}){
 const {document}=parseHTML('<html><body><section></section></body></html>');let visibility='visible';Object.defineProperty(document,'visibilityState',{get:()=>visibility});let done=0,resolve;const media=[];
 const clock={setTimeout:()=>1,clearTimeout(){}};
 const player=mountBeta05Opening({host:document.querySelector('section'),clock,onDone:()=>done++,audioFactory:opts=>createFilmAudio({...opts,audioFactory:src=>{const a={src,currentTime:0,plays:0,pauses:0,addEventListener(){},removeEventListener(){},removeAttribute(){},load(){},pause(){this.pauses++},play(){this.plays++;return reject?Promise.reject(Object.assign(Error('blocked'),{name:'NotAllowedError'})):pending?new Promise(r=>resolve=r):Promise.resolve()}};media.push(a);return a}})});
 const click=text=>{const b=[...document.querySelectorAll('button')].find(n=>n.textContent===text);assert(b,text);b.click()};
 return{player,media,document,click,get done(){return done},resolve:()=>resolve?.(),hide(){visibility='hidden';document.dispatchEvent(new document.defaultView.Event('visibilitychange'))},show(){visibility='visible';document.dispatchEvent(new document.defaultView.Event('visibilitychange'))}};
}
test('approved Drive WAV bytes are unchanged and only the opening slot changes',async()=>{
 const bytes=await fs.readFile(new URL('assets/music/opening-blue-island-42s.wav',root));assert.equal(createHash('sha256').update(bytes).digest('hex'),OPENING_MUSIC_SHA256);assert.equal(bytes.length,8093178);assert.equal(OPENING_MUSIC_SLOTS.intro.loop,false);assert(FILM_AUDIO_SLOTS.intro.src.endsWith('ost-19.mp3'));assert(FILM_AUDIO_SLOTS.main.src.endsWith('ost-20.mp3'));
});
test('actual film-audio engine receives new slot, starts only on gesture and stops at skip',async()=>{
 const f=fixture();try{f.player.play();assert.equal(f.media.length,0);f.click('오프닝 음악 재생');await Promise.resolve();assert.equal(f.media.length,1);assert.equal(f.media[0].src,OPENING_MUSIC_SLOTS.intro.src);assert.equal(f.media[0].loop,false);assert.equal(f.media[0].volume,.25);f.click('건너뛰기');assert.equal(f.done,1);assert(f.media[0].pauses>0)}finally{f.player.dispose()}
});
test('pause, hidden tab, replay and disposal use existing safe audio lifecycle',async()=>{
 const f=fixture();f.player.play();f.click('오프닝 음악 재생');await Promise.resolve();f.click('일시정지');assert(f.media[0].pauses>0);f.click('계속 보기');await Promise.resolve();assert.equal(f.media[0].plays,2);f.hide();const paused=f.media[0].pauses;assert(paused>1);f.show();await Promise.resolve();assert.equal(f.media[0].plays,3);f.player.play();assert(f.media[0].pauses>paused);assert.equal(f.media.length,1);f.player.dispose();
});
test('autoplay denial leaves opening usable and pending play cannot survive skip',async()=>{
 const blocked=fixture({reject:true});try{blocked.player.play();blocked.click('오프닝 음악 재생');await Promise.resolve();await Promise.resolve();assert(blocked.document.querySelector('[role=status]').textContent.includes('재생하지 못'));blocked.click('건너뛰기');assert.equal(blocked.done,1)}finally{blocked.player.dispose()}
 const pending=fixture({pending:true});try{pending.player.play();pending.click('오프닝 음악 재생');pending.click('건너뛰기');pending.resolve();await Promise.resolve();assert.equal(pending.done,1);assert(pending.media[0].pauses>0)}finally{pending.player.dispose()}
});
