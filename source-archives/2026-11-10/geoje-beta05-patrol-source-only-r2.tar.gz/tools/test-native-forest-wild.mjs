import test from 'node:test';
import assert from 'node:assert/strict';
import { fixture, memory, deps, load, fs, source, BINDINGS, hash, stable } from './forest-test-fixture.mjs';
const {FOREST,FOREST_GRASS,FOREST_GRASS_ENTRANCE,forestSafe,forestGrassAt}=await load('native-connected/forest-plan.mjs');
const {createCanonicalCreature}=await load('canonical-session.mjs');
const {ENCOUNTER_PROFILES,FREQUENCY_POLICY}=await load('encounter/frequency.mjs');
const {nativeSlotKey,SESSION_REVISION}=await load('native-connected/session.mjs');
const {resetForestEncounterWalk,advanceForestEncounterWalk}=await load('native-connected/forest-encounter-walk.mjs');
const forward='area-entry:P_ECO_CENTER_EDGE';
async function enter(a){a.exterior.arrival(BINDINGS[forward].foot);await a.world.interact(forward);a.sync();assert.equal(a.exterior.kind,'forest')}
async function ready({rng=()=>.99,battleDriver=()=>assert.fail('Unexpected battle'),storage=memory(),level=20,hp=null,hooks={}}={}){
 let a=await fixture();const runtime=a.world.snapshot();runtime.party=[createCanonicalCreature(a.world.catalog,'SPECIES_001',level)];if(hp!==null)runtime.party[0].hp=hp;runtime.inventory.ecology_ball=10;a.dispose();
 a=await fixture({initialRuntime:runtime,storage,worldOptions:{...deps.worldOptions,rng,battleDriver,hooks}});await enter(a);return a;
}
async function grassStep(a,direction='right'){for(let i=0;i<4;i++)await a.moveExterior(direction)}

test('new grass candidate and open south entrance connect; fences and unplaced edge stay blocked',async()=>{
 const a=await ready();try{a.exterior.arrival([700,223]);for(let i=0;i<5;i++)await a.moveExterior('up');assert.deepEqual(a.exterior.player,[700,163]);assert(forestGrassAt(a.exterior.player));assert(forestSafe([700,130]));assert(!forestSafe([610,100]));assert(!forestSafe([800,130]));assert(!forestGrassAt([700,205]));assert.equal(FOREST.randomEncounters,'EXISTING_CANONICAL_TABLE_CONNECTED');assert.deepEqual(FOREST_GRASS,[620,102,780,190]);assert.deepEqual(FOREST_GRASS_ENTRANCE,[640,184,760,224]);}finally{a.dispose()}
});

test('native step cadence is actual 48-pixel grass travel, not key repeat, turns, path or collision',async()=>{
 let rolls=0;const a=await ready({rng:()=>{rolls++;return .99}});
 try{const start=a.world.snapshot().encounter.eligibleSteps;a.exterior.arrival([650,150]);for(let i=0;i<3;i++)await a.moveExterior('right');assert.equal(rolls,0);assert.equal(a.world.snapshot().encounter.eligibleSteps,start);await a.moveExterior('right');assert.equal(rolls,1);assert.equal(a.world.snapshot().encounter.eligibleSteps,start+1);
  const canonical=a.world.snapshot().position;assert.equal(canonical.scene,FOREST.mapId);assert.notEqual(canonical.x,a.exterior.player[0]);
  a.exterior.arrival([779,150]);await a.save();a.sync();await a.moveExterior('right');assert.equal(rolls,1,'blocked boundary consumes no roll');
  a.exterior.arrival([650,223]);for(let i=0;i<8;i++)await a.moveExterior('right');assert.equal(rolls,1,'path consumes no roll');
  const before=a.world.snapshot().encounter;for(let i=0;i<30;i++)a.exterior.tick();assert.deepEqual(a.world.snapshot().encounter,before);
 }finally{a.dispose()}
});

test('existing chance, four weighted species slots and level ranges are untouched and used',async()=>{
 const a=await ready();try{const t=a.world.catalog.encounterContract.tables['P_ECO_CENTER_EDGE:land_grass'];assert.equal(t.profile,'NORMAL');assert.equal(ENCOUNTER_PROFILES.NORMAL,.09);assert.deepEqual(t.slots.map(s=>[s.speciesId,s.weight,s.level]),[['SPECIES_010',30,[2,4]],['SPECIES_012',25,[2,4]],['SPECIES_015',25,[3,5]],['SPECIES_020',20,[2,4]]]);assert.deepEqual(FREQUENCY_POLICY,{safeStepsAfterEncounter:5,dryStart:10,dryInterval:4,dryIncrement:.02,dryCap:.08});}finally{a.dispose()}
 for(const [slotRoll,id]of [[0,'SPECIES_010'],[.31,'SPECIES_012'],[.56,'SPECIES_015'],[.81,'SPECIES_020']]){
  const values=[0,slotRoll,.5];let seen;
  const a=await ready({rng:()=>values.shift()??.5,battleDriver:b=>{seen=b.snapshot().opponents[0];b.act({type:'flee'})}});
  try{a.exterior.arrival([650,150]);await grassStep(a);assert.equal(seen.speciesId,id);}finally{a.dispose()}
 }
});

test('normal wild capture consumes a ball, records the creature and returns to the same native foot',async()=>{
 let battles=0,outcome;const a=await ready({rng:()=>0,battleDriver:b=>{battles++;for(let i=0;i<10&&b.snapshot().phase!=='ended';i++)b.act({type:'capture',ballId:'ecology_ball'});outcome=b.snapshot().outcome}});
 try{a.exterior.arrival([650,150]);const before=a.world.snapshot(),canonical=before.position;await grassStep(a);const after=a.world.snapshot();assert.equal(outcome,'captured');assert.equal(battles,1);assert.equal(after.party.length,before.party.length+1);assert(after.inventory.ecology_ball<before.inventory.ecology_ball);assert.deepEqual(a.exterior.player,[698,150]);assert.deepEqual(after.position,canonical);assert.equal(after.encounter.safeStepsRemaining,5);assert.equal(after.economy.tutorial.completed,false,'normal battle does not complete designated tutorial');assert.equal(a.world.inputLocked,false);}finally{a.dispose()}
});

test('escape and victory preserve native pose; existing five safe steps suppress repeated encounters',async()=>{
 let battles=0,rolls=0;const a=await ready({rng:()=>{rolls++;return 0},battleDriver:b=>{battles++;b.act({type:'flee'})}});
 try{a.exterior.arrival([650,150]);await grassStep(a);const rollsAfter=rolls;for(let i=0;i<5;i++)await grassStep(a,i%2?'right':'left');assert.equal(battles,1);assert.equal(rolls,rollsAfter);assert.equal(a.world.snapshot().encounter.safeStepsRemaining,0);await grassStep(a,'right');assert.equal(battles,2);assert.deepEqual(a.exterior.player,[698,150]);}finally{a.dispose()}
 let outcome;const v=await ready({rng:()=>0,level:100,battleDriver:b=>{for(let i=0;i<150&&b.snapshot().phase!=='ended';i++){const s=b.snapshot(),move=s.party[s.active].moves.find(x=>x.pp>0);b.act({type:'move',moveId:move?.id??'SYSTEM_STRUGGLE'})}outcome=b.snapshot().outcome}});
 try{v.exterior.arrival([650,150]);await grassStep(v);assert.equal(outcome,'won');assert.deepEqual(v.exterior.player,[698,150]);assert.equal(v.exterior.kind,'forest')}finally{v.dispose()}
});

test('defeat follows existing verified recovery instead of restoring the grass position',async()=>{
 let outcome;const a=await ready({level:1,hp:1,rng:()=>0,battleDriver:b=>{for(let i=0;i<150&&b.snapshot().phase!=='ended';i++){const s=b.snapshot(),move=s.party[s.active].moves.find(x=>x.pp>0);b.act({type:'move',moveId:move?.id??'SYSTEM_STRUGGLE'})}outcome=b.snapshot().outcome}});
 try{a.exterior.arrival([650,150]);await grassStep(a);assert.equal(outcome,'lost');assert.equal(a.world.snapshot().economy.recovery.status,'RETURNED_VERIFIED_HOST');assert.notEqual(a.world.snapshot().position.scene,FOREST.mapId);assert(a.world.snapshot().party.every(m=>m.hp>0));assert.equal(a.world.inputLocked,false);assert(a.scene||a.exterior)}finally{a.dispose()}
});

test('one world lock blocks repeat movement and save while a wild battle is unresolved',async()=>{
 let release,started;const begin=new Promise(r=>started=r);const a=await ready({rng:()=>0,battleDriver:async b=>{started();await new Promise(r=>release=r);b.act({type:'flee'})}});
 try{a.exterior.arrival([650,150]);for(let i=0;i<3;i++)await a.moveExterior('right');const moving=a.moveExterior('right');await begin;assert.equal(a.world.inputLocked,true);await assert.rejects(a.moveExterior('right'),/UNAVAILABLE/);await assert.rejects(a.save(),/in progress|BUSY/i);release();await moving;assert.equal(a.world.inputLocked,false);assert.deepEqual(a.exterior.player,[698,150]);}finally{release?.();a.dispose()}
});

test('save/resume retains partial grass-step distance and leaves prior candidates untouched',async()=>{
 const storage=memory(),old='geoje.dev.interior-pilot.unified-native-r1.v1.SLOT_1';storage.setItem(old,'ORIGINAL_UNCHANGED');let rolls=0;const rng=()=>{rolls++;return .99};let a=await ready({storage,rng});
 try{a.exterior.arrival([650,150]);await a.moveExterior('right');await a.moveExterior('right');await a.save();const pose=a.exterior.capture(),raw=storage.getItem(deps.key);assert.equal(pose.encounterWalk.distance,24);a.dispose();a=await fixture({storage,worldOptions:{...deps.worldOptions,rng}});assert.deepEqual(a.exterior.capture(),pose);await a.moveExterior('right');assert.equal(rolls,0);await a.moveExterior('right');assert.equal(rolls,1);assert.equal(storage.getItem(old),'ORIGINAL_UNCHANGED');assert.equal(JSON.parse(raw).data.nativeCandidateRevision,SESSION_REVISION);
  const e=JSON.parse(raw);e.data.native.encounterWalk.distance=49;e.sha256=hash(stable(e.data));const bad=JSON.stringify(e);a.dispose();storage.setItem(deps.key,bad);await assert.rejects(fixture({storage}),/FOREST_ENCOUNTER_WALK_STATE/);assert.equal(storage.getItem(deps.key),bad);
 }finally{a.dispose()}
});

test('all-fainted party guard and leaving grass do not consume probability or safe-step counters',async()=>{
 let rolls=0;const a=await ready({hp:0,rng:()=>{rolls++;return 0}});
 try{a.exterior.arrival([650,150]);await grassStep(a);assert.equal(rolls,0);assert.equal(a.world.snapshot().encounter.eligibleSteps,0);a.exterior.arrival([700,185]);await a.moveExterior('down');assert.equal(a.exterior.capture().encounterWalk.distance,0);assert.equal(a.world.snapshot().encounter.method,null)}finally{a.dispose()}
});

test('failed aftermath write is retried from the existing pending commit without reroll or duplicate capture',async()=>{
 const backing=memory();let fail=false,battles=0,rolls=0;
 const storage={...backing,setItem(k,v){const e=JSON.parse(v);if(fail&&e.data.canonical.encounter.safeStepsRemaining===5){fail=false;throw Error('TEST_AFTER_BATTLE_WRITE_FAILURE')}backing.setItem(k,v)}};
 const a=await ready({storage,rng:()=>{rolls++;return 0},battleDriver:b=>{battles++;b.act({type:'capture',ballId:'ecology_ball'})}});
 try{a.exterior.arrival([650,150]);for(let i=0;i<3;i++)await a.moveExterior('right');const before=a.world.snapshot();fail=true;await assert.rejects(a.moveExterior('right'),/TEST_AFTER_BATTLE_WRITE_FAILURE/);assert(a.world.story.pendingCommit);assert(a.world.inputLocked);const afterRolls=rolls;await a.world.story.retryCommit();a.world.syncField();a.sync();assert.equal(battles,1);assert.equal(rolls,afterRolls);assert.equal(a.world.snapshot().party.length,before.party.length+1);assert.equal(a.world.snapshot().inventory.ecology_ball,before.inventory.ecology_ball-1);assert.deepEqual(a.exterior.player,[698,150]);assert.equal(a.world.story.pendingCommit,false)}finally{a.dispose()}
});
