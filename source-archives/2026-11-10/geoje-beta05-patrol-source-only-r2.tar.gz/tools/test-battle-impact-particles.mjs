import {test} from 'node:test';
import assert from 'node:assert/strict';
import {moveImpactParticles,drawMoveImpactParticles} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-impact-particles.mjs';
import {MOVE_ANIMATION_PROFILES as profiles} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation-profiles.mjs';
import {moveAnimationFrame,buildMoveAnimationPayloads,drawMoveAnimation} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation.mjs';
import {moveAnimationFrame as originalFrame,buildMoveAnimationPayloads as originalPayloads} from '../../reference/dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation.mjs';
const layout={width:432,height:240,player:{x:100,y:220,size:100},enemy:{x:330,y:130,size:100}};
function cue(id,side='player',outcome='hit'){
 const event={type:'move',moveId:id,side,instanceId:'a',targetId:'b',hit:outcome!=='miss'};
 const events=outcome==='immune'?[{type:'immune'}]:[{type:'damage',targetId:'b',actualDamage:outcome==='zero'?0:20}];
 assert.deepEqual(buildMoveAnimationPayloads(event,events),originalPayloads(event,events));
 return buildMoveAnimationPayloads(event,events)[0];
}
test('118 profiles retain all battle presentation frame values, cues, timing and recoil exactly',()=>{
 assert.equal(Object.keys(profiles).length,118);
 for(const id of Object.keys(profiles))for(const side of ['player','opponent'])for(const outcome of ['hit','miss','immune','zero']){
  const c=cue(id,side,outcome),before=JSON.stringify(c);
  for(const reducedMotion of [false,true])for(const t of [0,.14,.3,.61,.62,.7,.9,1,1.2]){
   const active={...c,reducedMotion},f=moveAnimationFrame(active,c.duration*t,layout);
   assert.deepEqual(f,originalFrame(active,c.duration*t,layout));
   const particles=moveImpactParticles(active,f);
   if(outcome!=='hit'||reducedMotion||f.done||f.phase!=='contact'||c.profile.target==='self')assert.equal(particles.length,0);
   assert.deepEqual(particles,moveImpactParticles(active,f));
   for(const p of particles){for(const k of ['x','y','size','angle','alpha'])assert.ok(Number.isFinite(p[k]));assert.ok(p.alpha>=0&&p.alpha<=1);assert.ok(Math.abs(p.x-f.to.x)<90);assert.ok(Math.abs(p.y-f.to.y)<90)}
  }
  assert.equal(JSON.stringify(c),before);
 }
});
test('authored motif families have distinct original contact shapes and settle without flashes',()=>{
 const shapes=new Set();
 for(const id of Object.keys(profiles)){
  const c=cue(id);if(c.profile.target==='self')continue;
  let previous=Infinity;
  for(const t of [0,.1,.3,.6,.9,.999,1]){
   const f=moveAnimationFrame(c,c.duration*(c.profile.contact+(1-c.profile.contact)*t),layout),particles=moveImpactParticles(c,f);
   for(const p of particles)shapes.add(p.shape);
   if(particles.length){assert.ok(particles[0].alpha<=previous);previous=particles[0].alpha}
  }
 }
 assert.ok(shapes.size>=9,`Only ${shapes.size} visual families`);
});
test('renderer draws new contact silhouettes with finite coordinates and balanced canvas state',()=>{
 let depth=0,operations=0;
 const ctx=new Proxy({save(){depth++},restore(){assert.ok(depth>0);depth--}},{get(o,k){return k in o?o[k]:(...args)=>{operations++;for(const x of args)if(typeof x==='number')assert.ok(Number.isFinite(x))}}});
 for(const id of Object.keys(profiles))for(const side of ['player','opponent']){
  const c=cue(id,side),elapsed=c.duration*.8,f=moveAnimationFrame(c,elapsed,layout);
  assert.deepEqual(drawMoveAnimation(ctx,c,elapsed,layout),f);assert.equal(depth,0);
 }
 assert.ok(operations>1000);
});
test('invalid geometry and absent inputs are safe no-ops',()=>{
 assert.deepEqual(moveImpactParticles(),[]);
 const c=cue('MV010'),f=moveAnimationFrame(c,c.duration*.8,layout);
 assert.deepEqual(moveImpactParticles(c,{...f,to:{x:NaN,y:0}}),[]);
});
