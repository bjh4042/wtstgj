import {deps,load} from './forest-test-fixture.mjs';
const {cellPosition}=await load('world/definition.mjs');
async function runtimeFixture(){
 const seed=new deps.World({adapter:deps.adapter});
 try{
  for(const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER'])await seed.story.runEvent(id);
  const r=seed.snapshot(),c=seed.story.contract,p=r.progress;
  p.completedStages=['PROLOGUE'];
  const events=new Set(p.completedEvents),trainers=new Set();
  function addEvent(id){if(events.has(id))return;events.add(id);for(const prerequisite of c.events[id].requiresEvents)addEvent(prerequisite);if(c.events[id].trainerId)trainers.add(c.events[id].trainerId)}
  for(const stage of p.completedStages){for(const id of c.stages[stage].eventIds)addEvent(id);for(const id of c.stages[stage].requiredTrainerIds)trainers.add(id)}
  for(const id of trainers)if(c.trainers[id].eventId)addEvent(c.trainers[id].eventId);
  p.completedEvents=[...events];p.defeatedTrainers=[...trainers];
  p.flags=Object.fromEntries(Object.values(c.flags).map(f=>[f.id,f.set_by.some(id=>events.has(c.aliases[id]??id))]));
  p.gymClears=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.id);p.badges=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.badgeId);
  p.rewardClaims=Object.values(c.rewards).filter(r=>events.has(r.triggerEvent)).map(r=>r.id);p.currentStage='S1';
  r.position=cellPosition('world:hub:S4',22,11,'up');r.world.mapId=r.position.scene;r.world.visitedMaps.push(r.position.scene);return r;
 }finally{seed.dispose()}
}




export async function s1ReadyRuntime(){const r=await runtimeFixture();r.position=cellPosition('world:hub:PROLOGUE',2,12,'right');r.world.mapId=r.position.scene;return r;}
