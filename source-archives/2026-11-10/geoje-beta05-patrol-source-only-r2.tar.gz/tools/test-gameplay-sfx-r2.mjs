import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {ORIGINAL_SFX, ROLE_SOURCE} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-manifest.mjs';
import {createOriginalSfxRouting} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-routing.mjs';
import {createOriginalSfxTransport} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-transport.mjs';
import {createSharedBattleSequences} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/shared-battle-sequences.mjs';
const source = new URL('../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx/', import.meta.url);
const publicSource = new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx/', import.meta.url);
const provenance = JSON.parse(fs.readFileSync(new URL('gameplay-sfx-r2-provenance.json', source), 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const cue = (kind, event) => ({channel: 'original-sfx-cue', cue: {kind, event}});
function router() {
  const played = [];
  const transport = {oneShot(id) { played.push(id); return true; }, reset() {}, dispose() {}};
  return {played, routing: createOriginalSfxRouting(transport)};
}
function step(overrides = {}) {
  return {moved: true, from: {scene: 'field', x: 24, y: 24}, to: {scene: 'field', x: 72, y: 24}, map: {grid: 48}, tileAt: () => ({tallGrass: true}), ...overrides};
}

test('five authored PCM files have safe levels, silent boundaries, provenance, and packaged paths', () => {
  assert.equal(provenance.assets.length, 5);
  const hashes = new Set();
  for (const asset of provenance.assets) {
    assert.equal(ROLE_SOURCE[asset.role], asset.role);
    assert.equal(ORIGINAL_SFX[asset.role].loop, false);
    const bytes = fs.readFileSync(new URL(asset.file, source));
    assert.equal(hash(bytes), asset.sha256);
    hashes.add(hash(bytes));
    assert.equal(ORIGINAL_SFX[asset.role].url, new URL(asset.file, source).href);
    assert.deepEqual(fs.readFileSync(new URL(asset.file, publicSource)), bytes);
    assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');
    assert.equal(bytes.readUInt32LE(4) + 8, bytes.length);
    assert.equal(bytes.toString('ascii', 8, 12), 'WAVE');
    assert.equal(bytes.toString('ascii', 12, 16), 'fmt ');
    assert.equal(bytes.readUInt16LE(20), 1, 'PCM');
    assert.equal(bytes.readUInt16LE(22), 1, 'mono');
    assert.equal(bytes.readUInt32LE(24), 48000);
    assert.equal(bytes.readUInt16LE(34), 16);
    assert.equal(bytes.toString('ascii', 36, 40), 'data');
    assert.equal(bytes.readUInt32LE(40), bytes.length - 44);
    const frames = (bytes.length - 44) / 2;
    assert.equal(frames / 48000, asset.seconds);
    assert.equal(bytes.readInt16LE(44), 0);
    assert.equal(bytes.readInt16LE(bytes.length - 2), 0);
    let peak = 0, squares = 0;
    for (let i = 44; i < bytes.length; i += 2) {
      const value = bytes.readInt16LE(i) / 32768;
      peak = Math.max(peak, Math.abs(value)); squares += value * value;
    }
    const rms = Math.sqrt(squares / frames);
    assert(peak < 0.63 && peak > 0.1, asset.role + ' peak');
    assert(rms > 0.05 && rms < 0.12, asset.role + ' RMS');
  }
  assert.equal(hashes.size, 5, 'separate original signals, not renamed duplicates');
});

test('grass is audible only after an eligible completed tile step', () => {
  const {routing, played} = router();
  assert.equal(routing.step(step()), true);
  for (const patch of [{moved: false}, {battleActive: true}, {visible: false}, {tileAt: () => null}, {map: {grid: 0}}, {to: {scene: 'field', x: 24, y: 24}}, {to: {scene: 'field', x: 120, y: 24}}, {to: {scene: 'field', x: NaN, y: 24}}]) {
    assert.equal(routing.step(step(patch)), false);
  }
  assert.deepEqual(played, ['UIFIELD_14_STEP_GRASS']);
});

test('water, normal steps and door transitions preserve their existing roles', () => {
  const {routing, played} = router();
  routing.step(step({tileAt: () => ({water: true})}));
  routing.step(step({tileAt: () => ({})}));
  routing.step(step({to: {scene: 'interior', x: 24, y: 24}, tileAt: () => {throw Error('not needed for a warp');}}));
  assert.deepEqual(played, ['UIFIELD_15_STEP_WATER_SAND', 'UIFIELD_13_STEP_NORMAL', 'UIFIELD_12_DOOR']);
});

test('recovery center gets its own completion sound, without replacing battle healing', () => {
  const {routing, played} = router();
  routing.fieldResult({kind: 'heal'}, {type: 'heal'});
  routing.fieldResult({kind: 'heal'});
  assert.equal(routing.fieldResult({kind: 'heal'}, {type: 'report'}), false);
  routing.hook({channel: 'original-sfx-cue', cue: {kind: 'move-result', event: {type: 'heal'}, resultChange: {kind: 'heal', verified: true, actualAmount: 10}}});
  assert.deepEqual(played, ['UIFIELD_20_RECOVERY', 'UIFIELD_20_RECOVERY', 'MOVE_21_HEAL']);
});

test('successful sale uses money sound while purchase keeps item sound', () => {
  const {routing, played} = router();
  routing.fieldResult({kind: 'shop'}, {type: 'sell', itemId: 'potion', quantity: 1});
  routing.fieldResult({kind: 'shop'}, {itemId: 'potion', quantity: 1});
  assert.deepEqual(played, ['UIFIELD_11_MONEY', 'UIFIELD_09_ITEM']);
});

test('learned moves and pending move choices have different feedback', () => {
  const {routing, played} = router();
  routing.hook(cue('move-learning', {type: 'learned-move', moveId: 'leaf'}));
  routing.hook(cue('move-learning', {type: 'move-choice', moveId: 'leaf'}));
  assert.equal(routing.hook(cue('move-learning', {type: 'learned-move', moveId: ''})), false);
  assert.equal(routing.hook(cue('move-learning', {type: 'unknown', moveId: 'leaf'})), false);
  assert.deepEqual(played, ['BATTLE_14_MOVE_LEARNED', 'UIFIELD_07_NOTIFY']);
});

test('status recovery and residual damage require the matching resolved event', () => {
  const {routing, played} = router();
  for (const status of ['sleep', 'freeze']) routing.hook(cue('status-cured', {type: 'status-cured', status}));
  for (const status of ['poison', 'bad_poison', 'burn']) routing.hook(cue('residual', {type: 'residual', status, amount: 4}));
  for (const event of [{type: 'residual', status: 'poison', amount: 0}, {type: 'residual', status: 'burn', amount: -1}, {type: 'residual', status: 'poison', amount: 0.5}, {type: 'residual', status: 'sleep', amount: 2}, {type: 'status', status: 'burn', amount: 2}]) assert.equal(routing.hook(cue('residual', event)), false);
  assert.equal(routing.hook(cue('status-cured', {type: 'status', status: 'sleep'})), false);
  assert.equal(routing.hook(cue('status-cured', {type: 'status-cured', status: 'unknown'})), false);
  assert.deepEqual(played, ['BATTLE_13_STATUS_CURED', 'BATTLE_13_STATUS_CURED', ...Array(3).fill('BATTLE_15_RESIDUAL_DAMAGE')]);
});

test('only a confirmed positive practice-ball refill gets a neutral notice', () => {
  const {routing, played} = router();
  routing.hook(cue('tutorial-refill', {type: 'tutorial-refill', quantity: 1}));
  for (const quantity of [0, -1, 0.5, NaN]) assert.equal(routing.hook(cue('tutorial-refill', {type: 'tutorial-refill', quantity})), false);
  assert.deepEqual(played, ['UIFIELD_07_NOTIFY']);
});

test('real cumulative battle cues connect once, and restoring does not replay', () => {
  const {routing, played} = router();
  const snapshot = {kind: 'wild', active: 0, enemyActive: 0, party: [{instanceId: 'ally', hp: 20, moves: [{id: 'leaf'}]}], opponents: [{instanceId: 'enemy', hp: 20}], events: [
    {type: 'residual', instanceId: 'ally', status: 'poison', amount: 2},
    {type: 'status-cured', instanceId: 'ally', status: 'freeze'},
    {type: 'learned-move', instanceId: 'ally', moveId: 'leaf'},
    {type: 'tutorial-refill', quantity: 1}
  ]};
  const before = JSON.stringify(snapshot);
  const sequences = createSharedBattleSequences();
  for (const item of sequences.consume(snapshot)) routing.hook(cue(item.kind, item.event));
  assert.deepEqual(played, ['BATTLE_15_RESIDUAL_DAMAGE', 'BATTLE_13_STATUS_CURED', 'BATTLE_14_MOVE_LEARNED', 'UIFIELD_07_NOTIFY']);
  assert.deepEqual(sequences.consume(snapshot), []);
  assert.deepEqual(createSharedBattleSequences().consume(snapshot, {restoring: true}), []);
  assert.equal(JSON.stringify(snapshot), before, 'presentation must not mutate game state');
});

test('BGM, ambient loops and disposed routers stay outside one-shot routing', () => {
  const {routing, played} = router();
  for (const channel of ['map-bgm', 'battle-bgm', 'map-ambient', 'weather']) assert.equal(routing.hook({channel, id: 'UIFIELD_20_RECOVERY'}), false);
  assert.equal(routing.play('AMBIENT_03_WIND'), false);
  assert.equal(routing.play('missing-role'), false);
  routing.dispose();
  assert.equal(routing.step(step()), false);
  assert.equal(routing.play('UIFIELD_20_RECOVERY'), false);
  assert.deepEqual(played, []);
});

test('new sounds preserve gesture gating, mute, volume, suspension and four-effect bound', async () => {
  const media = [];
  const transport = createOriginalSfxTransport({createMedia(src) {
    const item = {src, volume: 0, playCount: 0, pauses: 0, play() {this.playCount++; return Promise.resolve();}, pause() {this.pauses++;}, addEventListener() {}, removeEventListener() {}, removeAttribute() {}, load() {}};
    media.push(item); return item;
  }});
  const routing = createOriginalSfxRouting(transport);
  assert.equal(routing.play('UIFIELD_20_RECOVERY'), false);
  transport.setEnabled(true);
  assert.equal(routing.play('UIFIELD_20_RECOVERY'), false);
  transport.gesture({type: 'pointerdown', isTrusted: false});
  assert.equal(routing.play('UIFIELD_20_RECOVERY'), false);
  transport.gesture({type: 'pointerdown', isTrusted: true});
  transport.setGain(0.5);
  for (const asset of provenance.assets) assert.equal(routing.play(asset.role), true);
  await Promise.resolve();
  assert.equal(transport.state().effects, 4);
  assert.equal(media[0].pauses > 0, true);
  assert(media.every(item => item.volume === 0.15));
  transport.setSuspended(true);
  assert.equal(transport.state().effects, 0);
  assert.equal(routing.play('UIFIELD_20_RECOVERY'), false);
  transport.setSuspended(false);
  transport.setEnabled(false);
  assert.equal(routing.play('UIFIELD_20_RECOVERY'), false);
  transport.setEnabled(true); transport.setGain(0);
  assert.equal(routing.play('UIFIELD_20_RECOVERY'), false);
  routing.dispose();
});
