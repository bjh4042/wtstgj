import test from 'node:test';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
import {createHash} from 'node:crypto';
import {fixture,memory,load,fs,source,BINDINGS} from './forest-test-fixture.mjs';
const {mountNativeCandidateMenu}=await load('native-connected/menu.mjs');
const {nativeSlotKey,SESSION_REVISION}=await load('native-connected/session.mjs');
const {prepareGridHouse,createGridHouseController,VILLAGE_HOUSES}=await load('world/internal-interiors/house/grid-candidate.mjs');
const {NATIVE_HOUSE_DOORS}=await load('world/internal-interiors/house/native-door-bindings.mjs');
const {DEX_METADATA:DEX}=await load('ui/species-dex-data.mjs');
const {ECOLOGY_CANDIDATE_DATA:BASE}=await load('ui/species-dex-ecology-data.mjs');
const {ECOLOGY_SUPPLEMENT_R4:R4}=await load('ui/species-dex-ecology-supplement-r4.mjs');
const {ECOLOGY_SUPPLEMENT_R5:R5}=await load('ui/species-dex-ecology-supplement-r5.mjs');
const {ecologyCandidateFor}=await load('ui/species-dex-ecology-candidate.mjs');
const resources=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/',import.meta.url);
const prepared=await prepareGridHouse({enabled:true,mode:'development',readBytes:async p=>new Uint8Array(await fs.readFile(new URL(p,resources))),sha256:b=>createHash('sha256').update(b).digest('hex')});

test('one session visits a native home, warps to the forest, resumes its save and returns without cross-candidate writes',async()=>{
 const storage=memory(),legacy=['native-prologue-r2','native-houses-r3','native-forest-r3'];
 for(const name of legacy)storage.setItem(`geoje.dev.interior-pilot.${name}.v1.SLOT_1`,name);
 let s=await fixture({storage}),house;
 try{
  s.exterior.arrival(NATIVE_HOUSE_DOORS[0].foot);const pose=s.exterior.capture();pose.facing='up';s.exterior.restore(pose);
  const before=s.world.snapshot(),foot=s.exterior.capture(),rawBefore=[...storage.m];
  house=createGridHouseController({world:s.world,prepared,current:()=>true,canInput:()=>true,nativeScene:()=>s.exterior});
  assert(house.enter());assert.equal(house.snapshot().houseId,VILLAGE_HOUSES[0].id);assert(house.recover());
  assert.deepEqual(s.world.snapshot(),before);assert.deepEqual(s.exterior.capture(),foot);assert.deepEqual([...storage.m],rawBefore);
  const forward='area-entry:P_ECO_CENTER_EDGE';s.exterior.arrival(BINDINGS[forward].foot);await s.world.interact(forward);s.sync();assert.equal(s.exterior.kind,'forest');
  assert.equal(house.atDoor(),false);house.dispose();await s.moveExterior('up');await s.save();const forestPose=s.exterior.capture();s.dispose();s=await fixture({storage});assert.deepEqual(s.exterior.capture(),forestPose);
  s.exterior.arrival([570,270]);await s.world.interact(forward+':return');s.sync();assert.equal(s.exterior.kind,'prologue');assert.deepEqual(s.exterior.player,BINDINGS[forward].returnFoot);
  for(const name of legacy)assert.equal(storage.getItem(`geoje.dev.interior-pilot.${name}.v1.SLOT_1`),name);
  assert.equal(JSON.parse(storage.getItem(nativeSlotKey('SLOT_1'))).data.nativeCandidateRevision,SESSION_REVISION);assert.equal(storage.m.size,4);
 }finally{house?.dispose();s.dispose()}
});

test('real native menu opens 89/R4/R5 dex details and retains existing save/backup actions',async()=>{
 const s=await fixture();const {document}=parseHTML('<html><body><main id="canonical-world"><section><select data-w="starter"></select><button data-w="save">저장</button><button data-w="retry">재시도</button></section><button data-w="menu"></button><canvas data-w="field"></canvas><output data-w="status"></output><aside><pre data-w="state"></pre><section data-w="party"></section><details><summary>안내</summary><div data-w="guide"></div></details><details><select data-w="time"></select></details><p data-native-pc-backup><button data-backup>백업</button></p></aside></main></body></html>');
 const root=document.querySelector('main');let saved=0,backed=0;
 const save=root.querySelector('[data-w="save"]'),backup=root.querySelector('[data-backup]');save.onclick=()=>saved++;backup.onclick=()=>backed++;
 const menu=mountNativeCandidateMenu({root,ecologyCandidate:true,onExit(){},onOpenMenu(){}});
 try{
  const runtime=s.world.snapshot(),before=structuredClone(runtime); // In-memory DOM fixture only, not a game save.
  runtime.dex.seen=['SPECIES_001','SPECIES_023','SPECIES_029'];
  for(const id of runtime.dex.seen){
   menu.update(runtime,{catalog:s.world.catalog,open:false});assert(root.querySelector('aside').hidden);
   menu.update(runtime,{catalog:s.world.catalog,open:true});assert.equal(root.querySelector('aside').hidden,false);
   root.querySelector('[data-menu-page="dex"]').click();const row=root.querySelector(`[data-dex-id="${id}"]`);assert(row&&!row.disabled);row.click();
   const detail=root.querySelector('.eco-menu-content').textContent;assert(detail.includes('실제 생물 이야기'));assert(detail.includes('독립 사실검수'));assert(root.querySelector('.eco-dex-ecology-sources a[href]'));
  }
  menu.update(runtime,{catalog:s.world.catalog,open:false});menu.update(runtime,{catalog:s.world.catalog,open:true});root.querySelector('[data-menu-page="save"]').click();
  assert.equal(save.closest('[hidden]'),null);save.click();backup.click();assert.equal(saved,1);assert.equal(backed,1);assert.deepEqual(s.world.snapshot(),before);
 }finally{menu.dispose();s.dispose()}
});

test('all 140 biological slots resolve in this same candidate, without a change to undiscovered rules',()=>{
 const datasets=[BASE,R4,R5],ids=new Set(datasets.flatMap(d=>Object.keys(d.slots)));assert.deepEqual(datasets.map(d=>Object.keys(d.slots).length),[89,9,42]);assert.equal(ids.size,140);assert.equal(datasets.reduce((n,d)=>n+Object.keys(d.groups).length,0),68);
 for(const [id,info]of Object.entries(DEX.records)){const r={...info,id,number:Number(id.slice(8)),seen:true},result=ecologyCandidateFor(r);if(info.motifKind==='actual_living_organism')assert(result&&result.status==='source-supported-development-candidate');else assert.equal(result,null);assert.equal(ecologyCandidateFor({...r,seen:false}),null)}
});

test('the only compiled HTML explicitly enables the native menu, ecology and dialogue pages',async()=>{
 assert((await fs.readFile(new URL('beta05-unified-native-candidate.html',source),'utf8')).includes('./native-connected/game-entry.mjs'));
 const entry=await fs.readFile(new URL('native-connected/game-entry.mjs',source),'utf8');for(const token of ['houseGridFactory,nativeCandidateUI:true,ecologyCandidate:true','prepareForestRenderer(rendererOptions)','navigator.locks.request(s4SlotKey(selection.slot)'])assert(entry.includes(token));
 assert(!entry.includes('listCopySources:'));
 const world=await fs.readFile(new URL('world/entry.mjs',source),'utf8');assert(world.includes('if(nativeCandidateUI===true)ordinaryMenu=mountNativeCandidateMenu('));assert(world.includes("continueButton:el('continue'),enabled:!!ordinary||nativeCandidateUI===true"));assert(world.includes("'NATIVE_UI_EXPLICIT_HOST_REQUIRED'"));assert.equal(nativeSlotKey('SLOT_1'),'geoje.dev.interior-pilot.forest-growth-merged-r1.v1.SLOT_1');assert.equal(SESSION_REVISION,'BETA05_FOREST_GROWTH_MERGED_CANDIDATE_R1');
});
