// Actual integrated candidate source. No overlay loader.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {FOREST_FENCE_SOURCE_SHA as pin,FOREST_FENCE_PARTS as parts,forestFencePartsForFoot as selected,drawForestFenceForeground as drawFence} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-fence-foreground.mjs';
import {prepareForestRenderer} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-renderer.mjs';
import {createForestScene} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-scene.mjs';
import {FOREST,FOREST_BINDINGS,forestSafe} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-plan.mjs';
import {PROLOGUE_SCENE} from '../dist/native_world_selected_s9_boss_source_r3/source/native-restoration/r2-scene.mjs';
import {grassForegroundRuns} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-grass-foreground.mjs';
import {APPROVED_PLAYER_FRAMES} from '../dist/native_world_selected_s9_boss_source_r3/source/art/approved-player-bindings.mjs';
const base=new URL('../',import.meta.url);
const bytes=await readFile(new URL('public-resources/native-restoration/prologue.png',base));
const image={width:FOREST.width,height:FOREST.height};
const pose=foot=>({mapId:FOREST.mapId,revision:FOREST.revision,foot});
function context({fail=false}={}){
 const calls=[],stack=[];return{canvas:{width:960,height:540},calls,globalAlpha:1,
 save(){stack.push(this.globalAlpha);calls.push(['save'])},restore(){this.globalAlpha=stack.pop();calls.push(['restore'])},
 beginPath(){calls.push(['beginPath'])},moveTo(...a){calls.push(['moveTo',...a])},lineTo(...a){calls.push(['lineTo',...a])},closePath(){calls.push(['closePath'])},clip(){calls.push(['clip'])},rect(){},
 drawImage(...a){calls.push(['drawImage',...a]);if(fail)throw Error('TEST_DRAW_FAILED')},clearRect(){},fillRect(){},fillText(){}};
}
test('unchanged original composite pins match forest renderer',()=>{assert.equal(pin,FOREST.imageSHA);assert.equal(createHash('sha256').update(bytes).digest('hex'),pin)});
test('all eight fence pieces are bounded immutable candidate original-pixel coordinates',()=>{
 assert.equal(parts.length,8);assert.equal(new Set(parts.map(p=>p.id)).size,8);
 for(const p of parts){assert(Object.isFrozen(p)&&Object.isFrozen(p.polygon[0]));const[x,y,w,h]=p.bounds;assert(w<=14&&h<=34);assert(p.depthY>=y+h);for(const[a,b]of p.polygon){assert(Number.isInteger(a)&&Number.isInteger(b));assert(a>=x&&a<x+w&&b>=y&&b<y+h)}}
});
test('conservative actor envelope contains every current approved frame at 90px',()=>{
 for(const f of Object.values(APPROVED_PLAYER_FRAMES)){const[l,t,r,b]=f.bounds;assert((r-l)*90/(b-t)<=70)}
});
test('existing legal west and east grass-edge feet select only their nearby fence',()=>{
 for(const[foot,side]of[[[620,150],'west'],[[779,150],'east'],[[620,187],'west'],[[779,187],'east']]){assert(forestSafe(foot));const out=selected(foot);assert(out.length>0);assert(out.every(p=>p.id.startsWith(side)))}
});
test('grass center, south approach and malformed feet never gain fence overlap',()=>{
 for(const foot of [[700,150],[700,223],[570,270],[620,203],null,[],[620],[620,150,0],[620.5,150],[NaN,150]])assert.deepEqual(selected(foot),[]);
});
test('each part stops covering the player exactly at its candidate depth',()=>{
 for(const p of parts){const x=p.id.startsWith('west')?620:779;assert(selected([x,p.depthY-1]).includes(p));assert(!selected([x,p.depthY]).includes(p));assert(!selected([x,p.depthY+1]).includes(p))}
});
test('redraw preserves source pixels, original scale and translated polygon clipping',()=>{
 const c=context(),foot=[620,150],origin=[450,40];assert.equal(drawFence(c,image,origin,foot),selected(foot).length);
 const draws=c.calls.filter(x=>x[0]==='drawImage');for(const call of draws){assert.equal(call[1],image);assert.equal(call[6],call[2]-origin[0]);assert.equal(call[7],call[3]-origin[1]);assert.equal(call[8],call[4]);assert.equal(call[9],call[5])}
 assert.equal(c.calls.filter(x=>x[0]==='clip').length,draws.length);assert.equal(c.calls.filter(x=>x[0]==='save').length,c.calls.filter(x=>x[0]==='restore').length);
});
test('offscreen parts and invalid camera origins do not draw',()=>{
 const c=context();assert.equal(drawFence(c,image,[1500,500],[620,150]),0);assert.equal(c.calls.length,0);
 for(const origin of [null,[],[0],[0,NaN],[0,1,2]])assert.throws(()=>drawFence(c,image,origin,[620,150]),/ORIGIN/);assert.equal(c.calls.length,0);
});
test('failed draw restores the context and leaves the original foot untouched',()=>{
 const c=context({fail:true}),foot=Object.freeze([620,150]);assert.throws(()=>drawFence(c,image,[450,40],foot),/TEST_DRAW_FAILED/);assert.deepEqual(c.calls.at(-1),['restore']);assert.deepEqual(foot,[620,150]);
});
test('real renderer adds edge fence while keeping grass-row return contract',async()=>{
 const r=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>image}),c=context();
 try{const foot=[620,150];assert.equal(r.drawForeground(c,pose(foot),{elapsedMs:800}),grassForegroundRuns(foot,{elapsedMs:800}).length);assert(c.calls.some(x=>x[0]==='clip'))}finally{r.dispose()}
});
test('center grass foreground and sway return stay unchanged',async()=>{
 const r=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>image});
 try{for(const reducedMotion of [false,true]){const c=context(),options={elapsedMs:800,reducedMotion};assert.equal(r.drawForeground(c,pose([700,150]),options),grassForegroundRuns([700,150],options).length);assert(!c.calls.some(x=>x[0]==='clip'))}}finally{r.dispose()}
});
test('fence geometry is static in reduced-motion mode',async()=>{
 const r=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>image}),a=context(),b=context();
 try{r.drawForeground(a,pose([620,150]),{elapsedMs:800});r.drawForeground(b,pose([620,150]),{elapsedMs:800,reducedMotion:true});assert.deepEqual(a.calls,b.calls)}finally{r.dispose()}
});
test('renderer rejects unsafe or stale poses without drawing',async()=>{
 const r=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>image}),c=context();
 try{for(const p of [pose([600,150]),{...pose([620,150]),revision:'wrong'},{...pose([620,150]),mapId:'wrong'}])assert.throws(()=>r.drawForeground(c,p),/POSE/);assert.equal(c.calls.length,0)}finally{r.dispose()}
});
test('disposal and abort prevent stale foreground draws',async()=>{
 const abort=new AbortController();let closed=0;const r=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>({...image,close(){closed++}}),signal:abort.signal}),c=context();
 abort.abort();assert.throws(()=>r.drawForeground(c,pose([620,150])),/CANCELLED/);r.dispose();r.dispose();assert.equal(closed,1);assert.equal(c.calls.length,0);
});
function definition(){
 const points=Object.fromEntries(Object.keys(FOREST_BINDINGS).map(id=>[id,{id,label:id}]));
 const back='area-entry:P_ECO_CENTER_EDGE:return',forward='area-entry:P_ECO_CENTER_EDGE';
 points[back]={...points[back],reverseId:forward,targetMapId:PROLOGUE_SCENE.mapId};points[forward]={id:forward,targetMapId:FOREST.mapId,reverseId:back};
 return{points,maps:{[FOREST.mapId]:{points:Object.keys(FOREST_BINDINGS)}}};
}
test('actual scene paints fence after player before HUD and preserves save/movement state',async()=>{
 const r=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>image}),c=context();
 c.fillText=text=>{if(text.startsWith('숲길'))c.calls.push(['hud'])};
 const scene=createForestScene({definition:definition(),renderer:{forest:r},drawPlayer:()=>c.calls.push(['player']),current:()=>true});
 try{scene.arrival([620,150]);const before=scene.capture();scene.draw(c);const p=c.calls.findIndex(x=>x[0]==='player'),f=c.calls.findIndex(x=>x[0]==='clip'),hud=c.calls.findIndex(x=>x[0]==='hud');assert(p<f&&f<hud);assert.deepEqual(scene.capture(),before);assert.equal(scene.pendingWalk,0);assert.equal(scene.move('left'),false);assert.deepEqual(scene.player,[620,150]);scene.draw(c);assert.deepEqual(scene.capture(),{...before,facing:'left'});}finally{scene.dispose();r.dispose()}
});
test('presentation module owns no collision, random encounter, storage or scene mutation',async()=>{
 const code=await readFile(new URL('../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-fence-foreground.mjs',import.meta.url),'utf8');
 for(const forbidden of ['forest-plan','Math.random','localStorage','worldCommand','arrival(','move('])assert(!code.includes(forbidden));
});
