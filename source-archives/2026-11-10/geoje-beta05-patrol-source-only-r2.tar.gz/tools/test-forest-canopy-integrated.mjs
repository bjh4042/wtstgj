// Actual integrated candidate source. No overlay loader.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {FOREST_CANOPY_SOURCE_SHA as pin,FOREST_CANOPY_DEPTH_Y as depth,FOREST_CANOPY_RUNS as runs,canopyForegroundRuns as select,drawForestCanopyForeground as draw} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-canopy-foreground.mjs';
import {FOREST,forestSafe} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-plan.mjs';
import {prepareForestRenderer} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-renderer.mjs';
const bytes=await readFile(new URL('../public-resources/native-restoration/prologue.png',import.meta.url));
function context(){const calls=[];return{canvas:{width:960,height:540},calls,save(){calls.push(['save'])},restore(){calls.push(['restore'])},drawImage(...a){calls.push(['drawImage',...a])}}}
test('leaf stencil pins unchanged original source and stays inside inspected canopy',()=>{
 assert.equal(pin,FOREST.imageSHA);assert.equal(createHash('sha256').update(bytes).digest('hex'),pin);assert.equal(runs.length,157);assert.equal(runs.reduce((n,[,x,X])=>n+X-x,0),1308);
 let last=[0,0,0];for(const row of runs){const[y,x,X]=row;assert(Object.isFrozen(row));assert(y>=231&&y<=311&&x>=500&&X<=529&&X>x);assert(y>last[0]||y===last[0]&&x>=last[2]);last=row}
});
test('existing safe south-path pose overlaps original leaves, center and grass poses do not',()=>{
 assert(forestSafe([540,300]));assert(select([540,300]).length>0);
 for(const foot of [[570,300],[700,150],[700,223],[620,150],[779,150]])assert.deepEqual(select(foot),[]);
});
test('candidate base depth and actor bounds prevent foreground behind/in front mistakes',()=>{
 assert(select([540,depth-1]).length>0);assert.deepEqual(select([540,depth]),[]);
 for(const[y,x,X]of select([540,300])){assert(y>=210&&y<300);assert(X>505&&x<575)}
 for(const p of [null,[],[540],[540,300,0],[540.5,300],[NaN,300]])assert.deepEqual(select(p),[]);
});
test('leaf redraw is source-aligned one-pixel rows without replacement pixels or transparency changes',()=>{
 const c=context(),image={},origin=[400,100];const n=draw(c,image,origin,[540,300]);assert.equal(n,select([540,300]).length);
 for(const a of c.calls.filter(x=>x[0]==='drawImage')){assert.equal(a[1],image);assert.equal(a[5],1);assert.equal(a[9],1);assert.equal(a[6],a[2]-400);assert.equal(a[7],a[3]-100);assert.equal(a[8],a[4])}
 assert.deepEqual(c.calls[0],['save']);assert.deepEqual(c.calls.at(-1),['restore']);
});
test('offscreen, invalid origin and failing canvas restore are handled without state mutation',()=>{
 const c=context(),image={};assert.equal(draw(c,image,[1000,500],[540,300]),0);assert.equal(c.calls.length,0);
 assert.throws(()=>draw(c,image,[NaN,0],[540,300]),/ORIGIN/);c.drawImage=()=>{throw Error('DRAW_FAIL')};assert.throws(()=>draw(c,image,[400,100],Object.freeze([540,300])),/DRAW_FAIL/);assert.deepEqual(c.calls.at(-1),['restore']);
});
test('actual forest renderer reaches canopy without changing existing grass-row return',async()=>{
 const image={width:FOREST.width,height:FOREST.height},r=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>image});
 try{const c=context(),p={mapId:FOREST.mapId,revision:FOREST.revision,foot:[540,300]};assert.equal(r.drawForeground(c,p,{elapsedMs:800,reducedMotion:true}),0);assert(c.calls.filter(x=>x[0]==='drawImage').length>0)}finally{r.dispose()}
});
test('canopy presentation does not own path, random encounter or save updates',async()=>{
 const source=await readFile(new URL('../dist/native_world_selected_s9_boss_source_r3/source/native-connected/forest-canopy-foreground.mjs',import.meta.url),'utf8');for(const term of ['forest-plan','Math.random','localStorage','worldCommand','arrival(','move('])assert(!source.includes(term));
});
