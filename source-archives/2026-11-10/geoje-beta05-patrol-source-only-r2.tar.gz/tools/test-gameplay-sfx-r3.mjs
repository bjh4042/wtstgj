import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {ORIGINAL_SFX, ROLE_SOURCE} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-manifest.mjs';
import {createOriginalSfxRouting} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-routing.mjs';
import {createOriginalSfxTransport} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-transport.mjs';
import {createBattlePresentation} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/presentation.mjs';

const source = new URL('../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx/', import.meta.url);
const publicSource = new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx/', import.meta.url);
const provenance = JSON.parse(fs.readFileSync(new URL('gameplay-sfx-r3-provenance.json', source), 'utf8'));
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const end = outcome => ({channel: 'original-sfx-cue', cue: {kind: 'end', event: {type: 'end', outcome}}});

function router() {
  const played = [];
  return {played, routing: createOriginalSfxRouting({oneShot(id) {played.push(id); return true;}, reset() {}, dispose() {}})};
}

test('two distinct original PCM effects have reproducible provenance and readable resource paths', () => {
  assert.equal(provenance.assets.length, 2);
  const newRoles = new Set(provenance.assets.map(asset => asset.role));
  const existingHashes = new Set(Object.entries(ORIGINAL_SFX).filter(([id]) => !newRoles.has(id)).map(([, asset]) => hash(fs.readFileSync(new URL(asset.url)))));
  const newHashes = new Set();
  for (const asset of provenance.assets) {
    const bytes = fs.readFileSync(new URL(asset.file, source));
    const digest = hash(bytes);
    assert.equal(digest, asset.sha256);
    assert(!existingHashes.has(digest), 'not a renamed existing sound');
    newHashes.add(digest);
    assert.equal(ROLE_SOURCE[asset.role], asset.role);
    assert.equal(ORIGINAL_SFX[asset.role].loop, false);
    assert.equal(ORIGINAL_SFX[asset.role].url, new URL(asset.file, source).href);
    assert.deepEqual(fs.readFileSync(new URL(asset.file, publicSource)), bytes);
    assert.equal(bytes.toString('ascii', 0, 4), 'RIFF');
    assert.equal(bytes.toString('ascii', 8, 12), 'WAVE');
    assert.equal(bytes.toString('ascii', 12, 16), 'fmt ');
    assert.equal(bytes.readUInt32LE(4) + 8, bytes.length);
    assert.equal(bytes.readUInt16LE(20), 1);
    assert.equal(bytes.readUInt16LE(22), 1);
    assert.equal(bytes.readUInt32LE(24), 48000);
    assert.equal(bytes.readUInt16LE(34), 16);
    assert.equal(bytes.toString('ascii', 36, 40), 'data');
    assert.equal(bytes.readUInt32LE(40), bytes.length - 44);
    assert.equal(bytes.length, asset.bytes);
    const frames = (bytes.length - 44) / 2;
    assert.equal(frames / 48000, asset.seconds);
    assert.equal(bytes.readInt16LE(44), 0);
    assert.equal(bytes.readInt16LE(bytes.length - 2), 0);
    let peak = 0, squares = 0;
    for (let i = 44; i < bytes.length; i += 2) {
      const value = bytes.readInt16LE(i) / 32768;
      peak = Math.max(peak, Math.abs(value)); squares += value * value;
    }
    const rms = Math.sqrt(squares / frames);
    assert(peak > 0.10 && peak <= 0.551, 'nonzero, no clipping');
    assert(rms > 0.05 && rms < 0.11, 'subdued signal level');
    assert.equal(Number(peak.toFixed(6)), asset.peak);
    assert.equal(Number(rms.toFixed(6)), asset.rms);
  }
  assert.equal(newHashes.size, 2);
});

test('only confirmed lost/fled terminal cues receive the new result sounds', () => {
  const {routing, played} = router();
  routing.hook(end('fled'));
  routing.hook(end('lost'));
  routing.hook(end('won'));
  for (const event of [
    end('captured'), end('unknown'), end(null),
    {channel: 'original-sfx-cue', cue: {kind: 'end', event: {outcome: 'fled'}}},
    {channel: 'original-sfx-cue', cue: {kind: 'end', event: {type: 'flee', outcome: 'fled'}}},
    {channel: 'original-sfx-cue', cue: {kind: 'cannot-flee', event: {type: 'end', outcome: 'fled'}}},
    {channel: 'battle-end', cue: end('lost').cue},
    {channel: 'battle-bgm', cue: end('fled').cue},
  ]) assert.equal(routing.hook(event), false);
  routing.hook({channel: 'original-sfx-cue', cue: {kind: 'sequence', mode: 'success'}});
  assert.deepEqual(played, ['BATTLE_16_FLEE_SUCCESS', 'BATTLE_17_DEFEAT', 'JINGLE_01_VICTORY', 'JINGLE_04_CAPTURE']);
});

test('the real presentation emits each terminal sound once, never on restore or BGM cleanup', () => {
  for (const [outcome, role] of [['fled', 'BATTLE_16_FLEE_SUCCESS'], ['lost', 'BATTLE_17_DEFEAT']]) {
    const {routing, played} = router();
    const snapshot = {kind: 'wild', active: 0, enemyActive: 0, phase: 'ended', outcome, background: {},
      party: [{instanceId: 'ally', speciesId: 'ally', hp: outcome === 'lost' ? 0 : 20, moves: []}],
      opponents: [{instanceId: 'enemy', speciesId: 'enemy', hp: 20}], events: [{type: 'end', outcome}]};
    const before = JSON.stringify(snapshot);
    const audio = {emit(id, metadata) {routing.hook({id, ...metadata});}};
    const canvas = {clearRect() {}, fillRect() {}, save() {}, restore() {}, beginPath() {}, ellipse() {}, fill() {}};
    const presentation = createBattlePresentation({audio, drawSpecies: () => ({}), reducedMotion: true});
    presentation.consume(snapshot);
    presentation.draw(canvas, snapshot, 0);
    presentation.draw(canvas, snapshot, 16);
    presentation.consume(snapshot);
    presentation.draw(canvas, snapshot, 32);
    presentation.stop();
    assert.deepEqual(played, [role]);
    const restored = createBattlePresentation({audio, drawSpecies: () => ({}), reducedMotion: true});
    restored.consume(snapshot, {restoring: true});
    restored.draw(canvas, snapshot, 48);
    restored.stop();
    assert.deepEqual(played, [role]);
    assert.equal(JSON.stringify(snapshot), before, 'audio/presentation does not mutate gameplay state');
  }
});

test('terminal sounds use existing gesture, gain, mute and suspension safeguards', async () => {
  const media = [];
  const transport = createOriginalSfxTransport({createMedia(src) {
    const item = {src, volume: 0, plays: 0, play() {this.plays++; return Promise.resolve();}, pause() {}, addEventListener() {}, removeEventListener() {}, removeAttribute() {}, load() {}};
    media.push(item); return item;
  }});
  const routing = createOriginalSfxRouting(transport);
  assert.equal(routing.hook(end('lost')), false);
  transport.setEnabled(true);
  assert.equal(routing.hook(end('fled')), false);
  transport.gesture({type: 'pointerdown', isTrusted: true});
  transport.setGain(0.5);
  assert.equal(routing.hook(end('fled')), true);
  assert.equal(routing.hook(end('lost')), true);
  await Promise.resolve();
  assert.deepEqual(media.map(item => item.volume), [0.15, 0.15]);
  assert(media.every(item => item.plays === 1));
  assert.equal(transport.state().effects, 2);
  transport.setSuspended(true);
  assert.equal(transport.state().effects, 0);
  assert.equal(routing.hook(end('lost')), false);
  transport.setSuspended(false);
  transport.setEnabled(false);
  assert.equal(routing.hook(end('fled')), false);
  transport.setEnabled(true); transport.setGain(0);
  assert.equal(routing.hook(end('lost')), false);
  routing.dispose();
  assert.equal(routing.hook(end('fled')), false);
});
