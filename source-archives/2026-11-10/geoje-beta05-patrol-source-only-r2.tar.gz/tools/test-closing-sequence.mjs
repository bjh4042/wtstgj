import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {parseHTML} from 'linkedom';
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const load=file=>import(new URL(file,source));
const {openFourBadgeClosing}=await load('ui/beta05-closing-player.mjs');
const {CLOSING_SCENES,CLOSING_BADGES,CLOSING_ART,CLOSING_PARTNERS,CLOSING_DURATION_MS,canShowFourBadgeClosing}=await load('ui/beta05-closing-scenes.mjs');
const {appendBeta05Completion}=await load('ui/beta05-completion.mjs');
const {createAudioHooks}=await load('presentation/audio-hooks.mjs');
const {installOrdinaryOriginalSfx}=await load('presentation/ordinary-original-sfx.mjs');
const {FILM_AUDIO_SLOTS}=await load('film/film-audio.mjs');
const {readEndingState}=await load('world/ending-scenes.mjs');
const valid=()=>({enabled:true,version:'0.5',development:true,candidate:true,badgeTarget:4,complete:true,pendingSave:false});
function dom(){
 const {document}=parseHTML('<html><body><section id="host"><button id="return">여정 돌아보기</button></section></body></html>');
 let active=document.body,visible='visible';
 Object.defineProperty(document,'activeElement',{get:()=>active});Object.defineProperty(document,'visibilityState',{get:()=>visible});
 const original=document.createElement.bind(document);document.createElement=tag=>{const node=original(tag);node.focus=()=>active=node;if(tag==='dialog')node.showModal=()=>{node.open=true};return node};
 const host=document.getElementById('host'),returnFocus=document.getElementById('return');returnFocus.focus=()=>active=returnFocus;returnFocus.focus();
 return {document,host,returnFocus,visibility(value){visible=value;document.dispatchEvent(new document.defaultView.Event('visibilitychange'))}};
}
function fixture(){
 const f=dom();let view=valid(),time=0,serial=0,done=0;const timers=new Map,tracks=[],hookEvents=[];
 const clock={setTimeout(fn,ms){const id=++serial;timers.set(id,{at:time+ms,fn});return id},clearTimeout:id=>timers.delete(id)};
 function tick(ms){const end=time+ms;let limit=100;while(timers.size){const [id,job]=[...timers].sort((a,b)=>a[1].at-b[1].at)[0];if(job.at>end)break;assert(limit-->0);time=job.at;timers.delete(id);job.fn()}time=end}
 function audioFactory({kind,onChange}){const state={available:true,volume:.25,playing:false,pending:false,plays:0,pauses:0,disposed:false,kind};tracks.push(state);const emit=()=>onChange(state);return {get state(){return state},pause(){state.pauses++;state.playing=false;emit()},playFromGesture(){state.plays++;state.playing=true;emit();return Promise.resolve()},setVolume(v){state.volume=v;emit()},dispose(){state.disposed=true;state.playing=false;emit()}}}
 const hooks={emit:(id,event)=>hookEvents.push({id,...event})};
 const options={host:f.host,returnFocus:f.returnFocus,readStatus:()=>view,clock,now:()=>time,audioFactory,hooks,onClose:()=>done++};
 const player=openFourBadgeClosing(options);
 const button=text=>{const node=[...f.host.querySelectorAll('button')].find(n=>n.textContent===text);assert(node,'button '+text);return node};
 return {...f,player,options,timers,tracks,hookEvents,tick,button,setStatus:value=>view=value,get done(){return done}};
}
test('only saved, complete four-badge candidates are eligible; S1/S2/S3 and pending saves are excluded',()=>{
 assert(canShowFourBadgeClosing(valid()));for(const patch of [{enabled:false},{complete:false},{pendingSave:true},{badgeTarget:3},{candidate:false},{development:false},{version:'1.0'}])assert(!canShowFourBadgeClosing({...valid(),...patch}));
 for(const patch of [{badgeTarget:1},{badgeTarget:2},{badgeTarget:3},{pendingSave:true},{complete:false}]){const f=dom();assert.equal(openFourBadgeClosing({host:f.host,readStatus:()=>({...valid(),...patch})}),null)}
 const f=dom();const view=valid();const completion=appendBeta05Completion({parent:f.host,readStatus:()=>view});assert.equal(completion.closingButton.textContent,'네 배지 여정 돌아보기');view.pendingSave=true;completion.closingButton.click();assert.equal(f.host.querySelector('dialog'),null);
});
test('seven local scenes reach persistent credits at 29.4 seconds without playing music or marking a main ending',()=>{
 const f=fixture();try{assert.equal(CLOSING_DURATION_MS,29400);assert.equal(f.tracks[0].kind,'main');assert.equal(f.tracks[0].plays,0);f.tick(29399);assert.equal(f.player.state.index,5);f.tick(1);assert.equal(f.player.state.index,6);assert.equal(f.timers.size,0);f.tick(100000);assert.equal(f.done,0);assert.match(f.host.textContent,/본편의 결말은 이후/);assert.match(f.host.textContent,/OST20/);assert.equal(f.hookEvents[0].active,true);
 const snapshot={contentNamespace:'canonical-v1',sessionId:'closing-fixture',revision:1,progress:{completedEvents:['S4_GYM_STORY'],flags:{BADGE_04:true}}};assert.deepEqual(readEndingState(snapshot),{sessionId:'closing-fixture',revision:1,main:false,post:false});
 }finally{f.player.dispose()}
});
test('pause and tab hiding retain the exact remaining shot and animation; explicit music remains gesture-only',()=>{
 const f=fixture();try{f.tick(1200);const shot=f.host.querySelector('.closing-shot');f.button('클로징 음악 재생').click();f.button('일시정지').click();assert.equal(f.player.state.remaining,3000);assert.equal(f.tracks[0].playing,false);f.tick(60000);assert.equal(f.host.querySelector('.closing-shot'),shot);f.visibility('hidden');f.visibility('visible');assert.equal(f.timers.size,0);f.button('계속 보기').click();assert.equal(f.tracks[0].plays,2);f.tick(1000);f.visibility('hidden');assert.equal(f.player.state.remaining,2000);f.tick(60000);f.visibility('visible');f.tick(2000);assert.equal(f.player.state.index,1)}finally{f.player.dispose()}
});
test('previous/next remain paused, final credits do not auto-close, and dismiss/replay cannot duplicate owners or callbacks',()=>{
 const f=fixture();try{assert.equal(openFourBadgeClosing(f.options),null);f.button('일시정지').click();for(let i=0;i<6;i++){assert.equal(f.player.state.index,i);f.button('다음 장면').click();assert.equal(f.timers.size,0)}f.button('이전').click();assert.equal(f.player.state.index,5);f.button('다음 장면').click();const close=f.button('탐험 메뉴로');close.click();close.click();assert.equal(f.done,1);assert.equal(f.document.activeElement,f.returnFocus);assert.equal(f.tracks[0].disposed,true);assert.equal(f.hookEvents.at(-1).active,false);const replay=openFourBadgeClosing(f.options);assert.equal(replay.state.index,0);replay.dispose()}finally{f.player.dispose()}
});
test('host removal or a pending save retires the film, music and stale callbacks without completion',async()=>{
 for(const reason of ['removed','pending']){const f=fixture();const stale=[...f.timers.values()][0].fn;if(reason==='removed')f.host.remove();else f.setStatus({...valid(),pendingSave:true});f.tick(4200);stale();await Promise.resolve();assert.equal(f.player.state.disposed,true);assert.equal(f.tracks[0].disposed,true);assert.equal(f.timers.size,0);assert.equal(f.done,0);assert.equal(f.hookEvents.at(-1).active,false)}
});
test('BFCache pauses and resumes the same scene, while an explicit disposal cannot resurrect its timer',()=>{
 const f=fixture();f.tick(700);f.document.defaultView.dispatchEvent(new f.document.defaultView.Event('pagehide'));assert.equal(f.player.state.remaining,3500);assert.equal(f.timers.size,0);f.tick(60000);f.document.defaultView.dispatchEvent(new f.document.defaultView.Event('pageshow'));f.tick(3500);assert.equal(f.player.state.index,1);const stale=[...f.timers.values()][0].fn;f.player.dispose();stale();assert.equal(f.timers.size,0);
});
test('modal keyboard navigation ignores repeats and IME, preserves volume keys, and Escape returns once',()=>{
 const f=fixture();try{
  const key=(value,extra={})=>{const event=new f.document.defaultView.Event('keydown',{bubbles:true,cancelable:true});Object.assign(event,{key:value,...extra});f.document.defaultView.dispatchEvent(event);return event};
  key('ArrowRight');assert.equal(f.player.state.index,1);key('ArrowRight',{repeat:true});assert.equal(f.player.state.index,1);
  key('Escape',{isComposing:true});assert.equal(f.player.state.disposed,false);
  f.host.querySelector('input').focus();const volumeKey=key('ArrowRight');assert.equal(volumeKey.defaultPrevented,false);assert.equal(f.player.state.index,1);
  key('Tab');assert(f.player.dialog.contains(f.document.activeElement));key('Escape');assert.equal(f.player.state.disposed,true);assert.equal(f.done,1);key('Escape');assert.equal(f.done,1);
 }finally{f.player.dispose()}
});
test('failed modal creation cleans its music and owner so a later retry can open',()=>{
 const f=fixture();f.player.dispose();const make=f.document.createElement;f.document.createElement=tag=>{const node=make(tag);if(tag==='dialog')node.showModal=()=>{throw Error('test modal failure')};return node};
 assert.throws(()=>openFourBadgeClosing(f.options),/test modal failure/);assert.equal(f.tracks.at(-1).disposed,true);assert.equal(f.host.querySelector('dialog'),null);assert.equal(f.timers.size,0);
 f.document.createElement=make;const retry=openFourBadgeClosing(f.options);assert(retry);retry.dispose();
});
test('art errors preserve readable captions and old image callbacks are retired between scenes',()=>{
 const f=fixture();try{const art=f.host.querySelector('.closing-background');art.onerror();assert.equal(art.hidden,true);assert.equal(f.host.querySelector('.closing-fallback').hidden,false);assert.match(f.host.querySelector('.closing-body').textContent,/첫 파트너/);f.button('다음 장면').click();assert.equal(art.onerror,null);assert.equal(f.host.querySelector('.closing-fallback').hidden,true)}finally{f.player.dispose()}
});
test('closing assets exist and badge names/regions agree with the canonical stage master',async()=>{
 for(const path of [...Object.values(CLOSING_ART),...CLOSING_PARTNERS.map(p=>p.src),FILM_AUDIO_SLOTS.main.src])assert((await readFile(new URL(path))).length>0);
 assert.match(FILM_AUDIO_SLOTS.main.src,/ost-20\.mp3$/);assert.equal(FILM_AUDIO_SLOTS.main.loop,false);
 const master=JSON.parse((await readFile(new URL('data/staging-20260927/geoje_stage_master_v2_4.json',source),'utf8')).replace(/^\uFEFF/,''));CLOSING_BADGES.forEach((badge,index)=>{const stage=master.stages.find(s=>s.id==='S'+(index+1));assert.equal(badge.name,stage.gym.badge);assert.equal(badge.region,stage.gym.region)});
 const baseline=[{"file":"world/ending-scenes.mjs","sha256":"7f5d7e2c6ed0725067123c389ca883e1e678e157e4fc04363ec9816ee2edc19d"},{"file":"world/ending-dom-renderer.mjs","sha256":"290d2632b683b772dec1f836e03ab3613c3f5c296be6d96349cf5cd27c1d54fc"},{"file":"world/entry.mjs","sha256":"0e7a891623f5ce6cabdcbb286a7ff4b2bc26b23e582b5d6a8963a71a8c7350ff"},{"file":"film/film-audio.mjs","sha256":"bcc61eead15d3634649700dcef07334bb319e5c686381d6d3e027231461a26b8"}];for(const record of baseline){const bytes=await readFile(new URL(record.file,source));assert.equal(createHash('sha256').update(bytes).digest('hex'),record.sha256,record.file)}
 for(const file of ['ui/beta05-closing-player.mjs','ui/beta05-closing-scenes.mjs','ui/beta05-closing-style.mjs']){const code=await readFile(new URL(file,source),'utf8');assert.doesNotMatch(code,/localStorage|sessionStorage|fetch\(|setItem\(|removeItem\(/)}
});
test('BGM is exclusive during the film, resumes the latest map afterward, and never changes saved mute settings',async()=>{
 const f=dom(),hooks=createAudioHooks(),media=[];let saved={sound:true,sfx:.5},writes=0;
 class FakeAudio{constructor(src){this.src=src;this.playing=false;media.push(this)}play(){this.playing=true;return Promise.resolve()}pause(){this.playing=false}addEventListener(){}removeEventListener(){}removeAttribute(){}load(){}}
 const previous=globalThis.Audio;globalThis.Audio=FakeAudio;
 const backend={createMedia:src=>new FakeAudio(src),unlock(){},setSuspended(){},dispose(){}};
 const sound=installOrdinaryOriginalSfx({root:f.host,document:f.document,window:f.document.defaultView,hooks,backend,storage:{getItem:()=>JSON.stringify(saved),setItem:(_k,value)=>{saved=JSON.parse(value);writes++}}});
 const gesture=()=>{const e=new f.document.defaultView.Event('click',{bubbles:true});Object.defineProperty(e,'isTrusted',{value:true});f.returnFocus.dispatchEvent(e)};
 try{
  hooks.emit('bgm.field.coast',{channel:'map-bgm'});gesture();await Promise.resolve();assert.equal(media.filter(m=>m.playing).length,1);assert.match(media.at(-1).src,/ost-07/);
  const a={},b={};hooks.emit('beta05-closing',{channel:'film-presentation',owner:a,active:true});assert.equal(media.filter(m=>m.playing).length,0);gesture();assert.equal(media.filter(m=>m.playing).length,0);hooks.emit('bgm.field.forest',{channel:'map-bgm'});hooks.emit('beta05-closing',{channel:'film-presentation',owner:b,active:true});hooks.emit('beta05-closing',{channel:'film-presentation',owner:a,active:false});assert.equal(media.filter(m=>m.playing).length,0);hooks.emit('beta05-closing',{channel:'film-presentation',owner:b,active:false});await Promise.resolve();assert.equal(media.filter(m=>m.playing).length,1);assert.match(media.at(-1).src,/ost-06/);assert.equal(writes,0);
  hooks.emit('beta05-closing',{channel:'film-presentation',owner:a,active:true});f.visibility('hidden');hooks.emit('beta05-closing',{channel:'film-presentation',owner:a,active:false});assert.equal(media.filter(m=>m.playing).length,0);f.visibility('visible');assert.equal(media.filter(m=>m.playing).length,0);gesture();assert.equal(media.filter(m=>m.playing).length,1);
  hooks.emit('beta05-closing',{channel:'film-presentation',owner:a,active:true});sound.setPreferences({sound:false});hooks.emit('beta05-closing',{channel:'film-presentation',owner:a,active:false});assert.equal(media.filter(m=>m.playing).length,0);assert.equal(saved.sound,false);
 }finally{sound.dispose();globalThis.Audio=previous}
});
