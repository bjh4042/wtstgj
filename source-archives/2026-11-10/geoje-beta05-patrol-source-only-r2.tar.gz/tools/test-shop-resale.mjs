import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture,load,memory,fs,source} from './forest-test-fixture.mjs';
const {createInteriorController}=await load('world/internal-interiors/entry-pilot/controller.mjs');
const {nativeSlotKey}=await load('native-connected/session.mjs');
const {resaleItems,quoteResale,resaleItemAllowed}=await load('economy/resale-v1.mjs');
async function shop(storage=memory()){
 const seed=await fixture();const runtime=seed.world.snapshot(),map=seed.world.definition.maps['world:interior:PROLOGUE:shop'];seed.dispose();
 const {cellPosition}=await load('world/definition.mjs');runtime.position=cellPosition(map.id,...map.spawn);runtime.world.mapId=map.id;if(!runtime.world.visitedMaps.includes(map.id))runtime.world.visitedMaps.push(map.id);
 const s=await fixture({storage,initialRuntime:runtime});s.sync();
 const c=createInteriorController({session:s,assets:{},drawActor(){}});
 s.scene.player=[...s.scene.r.points.counter_front];
 return {s,c,storage};
}
test('real interior cashier sale persists 80% money and reduced ball count without changing save format',async()=>{
 let {s,c,storage}=await shop();try{
 await c.service({itemId:'ecology_ball',quantity:1,transactionId:'buy-before-sale'});const before=s.world.snapshot();const request={type:'sell',itemId:'ecology_ball',quantity:1,revision:before.revision,transactionId:'resale-interior'};
 await c.service(request);const after=s.world.snapshot();assert.equal(after.economy.money,before.economy.money+160);assert.equal(after.inventory.ecology_ball,before.inventory.ecology_ball-1);
 await s.save();const saved=s.world.snapshot();const raw=storage.getItem(nativeSlotKey('SLOT_1'));assert(raw);c.dispose();c=null;s=await fixture({storage});assert.deepEqual(s.world.snapshot(),saved);assert.equal(s.scene.kind,'shop');
 }finally{c?.dispose();s.dispose()}
});
test('important items, TMs, unknown items and malformed sales cannot change runtime or stored bytes',async()=>{
 const {s,c,storage}=await shop();try{await s.save();const before=s.world.snapshot(),raw=storage.getItem(nativeSlotKey('SLOT_1'));const excluded=Object.values(s.world.catalog.itemContract).filter(i=>!resaleItemAllowed(i));assert(excluded.length>0);
 for(const id of [...excluded.map(i=>i.id),'not_an_item']){assert.throws(()=>quoteResale(before,s.world.catalog,id,1));}
 for(const request of [{itemId:excluded[0].id,quantity:1},{itemId:'ecology_ball',quantity:0},{itemId:'ecology_ball',quantity:10000},{itemId:'ecology_ball',quantity:0.5},{itemId:'ecology_ball',quantity:1,revision:-1}]){await assert.rejects(c.service({type:'sell',revision:before.revision,transactionId:'bad:'+JSON.stringify(request),...request}));assert.deepEqual(s.world.snapshot(),before);assert.equal(storage.getItem(nativeSlotKey('SLOT_1')),raw)}
 assert(resaleItems(s.world.catalog,before).every(resaleItemAllowed));
 }finally{c.dispose();s.dispose()}
});
test('sale denied away from cashier and read-only UI connection remains gated by current generation',async()=>{
 const {s,c}=await shop();try{const before=s.world.snapshot();s.scene.player=[...s.scene.r.points.entry];await assert.rejects(c.service({type:'sell',itemId:'ecology_ball',quantity:1,revision:before.revision,transactionId:'away'}),/INTERIOR_PROXIMITY/);assert.deepEqual(s.world.snapshot(),before);
 const code=await fs.readFile(new URL('world/entry.mjs',source),'utf8');assert(code.includes("p.kind==='shop'&&ordinary&&!world.host?.selectedNative"));assert(code.includes('saveAckGeneration===saleGeneration'));assert(code.includes('world.snapshot().revision===saleRevision'));
 }finally{c.dispose();s.dispose()}
});
test('confirmation requires deliberate accept, cancel and stale selection never sell',async()=>{
 const {parseHTML}=await import('linkedom');const {appendResaleControls}=await load('ui/resale-controls.mjs');const {s,c}=await shop();try{
 await c.service({itemId:'ecology_ball',quantity:1,transactionId:'buy-ui'});
 const {document}=parseHTML('<html><body><main></main></body></html>');let current=true;const calls=[];
 const button=(parent,text,fn,disabled)=>{const b=document.createElement('button');b.textContent=text;b.onclick=fn;b.disabled=disabled;parent.append(b);return b};
 const ui=appendResaleControls({parent:document.querySelector('main'),runtime:s.world.snapshot(),catalog:s.world.catalog,button,isCurrent:()=>current,onSell:r=>calls.push(r)});
 assert(ui.rows.length);ui.rows[0].onclick();assert.equal(calls.length,0);assert.match(ui.question.textContent,/남는 수량/);ui.cancel.onclick();await ui.confirm.onclick();assert.equal(calls.length,0);
 ui.rows[0].onclick();current=false;await ui.confirm.onclick();assert.equal(calls.length,0);current=true;await ui.confirm.onclick();assert.equal(calls.length,1);await ui.confirm.onclick();assert.equal(calls.length,1);
 }finally{c.dispose();s.dispose()}
});
