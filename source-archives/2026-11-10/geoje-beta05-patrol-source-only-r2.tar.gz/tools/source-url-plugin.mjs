import {relative,resolve,sep} from 'node:path';
// Preserve the original module-relative resource base after Vite bundles modules.
// Source files remain byte-identical. The compiler only rewrites the import.meta.url
// AST member expression; strings, comments and import.meta.env stay untouched.
export function sourceURLPlugin({dist,base='/wtstgj/'}){
 const root=resolve(dist);
 return {name:'geoje-preserve-source-resource-urls',enforce:'pre',
  transform(code,id){
   const file=id.split('?')[0],rel=relative(root,file);
   if(!/\.[cm]?js$/.test(file)||rel==='..'||rel.startsWith('..'+sep)||rel.startsWith(sep)||!code.includes('import.meta'))return null;
   const replacements=[],ast=this.parse(code);
   function visit(node){
    if(!node||typeof node!=='object')return;
    if(node.type==='MemberExpression'&&node.object?.type==='MetaProperty'&&node.object.meta?.name==='import'&&node.object.property?.name==='meta'&&((!node.computed&&node.property?.name==='url')||(node.computed&&node.property?.value==='url'))){
     const path=base+'__source_layout/'+rel.split(sep).map(encodeURIComponent).join('/');
     replacements.push({start:node.start,end:node.end,text:`new URL(${JSON.stringify(path)},globalThis.location.href).href`});return;
    }
    for(const value of Object.values(node)){if(Array.isArray(value))for(const child of value)visit(child);else if(value&&typeof value==='object')visit(value)}
   }
   visit(ast);if(!replacements.length)return null;
   let output=code;for(const r of replacements.sort((a,b)=>b.start-a.start))output=output.slice(0,r.start)+r.text+output.slice(r.end);
   return {code:output,map:null};
  }
 };
}
