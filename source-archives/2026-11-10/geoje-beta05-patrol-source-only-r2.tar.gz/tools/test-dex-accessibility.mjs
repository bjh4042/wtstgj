import test from 'node:test';import assert from 'node:assert/strict';import {parseHTML} from 'linkedom';
import {fixture,load} from './forest-test-fixture.mjs';
const {installOrdinaryMenu}=await load('ui/ordinary-menu.mjs');
test('dex source focus, expanded provenance, tab wrap, back and list scroll survive passive refresh',async()=>{
 const s=await fixture();const {document,window}=parseHTML('<html><body><div id="root"><button id="return">field</button><aside><div data-w="party"></div><div data-w="state"></div><details><summary>guide</summary><p data-w="guide"></p></details><section aria-label="저장 메뉴"></section></aside></div></body></html>');
 let active=document.body;Object.defineProperty(document,'activeElement',{get:()=>active});window.HTMLElement.prototype.focus=function(){active=this};window.HTMLElement.prototype.scrollIntoView=function(){};
 let exits=0;const root=document.querySelector('#root'),aside=root.querySelector('aside');const menu=installOrdinaryMenu({root,ecologyCandidate:true,onExit:()=>exits++,returnFocus:root.querySelector('#return')});
 const runtime=s.world.snapshot();runtime.dex.seen.push('SPECIES_046');const update=()=>menu.update(runtime,{catalog:s.world.catalog,open:true});const key=(key,shiftKey=false)=>{let prevented=false;menu.handleKeydown({key,shiftKey,preventDefault(){prevented=true},stopPropagation(){}});return prevented};
 try{update();root.querySelector('[data-menu-page="dex"]').onclick();aside.scrollTop=321;root.querySelector('[data-dex-id="SPECIES_046"]').onclick();assert.equal(aside.scrollTop,0);
 const link=root.querySelector('.eco-dex-basic-habitat a');assert(link.dataset.menuFocus);link.focus();const identity=link.dataset.menuFocus;update();assert.equal(document.activeElement.dataset.menuFocus,identity);assert(document.activeElement.isConnected);
 const details=root.querySelector('.eco-dex-provenance');details.setAttribute('open','');details.querySelector('summary').focus();const summaryKey=document.activeElement.dataset.menuFocus;update();assert(root.querySelector('.eco-dex-provenance').hasAttribute('open'));assert.equal(document.activeElement.dataset.menuFocus,summaryKey);
 const back=root.querySelector('[data-menu-focus="back"]');back.focus();assert(key('Tab',true));assert.equal(document.activeElement.tagName,'SUMMARY');assert(key('Tab'));assert.equal(document.activeElement,back);
 assert(key('Escape'));assert.equal(aside.scrollTop,321);assert.equal(document.activeElement.dataset.dexId,'SPECIES_046');assert.equal(exits,0);key('Escape');assert.equal(document.activeElement.dataset.menuPage,'dex');key('Escape');assert.equal(exits,1);
 menu.update(runtime,{catalog:s.world.catalog,open:false});assert.equal(document.activeElement.id,'return');
 }finally{menu.dispose();s.dispose()}
});
