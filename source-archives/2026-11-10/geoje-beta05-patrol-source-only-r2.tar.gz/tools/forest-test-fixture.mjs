import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url),load=p=>import(new URL(p,source));
const {CanonicalWorld}=await load('world/service.mjs');
const {loadApprovedLatestRuntimeAdapter}=await load('compatibility/approved-latest-runtime-adapter.mjs');
const read=dir=>async f=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await fs.readFile(new URL('data/'+dir+'/'+f,source)));
const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:read('canonical-handoff-v1')},stagedOptions:{readStaging:read('staging-20260927')}});
const {createGameplayReleases}=await load('compatibility/gameplay-release.mjs'),{createBeta05Sessions}=await load('beta05/session.mjs');
const releases=createGameplayReleases({historical:adapter,latest:adapter});
const {createConnectedSession,nativeSlotKey}=await load('native-connected/session.mjs');
const {BINDINGS,MAP}=await load('native-connected/bindings.mjs');
const {S1_NATIVE_WORLD_OPTIONS}=await load('native-connected/s1-native-policy.mjs');
const {validateCanonicalStorySave:validateCanonical}=await load('story/save.mjs');
const {validateWorldLocation:validateLocation}=await load('world/state.mjs');
const {sha256:hash,stableJSON:stable}=await load('compatibility/codec.mjs');
const authority=await load('world/interior-pilot-authority.mjs');
const {PROLOGUE_SCENE:R}=await load('native-restoration/r2-scene.mjs');
const configs={},base=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/reuse/',import.meta.url);
for(const kind of ['center','shop']){const dir=kind==='center'?'center/assets/':'shop/';configs[kind]={registration:JSON.parse(await fs.readFile(new URL(kind==='center'?'center/layout.json':'shop/REGISTRATION.json',base),'utf8')),floor:new Uint8Array(await fs.readFile(new URL(dir+(kind==='center'?'player_floor.u8':'floor.u8'),base))),staffFloor:kind==='center'?new Uint8Array(await fs.readFile(new URL(dir+'doctor_support.u8',base))):null}}
const mask=new Uint8Array(await fs.readFile(new URL('../public-resources/native-restoration/main-r2.safe.u8',import.meta.url)));
const memory=()=>{const m=new Map;return{m,getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k),get length(){return m.size},key:i=>[...m.keys()][i]??null}};
const deps={World:CanonicalWorld,worldOptions:S1_NATIVE_WORLD_OPTIONS,adapter,configs,authority,validateCanonical,validateLocation,hash,stable,mask,renderer:{drawPose:()=>({origin:[0,0]}),forest:{drawPose:()=>({origin:[0,0]})}},drawNPC(){},ownerCurrent:()=>true,key:nativeSlotKey('SLOT_1')};
async function fixture(options={}){const storage=options.storage??memory(),api=createBeta05Sessions(memory(),releases),initialRuntime=(await api.newGame('SLOT_1',{starterId:'SPECIES_001',playerName:'검증',appearance:'boy'})).runtime;return createConnectedSession({...deps,initialRuntime,storage,...options})}


export {fixture,memory,deps,load,fs,hash,stable,source,MAP,BINDINGS};
