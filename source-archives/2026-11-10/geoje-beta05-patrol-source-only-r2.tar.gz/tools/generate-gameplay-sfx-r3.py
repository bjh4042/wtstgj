#!/usr/bin/env python3
"""Original terminal-result SFX, synthesized without external samples or music.

Run normally to create the two originals and public resource links. --check
verifies deterministic bytes and provenance without modifying any files.
Existing different bytes are never silently replaced.
"""
from pathlib import Path
import argparse
import hashlib
import io
import json
import math
import os
import random
import struct
import wave

RATE = 48000
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx'
PUBLIC = ROOT / 'public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx'
DURATIONS = {'BATTLE_16_FLEE_SUCCESS': 0.34, 'BATTLE_17_DEFEAT': 0.64}


def tone(samples, start, length, frequency, end_frequency, amplitude, harmonic=0.06):
    first, count = round(start * RATE), round(length * RATE)
    for i in range(min(count, len(samples) - first)):
        t, u = i / RATE, i / max(1, count - 1)
        phase = math.tau * (frequency * t + (end_frequency - frequency) * t * t / (2 * length))
        envelope = min(1.0, t / 0.008) * min(1.0, (1 - u) / 0.18) * math.exp(-3.6 * u)
        samples[first + i] += amplitude * envelope * (math.sin(phase) + harmonic * math.sin(phase * 2.01))


def breeze(samples, start, length, amplitude):
    rng, low, slow = random.Random(1603), 0.0, 0.0
    first, count = round(start * RATE), round(length * RATE)
    for i in range(min(count, len(samples) - first)):
        low += 0.16 * (rng.uniform(-1, 1) - low)
        slow += 0.018 * (low - slow)
        u = i / max(1, count - 1)
        samples[first + i] += amplitude * (low - slow) * math.sin(math.pi * u) ** 1.6 * math.exp(-2.2 * u)


def synthesize(role):
    samples = [0.0] * round(DURATIONS[role] * RATE)
    if role == 'BATTLE_16_FLEE_SUCCESS':
        # A short receding breeze with two light steps, not a victory jingle.
        breeze(samples, 0.0, 0.30, 0.58)
        tone(samples, 0.006, 0.10, 310, 225, 0.16, 0.08)
        tone(samples, 0.108, 0.13, 390, 250, 0.10, 0.03)
        tone(samples, 0.05, 0.24, 1050, 540, 0.035, 0.0)
    elif role == 'BATTLE_17_DEFEAT':
        # A gentle descending wood-like pair marks rest after defeat.
        tone(samples, 0.0, 0.30, 330, 326, 0.19, 0.11)
        tone(samples, 0.18, 0.43, 247, 244, 0.17, 0.07)
        tone(samples, 0.185, 0.42, 123.5, 122, 0.055, 0.0)
    else:
        raise ValueError(role)
    rms = math.sqrt(sum(x * x for x in samples) / len(samples))
    target_rms = 0.075 if role == 'BATTLE_16_FLEE_SUCCESS' else 0.09
    scale = min(target_rms / rms, 0.55 / max(abs(x) for x in samples))
    fade = round(0.004 * RATE)
    return [round(x * scale * min(1.0, i / fade, (len(samples) - 1 - i) / fade) * 32767)
            for i, x in enumerate(samples)]


def pcm_wav(samples):
    buffer = io.BytesIO()
    with wave.open(buffer, 'wb') as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(RATE)
        output.writeframes(struct.pack('<' + 'h' * len(samples), *samples))
    return buffer.getvalue()


def store_or_check(path, content, check):
    if path.exists():
        if path.read_bytes() != content:
            raise RuntimeError('Existing bytes differ: ' + str(path))
    elif check:
        raise RuntimeError('Missing file: ' + str(path))
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    records = []
    for role, duration in DURATIONS.items():
        samples = synthesize(role)
        content = pcm_wav(samples)
        path, public = SOURCE / (role + '.wav'), PUBLIC / (role + '.wav')
        store_or_check(path, content, args.check)
        if not public.exists() and not public.is_symlink() and not args.check:
            public.parent.mkdir(parents=True, exist_ok=True)
            public.symlink_to(os.path.relpath(path, public.parent))
        if not public.is_file() or public.read_bytes() != content:
            raise RuntimeError('Missing or different public resource: ' + str(public))
        records.append({
            'role': role, 'file': path.name, 'seconds': duration,
            'sampleRate': RATE, 'channels': 1, 'bits': 16, 'bytes': len(content),
            'sha256': hashlib.sha256(content).hexdigest(),
            'peak': round(max(abs(x) for x in samples) / 32768, 6),
            'rms': round(math.sqrt(sum(x * x for x in samples) / len(samples)) / 32768, 6),
        })
    provenance = {
        'version': 1,
        'provenance': 'Original procedural synthesis for Geoje Monsters; no external samples, music, ROM, or private reference material.',
        'generator': 'tools/generate-gameplay-sfx-r3.py',
        'assets': records,
    }
    content = (json.dumps(provenance, ensure_ascii=False, indent=2) + '\n').encode()
    store_or_check(SOURCE / 'gameplay-sfx-r3-provenance.json', content, args.check)
    print(json.dumps({'mode': 'check' if args.check else 'create', **provenance}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
