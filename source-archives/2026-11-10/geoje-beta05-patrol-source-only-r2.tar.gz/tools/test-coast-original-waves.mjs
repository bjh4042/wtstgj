import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const {prepareCoastRenderer}=await import(new URL('native-connected/coast-renderer.mjs',root));
const {COAST}=await import(new URL('native-connected/coast-plan.mjs',root));
const readBytes=key=>fs.readFile(new URL('../public-resources/native-restoration/'+key,import.meta.url));
const hash=b=>createHash('sha256').update(b).digest('hex');
test('coast actually replays all 48 original water frames and loops at 2400ms without regenerating data',async()=>{
 const renderer=await prepareCoastRenderer({readBytes,decodeImage:async()=>({width:COAST.width,height:COAST.height})});
 const pixels=new Uint8ClampedArray(960*540*4);let puts=0;
 const ctx={canvas:{width:960,height:540},save(){},restore(){},clearRect(){pixels.fill(0)},drawImage(){},getImageData(){return{data:pixels}},putImageData(){puts++}};
 const pose={mapId:COAST.mapId,revision:COAST.revision,foot:COAST.landing};
 const idsRaw=await readBytes('environment/central.indices'),rgb=await readBytes('environment/central.rgb');
 const ids=new Uint32Array(idsRaw.buffer,idsRaw.byteOffset,idsRaw.byteLength/4),frames=[];
 let sample=-1,origin;
 for(let phase=0;phase<48;phase++){
  const result=renderer.drawPose(ctx,pose,{elapsedMs:phase*50});assert(result.writes>0);origin=result.origin;
  if(sample<0)sample=ids.findIndex(id=>id%2804>=origin[0]&&id%2804<origin[0]+960&&Math.floor(id/2804)>=origin[1]&&Math.floor(id/2804)<origin[1]+540);
  assert(sample>=0);const id=ids[sample],dst=((Math.floor(id/2804)-origin[1])*960+id%2804-origin[0])*4,src=(phase*ids.length+sample)*3;
  assert.deepEqual(Array.from(pixels.slice(dst,dst+3)),Array.from(rgb.slice(src,src+3)));
  frames.push(hash(pixels));
 }
 assert(new Set(frames).size>1);renderer.drawPose(ctx,pose,{elapsedMs:2400});assert.equal(hash(pixels),frames[0]);
 const before=puts;assert.equal(renderer.drawPose(ctx,pose,{elapsedMs:800,reducedMotion:true}).writes,0);assert.equal(puts,before);
 assert.throws(()=>renderer.drawPose(ctx,pose,{elapsedMs:NaN}),/COAST_RENDER_TIME/);
 renderer.dispose();assert.throws(()=>renderer.drawPose(ctx,pose),/CANCELLED/);
});
test('corrupt original animation bytes fail closed and decoded original image is released',async()=>{
 let closed=0;
 await assert.rejects(prepareCoastRenderer({readBytes:async key=>{const b=await readBytes(key);if(key==='environment/sw.rgb'){const c=new Uint8Array(b);c[0]^=1;return c}return b},decodeImage:async()=>({width:COAST.width,height:COAST.height,close(){closed++}})}),/ENVIRONMENT_PIN/);
 assert.equal(closed,1);
});
test('live coast clock freezes during menus/battles and leaves saved pose unchanged',async()=>{
 const {fixture,BINDINGS}=await import('./forest-test-fixture.mjs');const poses=[];
 const a=await fixture({renderer:{drawPose:()=>({origin:[0,0]}),forest:{drawPose:()=>({origin:[0,0]})},coast:{drawPose(ctx,pose,options){poses.push(options);return{origin:[0,0]}}}}});
 try{const forward='area-entry:P_JANGSEUNGPO_COAST';a.exterior.arrival(BINDINGS[forward].foot);await a.world.interact(forward);a.sync();const scene=a.exterior,pose=scene.capture();const ctx={canvas:{width:960},save(){},restore(){},fillRect(){},fillText(){}};
 scene.tick(50);scene.draw(ctx);assert.equal(poses.at(-1).elapsedMs,50);scene.tick(100,{paused:true});scene.draw(ctx);assert.equal(poses.at(-1).elapsedMs,50);scene.tick(5000);scene.draw(ctx);assert.equal(poses.at(-1).elapsedMs,150);assert.deepEqual(scene.capture(),pose);
 }finally{a.dispose()}
});
