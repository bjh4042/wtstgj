import test from 'node:test';import assert from 'node:assert/strict';
import {capturePhaseSounds} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/capture-phase-sfx.mjs';
import {createBattlePresentation} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/presentation.mjs';
import {createOriginalSfxRouting} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-routing.mjs';
import {createOriginalSfxTransport} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx-transport.mjs';
const cue=(reducedMotion=false)=>({kind:'sequence',id:'SEQ_CAPTURE',mode:'attempt',duration:1000,reducedMotion});
test('phase sounds fire once at original checkpoints without a second shake voice',()=>{
 const c=cue(),heard=[];for(const time of [0,279,280,280,400,619,620,620,800,1000,1500])heard.push(...capturePhaseSounds(c,time));assert.deepEqual(heard,['capture-absorb','capture-land-shake']);
});
test('skipped phases, expired cues, wrong ids and reduced motion never burst new sounds',()=>{
 let c=cue();assert.deepEqual(capturePhaseSounds(c,600),[]);assert.deepEqual(capturePhaseSounds(c,620),['capture-land-shake']);assert.deepEqual(capturePhaseSounds(c,300),[]);
 c=cue();assert.deepEqual(capturePhaseSounds(c,1000),[]);assert.deepEqual(capturePhaseSounds(c,620),[]);
 c=cue(true);assert.deepEqual(capturePhaseSounds(c,300),[]);assert.deepEqual(capturePhaseSounds(c,620),['shake']);assert.deepEqual(capturePhaseSounds(c,650),[]);
 for(const x of [null,{...cue(),id:'OTHER'},{...cue(),mode:'success'}, {...cue(),duration:0}])assert.deepEqual(capturePhaseSounds(x,620),[]);
});
function setup(reducedMotion=false,speed=1){
 const heard=[],routing=createOriginalSfxRouting({oneShot(id){heard.push(id);return true},reset(){},dispose(){}}),audio={emit(id,m){routing.hook({id,...m})}};
 const p=createBattlePresentation({drawSpecies:()=>({}),audio,reducedMotion,playbackSpeed:speed});
 const canvas=new Proxy({},{get:()=>()=>{}});
 const snapshot={kind:'wild',active:0,enemyActive:0,phase:'command',outcome:null,background:{},party:[{instanceId:'ally',speciesId:'ally',hp:20,moves:[]}],opponents:[{instanceId:'enemy',speciesId:'enemy',hp:20}],events:[{type:'capture',success:false,ballId:'ecology_ball'}]};return {p,heard,canvas,snapshot};
}
test('real presentation routes each cue once and preserves snapshot, result queue and failed capture',()=>{
 const {p,heard,canvas,snapshot}=setup(),before=JSON.stringify(snapshot);p.consume(snapshot);for(const t of [0,280,280,620,620,1000,1001,1701])p.draw(canvas,snapshot,t);p.consume(snapshot);p.draw(canvas,snapshot,2000);p.stop();assert.deepEqual(heard,['BATTLE_02_THROW','CAPTURE_ABSORB_CANDIDATE','CAPTURE_LAND_SHAKE_CANDIDATE','BATTLE_05_CAPTURE_FAIL']);assert.equal(JSON.stringify(snapshot),before);assert.equal(p.busy,false);
});
test('restore, stop and frame stalls do not replay past phase sounds',()=>{
 for(const mode of ['restore','stop','stall']){const {p,heard,canvas,snapshot}=setup();p.consume(snapshot,mode==='restore'?{restoring:true}:{});p.draw(canvas,snapshot,0);if(mode==='stop')p.stop();p.draw(canvas,snapshot,1200);assert.deepEqual(heard,mode==='restore'?[]:['BATTLE_02_THROW']);p.stop()}
});
test('two distinct attempts each get one set, reduced motion retains only existing cues',()=>{
 const {p,heard,canvas,snapshot}=setup();p.consume(snapshot);for(const t of [0,280,620,1000,1001,1701])p.draw(canvas,snapshot,t);snapshot.events.push({type:'capture',success:true,ballId:'ecology_ball'});p.consume(snapshot);for(const t of [1800,2080,2420,2800,2801,3701])p.draw(canvas,snapshot,t);assert.equal(heard.filter(x=>x==='CAPTURE_ABSORB_CANDIDATE').length,2);assert.equal(heard.filter(x=>x==='CAPTURE_LAND_SHAKE_CANDIDATE').length,2);assert.equal(heard.filter(x=>x==='JINGLE_04_CAPTURE').length,1);p.stop();
 const q=setup(true);q.p.consume(q.snapshot);for(const t of [0,124,200,201,701])q.p.draw(q.canvas,q.snapshot,t);assert.deepEqual(q.heard,['BATTLE_02_THROW','BATTLE_03_SHAKE','BATTLE_05_CAPTURE_FAIL']);q.p.stop();
});
test('playback speed maps phase checkpoints without new timers',()=>{
 for(const speed of [.5,2,4]){const q=setup(false,speed);q.p.consume(q.snapshot);for(const t of [0,280/speed,620/speed,1000/speed])q.p.draw(q.canvas,q.snapshot,t);assert.deepEqual(q.heard,['BATTLE_02_THROW','CAPTURE_ABSORB_CANDIDATE','CAPTURE_LAND_SHAKE_CANDIDATE']);q.p.stop()}
});
test('new routes require capture identity and use existing mute, gesture, suspension and disposal',async()=>{
 const media=[];const transport=createOriginalSfxTransport({createMedia(src){const m={src,play(){media.push(src);return Promise.resolve()},pause(){},addEventListener(){},removeEventListener(){},removeAttribute(){},load(){}};return m}}),r=createOriginalSfxRouting(transport),event=mode=>({channel:'original-sfx-cue',cue:{kind:'sequence',id:'SEQ_CAPTURE',mode}});
 assert.equal(r.hook(event('capture-absorb')),false);transport.setEnabled(true);assert.equal(r.hook(event('capture-absorb')),false);transport.gesture({type:'pointerdown',isTrusted:true});assert.equal(r.hook(event('capture-absorb')),true);assert.equal(r.hook(event('capture-land-shake')),true);assert.equal(media.length,2);transport.setSuspended(true);assert.equal(r.hook(event('capture-absorb')),false);transport.setSuspended(false);transport.setGain(0);assert.equal(r.hook(event('capture-land-shake')),false);transport.setGain(.5);assert.equal(r.hook({channel:'original-sfx-cue',cue:{kind:'sequence',mode:'capture-absorb'}}),false);r.dispose();assert.equal(r.hook(event('capture-absorb')),false);
});

test('actual presentation output and cue completion exactly match stable baseline for success/failure',async()=>{
 const {createBattlePresentation:original}=await import('../../../beta05_forest_growth_merged_candidate_r1/project/dist/native_world_selected_s9_boss_source_r3/source/battle-v3/presentation.mjs');
 for(const reducedMotion of [false,true])for(const success of [false,true]){
  const q=setup(reducedMotion);q.snapshot.events[0].success=success;const old=original({drawSpecies:()=>({}),audio:{emit(){}},reducedMotion});q.p.consume(q.snapshot);old.consume(q.snapshot);
  for(let t=0;t<=2100;t+=10){assert.deepEqual(q.p.draw(q.canvas,q.snapshot,t),old.draw(q.canvas,q.snapshot,t));assert.equal(q.p.busy,old.busy)}q.p.stop();old.stop();
 }
});
