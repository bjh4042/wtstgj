import test from 'node:test';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
import {appendOrdinaryPlayHelp} from '../dist/native_world_selected_s9_boss_source_r3/source/ui/ordinary-play-help.mjs';
import {installOrdinaryOriginalSfx} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/ordinary-original-sfx.mjs';
import {createAudioHooks} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/audio-hooks.mjs';
import {createBattlePresentation} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/presentation.mjs';
import {moveProjectileTrail} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-projectile-trail.mjs';
import {MOVE_ANIMATION_PROFILES} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation-profiles.mjs';

// Stub DOM, canvas and audio only. This is not browser, listening or full-play QA.
for (const outcome of ['fled','lost']) test(`help, projectile rendering and ${outcome} audio coexist without changing state`,async()=>{
 const {document,window}=parseHTML('<html><body><main><button>메뉴</button></main></body></html>');
 const root=document.querySelector('main'),button=root.querySelector('button'),hooks=createAudioHooks();
 const effects=[],bgm=[];let writes=0,depth=0;
 class Media {
  constructor(src,list){this.src=src;this.playing=false;list.push(this)}
  play(){this.playing=true;return Promise.resolve()}
  pause(){this.playing=false}
  addEventListener(){} removeEventListener(){} removeAttribute(){} load(){}
 }
 const previous=globalThis.Audio;globalThis.Audio=class extends Media {constructor(src){super(src,bgm)}};
 const audio=installOrdinaryOriginalSfx({root,document,window,hooks,
  backend:{createMedia:src=>new Media(src,effects),unlock(){},setSuspended(){},dispose(){}},
  storage:{getItem:()=>JSON.stringify({sound:true,sfx:.5}),setItem(){writes++}}});
 const moveId=Object.keys(MOVE_ANIMATION_PROFILES).find(id=>MOVE_ANIMATION_PROFILES[id].type==='water'&&MOVE_ANIMATION_PROFILES[id].target==='opponent'&&MOVE_ANIMATION_PROFILES[id].spread>0);
 assert(moveId,'authored water projectile');
 const snapshot={kind:'wild',active:0,enemyActive:0,phase:'ended',outcome,background:{},
  party:[{instanceId:'ally',speciesId:'ally',hp:20,moves:[]}],opponents:[{instanceId:'enemy',speciesId:'enemy',hp:20}],
  events:[{type:'move',moveId,side:'player',instanceId:'ally',targetId:'enemy',hit:true},{type:'damage',targetId:'enemy',actualDamage:12},{type:'end',outcome}]};
 const original=JSON.stringify(snapshot);
 const canvas=new Proxy({globalAlpha:1,save(){depth++},restore(){depth--}},{
  get(target,key){
   if(key in target)return target[key];
   return (...args)=>{
    for(const value of args)if(typeof value==='number')assert(Number.isFinite(value),String(key));
    return {addColorStop(){}};
   };
  }
 });
 const presentation=createBattlePresentation({audio:hooks,drawSpecies:()=>({}),reducedMotion:false});
 try {
  const help=appendOrdinaryPlayHelp(root);assert.match(help.textContent,/PC 백업 파일 만들기/);assert.match(help.textContent,/자동으로 합쳐지지 않아요/);
  assert.equal(effects.length,0);assert.equal(writes,0);
  hooks.emit('bgm.field.coast',{channel:'map-bgm'});
  const gesture=new window.Event('click',{bubbles:true});Object.defineProperty(gesture,'isTrusted',{value:true});button.dispatchEvent(gesture);
  await Promise.resolve();assert.equal(bgm.filter(item=>item.playing).length,1);
  assert.equal(audio.play('UIFIELD_05_MENU'),true);
  presentation.consume(snapshot);let spreadSeen=false;
  for(let now=0;now<10000;now+=16){
   const frame=presentation.draw(canvas,snapshot,now);
   if(frame.moveFrame?.phase==='travel')spreadSeen ||= moveProjectileTrail(MOVE_ANIMATION_PROFILES[moveId],frame.moveFrame).some(p=>p.lateral!==0);
   if(!frame.busy)break;
  }
  assert(spreadSeen,'the real presentation reached nonzero authored trail spread');
  assert.equal(presentation.busy,false);assert.equal(depth,0);
  const role=outcome==='fled'?'BATTLE_16_FLEE_SUCCESS.wav':'BATTLE_17_DEFEAT.wav';
  const names=()=>effects.map(item=>new URL(item.src).pathname.split('/').pop());
  assert.equal(names().filter(name=>name===role).length,1);assert(names().includes('UIFIELD_05_MENU.wav'));
  assert(names().some(name=>name.startsWith('MOVE_')),'existing move sound retained');
  const count=effects.length;presentation.consume(snapshot);presentation.draw(canvas,snapshot,10016);presentation.stop();
  assert.equal(effects.length,count,'no duplicate terminal or cleanup sound');
  const restored=createBattlePresentation({audio:hooks,drawSpecies:()=>({}),reducedMotion:false});
  restored.consume(snapshot,{restoring:true});restored.draw(canvas,snapshot,11000);restored.stop();assert.equal(effects.length,count);
  assert(effects.every(item=>item.volume===.15));assert(audio.state().transport.effects<=4);
  assert.equal(JSON.stringify(snapshot),original);assert.equal(writes,0);
  assert.match(help.textContent,/PC 백업으로 이어하기/);
 } finally {presentation.stop();audio.dispose();globalThis.Audio=previous}
});
