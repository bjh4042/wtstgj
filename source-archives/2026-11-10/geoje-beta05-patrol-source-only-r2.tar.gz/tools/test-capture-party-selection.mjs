import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
import {readFileSync} from 'node:fs';
import * as old from '../../../beta05_gameplay_review_merged_candidate_r1/project/dist/native_world_selected_s9_boss_source_r3/source/ui/capture-party-choice.mjs';
import {appendCapturePartyChoice,capturePartySelection} from '../dist/native_world_selected_s9_boss_source_r3/source/ui/capture-party-choice.mjs';
const offer={instanceId:'new-mon',revision:12};
const runtime={party:Array.from({length:6},(_,i)=>({instanceId:`party-${i}`,speciesId:`species-${i}`,level:5,hp:20})),box:[{instanceId:'new-mon',speciesId:'new',level:4}]};
const catalog={getDisplayName:id=>id};
function fixture(){const {document}=parseHTML('<html><body><div></div></body></html>');return {parent:document.querySelector('div'),offer,runtime,catalog,button(parent,label,fn,disabled){const b=document.createElement('button');b.textContent=label;b.disabled=disabled;b.onclick=fn;parent.append(b);return b},onKeep(){},onSwap(){}};}
function choose(view,id){for(const option of view.select.options)option.removeAttribute('selected');[...view.select.options].find(option=>option.value===id).selected=true;}
test('baseline reproduces selected target loss after rebuilding the same capture offer',()=>{
 const opts=fixture();const first=old.appendCapturePartyChoice(opts);choose(first,'party-4');assert.equal(first.select.value,'party-4');opts.parent.replaceChildren();const second=old.appendCapturePartyChoice(opts);assert.notEqual(second.select.value,'party-4');
});
test('same offer and revision retain the exact chosen target and swap callback after rebuild',()=>{
 const opts=fixture(),calls=[];opts.onSwap=id=>calls.push(id);const first=appendCapturePartyChoice(opts);choose(first,'party-4');const savedSelection=capturePartySelection(opts.parent);opts.parent.replaceChildren();const second=appendCapturePartyChoice({...opts,savedSelection});assert.equal(second.select.value,'party-4');assert.match(second.detail.textContent,/species-4/);second.swap.onclick();assert.deepEqual(calls,['party-4']);
});
test('locked error/retry renders preserve selection without invoking actions or mutating save data',()=>{
 const opts=fixture(),before=JSON.stringify(runtime),calls=[];opts.onSwap=id=>calls.push(id);const first=appendCapturePartyChoice(opts);choose(first,'party-2');for(const disabled of [true,false,true,false]){const savedSelection=capturePartySelection(opts.parent);opts.parent.replaceChildren();const view=appendCapturePartyChoice({...opts,disabled,savedSelection});assert.equal(view.select.value,'party-2');assert.equal(view.select.disabled,disabled);if(disabled)view.swap.onclick();}assert.deepEqual(calls,[]);assert.equal(JSON.stringify(runtime),before);
});
test('new offer, revision or removed party identity cannot inherit stale selection',()=>{
 const opts=fixture(),savedSelection={instanceId:'new-mon',revision:'12',partyInstanceId:'party-3'};
 for(const saved of [{...savedSelection,instanceId:'other'},{...savedSelection,revision:'13'},{...savedSelection,partyInstanceId:'removed'}]){opts.parent.replaceChildren();const view=appendCapturePartyChoice({...opts,savedSelection:saved});assert.notEqual(view.select.value,saved.partyInstanceId);}
});
test('missing choices and missing captured instance do not create a selection',()=>{
 const opts=fixture();assert.equal(capturePartySelection(opts.parent),null);assert.equal(appendCapturePartyChoice({...opts,offer:{instanceId:'absent',revision:12}}),null);assert.equal(capturePartySelection(opts.parent),null);
});
test('real entry captures before clearing choices and passes selection to the party view',()=>{
 const source=readFileSync(new URL('../dist/native_world_selected_s9_boss_source_r3/source/world/entry.mjs',import.meta.url),'utf8');
 assert.ok(source.indexOf('capturedSelection=capturePartySelection(box)')<source.indexOf('box.replaceChildren();const near='));assert.ok(source.includes('offer:capturedOffer,savedSelection:capturedSelection,runtime:s'));
});
