import {test} from 'node:test';
import assert from 'node:assert/strict';
import {moveHitReaction} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-hit-reaction.mjs';
import {MOVE_ANIMATION_PROFILES} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation-profiles.mjs';
import {buildMoveAnimationPayloads,moveAnimationFrame,drawMoveAnimation} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation.mjs';
import {moveAnimationFrame as originalFrame,buildMoveAnimationPayloads as originalPayloads} from '../../reference/dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation.mjs';

const layout={width:432,height:240,player:{x:115,y:228,size:125},enemy:{x:320,y:145,size:110}};
const close=(actual,expected,message='close')=>assert.ok(Math.abs(actual-expected)<1e-9,`${message}: ${actual} vs ${expected}`);
const zero={x:0,y:0};
const ids=Object.keys(MOVE_ANIMATION_PROFILES);
function cue(moveId='MV010',side='player',outcome='hit'){
 const event={type:'move',moveId,side,instanceId:'actor',targetId:'target',hit:outcome!=='miss'};
 const following=outcome==='immune'?[{type:'immune'}]:outcome==='miss'?[{type:'miss'}]:[{type:'damage',targetId:'target',actualDamage:outcome==='zero'?0:12}];
 return buildMoveAnimationPayloads(event,following)[0];
}
const elapsedAfter=(active,after)=>active.duration*(active.profile.contact+(1-active.profile.contact)*after);

test('recoil pushes away from either attacker first, makes one small rebound and rests exactly',()=>{
 for(const direction of [-1,1]){
  assert.deepEqual(moveHitReaction({progress:0,direction,power:90}),zero);
  const peak=moveHitReaction({progress:.18,direction,power:90});
  close(peak.x,direction*6);close(peak.y,-1.5);
  const rebound=moveHitReaction({progress:.55,direction,power:90});
  close(rebound.x,-direction*6*.18);
  assert.deepEqual(moveHitReaction({progress:1,direction,power:90}),zero);
 }
});

test('the opposite sides mirror horizontal recoil without reversing the small lift',()=>{
 for(let step=0;step<=1000;step++){
  const progress=step/1000,left=moveHitReaction({progress,direction:-1,power:80}),right=moveHitReaction({progress,direction:1,power:80});
  close(left.x,-right.x);close(left.y,right.y);
  assert.ok(right.x<=7&&right.x>=-7*.18);assert.ok(right.y>=-1.5&&right.y<=0);
 }
});

test('position and velocity settle continuously at contact, peak, rebound and end',()=>{
 const epsilon=1e-6;
 for(const progress of [0,.18,.55,1]){
  const before=moveHitReaction({progress:progress-epsilon,direction:1,power:120});
  const current=moveHitReaction({progress,direction:1,power:120});
  const after=moveHitReaction({progress:progress+epsilon,direction:1,power:120});
  for(const axis of ['x','y']){
   assert.ok(Math.abs(before[axis]-current[axis])<1e-4);
   assert.ok(Math.abs(after[axis]-current[axis])<1e-4);
   assert.ok(Math.abs((after[axis]-current[axis])/epsilon-(current[axis]-before[axis])/epsilon)<.01);
  }
 }
});

test('strength is bounded, responds to authored power, and uses the existing layout scale',()=>{
 for(const direction of [-1,1])for(const progress of [.1,.18,.4,.55,.9]){
  const normal=moveHitReaction({progress,direction,power:60,scale:1});
  const large=moveHitReaction({progress,direction,power:60,scale:2});
  close(large.x,normal.x*2);close(large.y,normal.y*2);
 }
 close(moveHitReaction({progress:.18,direction:1,power:0}).x,3);
 close(moveHitReaction({progress:.18,direction:1,power:30}).x,4);
 close(moveHitReaction({progress:.18,direction:1,power:1000000,scale:1000000}).x,14);
});

test('all authored moves retain exact cues, timing, targets, paths, contact flags and labels',()=>{
 assert.equal(ids.length,118);
 for(const id of ids)for(const side of ['player','opponent'])for(const outcome of ['hit','miss','immune','zero']){
  const active=cue(id,side,outcome),snapshot=JSON.stringify({active,layout});
  for(const t of [0,.1,.3,.61,.62,.7,.82,.99,1,1.1]){
   const before=originalFrame(active,t*active.duration,layout),after=moveAnimationFrame(active,t*active.duration,layout);
   const {offsets:oldOffsets,...oldRest}=before,{offsets:newOffsets,...newRest}=after;
   assert.deepEqual(newRest,oldRest,`${id} ${side} ${outcome} ${t}`);
   if(!before.contact||active.outcome.actualDamage===0)assert.deepEqual(newOffsets,oldOffsets);
  }
  assert.equal(JSON.stringify({active,layout}),snapshot);
 }
});

test('damaging contacts use the recipient side and never move the attacker after contact',()=>{
 for(const side of ['player','opponent']){
  const active=cue('MV010',side),target=side==='player'?'opponent':'player';
  const sampled=moveAnimationFrame(active,elapsedAfter(active,.18),layout);
  assert.equal(sampled.contact,true);
  assert.ok(Math.sign(sampled.offsets[target].x)===(side==='player'?1:-1));
  assert.deepEqual(sampled.offsets[side],zero);
  const atContact=moveAnimationFrame(active,elapsedAfter(active,0),layout);
  assert.deepEqual(atContact.offsets[target],zero);
 }
});

test('misses, immunity, zero damage, reduced motion and finished cues never gain recoil',()=>{
 for(const side of ['player','opponent'])for(const outcome of ['hit','miss','immune','zero']){
  const active=cue('MV010',side,outcome);
  for(const progress of [.03,.18,.55,.9]){
   const regular=moveAnimationFrame(active,elapsedAfter(active,progress),layout);
   if(outcome!=='hit')assert.deepEqual(regular.offsets,{player:zero,opponent:zero});
   const reduced=moveAnimationFrame({...active,reducedMotion:true},100,layout);
   assert.deepEqual(reduced.offsets,{player:zero,opponent:zero});
  }
  for(const time of [active.duration,active.duration*2])assert.deepEqual(moveAnimationFrame(active,time,layout).offsets,{player:zero,opponent:zero});
 }
});

test('result cues and runtime outcome payloads are unchanged',()=>{
 const event={type:'move',moveId:'MV010',side:'opponent',instanceId:'actor',targetId:'target',hit:true};
 const following=[{type:'damage',targetId:'target',actualDamage:12},{type:'status',instanceId:'target',status:'burn'},{type:'heal',instanceId:'actor',amount:3},{type:'recoil',instanceId:'actor',amount:2}];
 const results=buildMoveAnimationPayloads(event,following);
 assert.deepEqual(results,originalPayloads(event,following));
 for(const result of results.slice(1))for(const t of [0,.2,.7,1])assert.deepEqual(moveAnimationFrame(result,result.duration*t,layout),originalFrame(result,result.duration*t,layout));
});

test('canvas renderer keeps context balanced while sampling damaging contacts in both directions',()=>{
 for(const side of ['player','opponent']){
  let depth=0;const c=new Proxy({save(){depth++},restore(){depth--}},{get(target,key){return key in target?target[key]:(...args)=>{for(const value of args)if(typeof value==='number')assert.ok(Number.isFinite(value))}}});
  const active=cue('MV010',side),elapsed=elapsedAfter(active,.18),sampled=moveAnimationFrame(active,elapsed,layout);
  assert.deepEqual(drawMoveAnimation(c,active,elapsed,layout,sampled),sampled);assert.equal(depth,0);
 }
});

test('malformed samples remain finite, bounded and deterministic without mutating inputs',()=>{
 for(const progress of [NaN,Infinity,-Infinity,-10,0,.3,1,10])for(const direction of [NaN,Infinity,-Infinity,-100,0,100]){
  const input=Object.freeze({progress,direction,power:Infinity,scale:NaN});
  const sample=moveHitReaction(input);assert.deepEqual(sample,moveHitReaction(input));
  assert.ok(Number.isFinite(sample.x));assert.ok(Number.isFinite(sample.y));
  assert.ok(Math.abs(sample.x)<=14);assert.ok(sample.y>=-3&&sample.y<=0);
 }
 assert.deepEqual(moveHitReaction(),zero);
});
