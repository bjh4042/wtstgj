import test from'node:test';import assert from'node:assert/strict';import{readFile}from'node:fs/promises';import{parseHTML}from'linkedom';
const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const{mountBeta05Opening}=await import(new URL('ui/beta05-opening-player.mjs',root));
const{openFourBadgeClosing}=await import(new URL('ui/beta05-closing-player.mjs',root));
function setup(){const{document}=parseHTML('<html><body><section id="host"></section></body></html>');let active=document.body;Object.defineProperty(document,'activeElement',{get:()=>active});const make=document.createElement.bind(document);document.createElement=tag=>{const n=make(tag);n.focus=()=>active=n;if(tag==='dialog')n.showModal=()=>{n.open=true};return n};return{document,host:document.getElementById('host')}}
function opening(){const f=setup();let time=0,n=0,done=0;const jobs=new Map,tracks=[];const clock={setTimeout(fn,ms){const id=++n;jobs.set(id,{at:time+ms,fn});return id},clearTimeout(id){jobs.delete(id)}};
const player=mountBeta05Opening({host:f.host,onDone:()=>done++,clock,now:()=>time,audioFactory:()=>{const s={playing:false,pauses:0,disposed:false};tracks.push(s);return{state:s,pause(){s.playing=false;s.pauses++},dispose(){s.disposed=true},playFromGesture(){s.playing=true}}}});
function tick(ms){const end=time+ms;let limit=100;while(jobs.size){const[id,j]=[...jobs].sort((a,b)=>a[1].at-b[1].at)[0];if(j.at>end)break;assert(limit-->0);time=j.at;jobs.delete(id);j.fn()}time=end}
const key=(value,extra={})=>{const e=new f.document.defaultView.Event('keydown',{bubbles:true,cancelable:true});Object.assign(e,{key:value,...extra});f.host.dispatchEvent(e);return e};return{...f,player,jobs,tracks,tick,key,get done(){return done}}}
test('opening places focus on real next button; Escape skips once and pauses audio',()=>{
 const f=opening();try{f.player.play();assert.equal(f.document.activeElement.textContent,'다음');assert.equal(f.host.querySelector('[aria-keyshortcuts=Escape]').textContent,'건너뛰기');const event=f.key('Escape');assert(event.defaultPrevented);assert.equal(f.done,1);assert(f.tracks.at(-1).pauses>0);f.key('Escape');assert.equal(f.done,1)}finally{f.player.dispose()}
});
test('opening Escape ignores IME/modifiers/repeats and detached or disposed owners',()=>{
 const f=opening();f.player.play();for(const patch of [{isComposing:true},{ctrlKey:true},{metaKey:true},{altKey:true},{repeat:true}]){f.key('Escape',patch);assert.equal(f.done,0)}const tab=f.key('Tab');assert.equal(tab.defaultPrevented,false);f.host.remove();f.key('Escape');assert.equal(f.done,0);f.player.dispose();f.key('Escape');assert.equal(f.done,0);
});
test('BFCache suspends exact opening remainder and replay after a hidden retirement is not stuck',()=>{
 const f=opening();try{f.player.play();f.tick(1200);f.document.defaultView.dispatchEvent(new f.document.defaultView.Event('pagehide'));assert.equal(f.player.state.remaining,3000);assert.equal(f.jobs.size,0);f.tick(50000);f.document.defaultView.dispatchEvent(new f.document.defaultView.Event('pageshow'));f.tick(3000);assert.equal(f.player.state.index,1);f.document.defaultView.dispatchEvent(new f.document.defaultView.Event('pagehide'));f.player.hide();f.document.defaultView.dispatchEvent(new f.document.defaultView.Event('pageshow'));f.player.play();assert.equal(f.jobs.size,1)}finally{f.player.dispose()}
});
test('closing return/skip control lives in sticky header, retains tap action and disposes audio',()=>{
 const f=setup();let closed=0,disposed=false;const player=openFourBadgeClosing({host:f.host,readStatus:()=>({enabled:true,version:'0.5',development:true,candidate:true,badgeTarget:4,complete:true,pendingSave:false}),onClose:()=>closed++,clock:{setTimeout:()=>1,clearTimeout(){}},hooks:{emit(){}},audioFactory:()=>({state:{available:true},pause(){},dispose(){disposed=true},playFromGesture(){},setVolume(){}})});
 const exit=f.host.querySelector('.closing-label button');assert(exit);assert.equal(exit.textContent,'탐험 메뉴로');assert(exit.getAttribute('aria-label').includes('건너뛰고'));exit.click();assert.equal(closed,1);assert(disposed);assert(player.state.disposed);
});
test('mobile targets are at least 44px, touch-friendly, focus-visible and skip header respects safe area',async()=>{
 const opening=await readFile(new URL('ui/beta05-opening-style.mjs',root),'utf8'),closing=await readFile(new URL('ui/beta05-closing-style.mjs',root),'utf8');assert(opening.includes('min-height:44px'));assert(opening.includes('min-width:44px'));assert(opening.includes('touch-action:manipulation'));assert(opening.includes(':focus-visible'));assert(closing.includes('position:sticky;top:0'));assert(closing.includes('env(safe-area-inset-top)'));assert(closing.includes('min-height:44px'));assert(closing.includes('touch-action:manipulation'));
});
