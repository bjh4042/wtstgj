#!/usr/bin/env python3
"""Original procedural gameplay SFX. Python standard library only; no samples/ROMs."""
from pathlib import Path
import hashlib
import json
import math
import random
import struct
import wave

RATE = 48000
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'dist/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx'
PUBLIC = ROOT / 'public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx'
TAU = math.tau


def tone(buffer, start, length, frequency, amplitude, overtone=0.12, end_frequency=None):
    """Soft bell with an integral-frequency chirp and click-free envelopes."""
    first = round(start * RATE)
    count = round(length * RATE)
    for i in range(count):
        if first + i >= len(buffer):
            break
        t = i / RATE
        u = i / max(1, count - 1)
        attack = min(1.0, t / 0.008)
        release = min(1.0, (1.0 - u) / 0.12)
        phase = TAU * (frequency * t + 0.5 * ((end_frequency or frequency) - frequency) * t * t / length)
        bell = math.sin(phase) + overtone * math.sin(phase * 2.003) * math.exp(-8 * u)
        buffer[first + i] += amplitude * bell * attack * release * math.exp(-4 * u)


def rustle(buffer, seed, start, length, amplitude, cutoff=0.23):
    rng = random.Random(seed)
    first, count = round(start * RATE), round(length * RATE)
    low, previous = 0.0, 0.0
    for i in range(count):
        if first + i >= len(buffer):
            break
        value = rng.uniform(-1, 1)
        low += cutoff * (value - low)
        high = low - previous
        previous += 0.025 * (low - previous)
        u = i / max(1, count - 1)
        envelope = math.sin(math.pi * u) ** 1.4 * math.exp(-2.2 * u)
        buffer[first + i] += amplitude * high * envelope


def synthesize(role, duration):
    samples = [0.0] * round(duration * RATE)
    if role == 'UIFIELD_14_STEP_GRASS':
        rustle(samples, 1401, 0.0, 0.115, 0.65)
        rustle(samples, 1402, 0.045, 0.105, 0.28, 0.45)
        tone(samples, 0.006, 0.075, 130, 0.075, 0.0, 82)
    elif role == 'UIFIELD_20_RECOVERY':
        for start, frequency, length in [(0, 523.25, 0.28), (0.13, 659.25, 0.28), (0.26, 783.99, 0.29), (0.39, 1046.5, 0.46)]:
            tone(samples, start, length, frequency, 0.18)
        tone(samples, 0.39, 0.46, 523.25, 0.07, 0.04)
        tone(samples, 0.45, 0.35, 1569.75, 0.025, 0.0)
    elif role == 'BATTLE_13_STATUS_CURED':
        tone(samples, 0, 0.18, 420, 0.14, 0.05, 840)
        tone(samples, 0.105, 0.33, 1174.66, 0.14, 0.08)
        tone(samples, 0.17, 0.27, 1567.98, 0.045, 0.0)
    elif role == 'BATTLE_14_MOVE_LEARNED':
        tone(samples, 0, 0.13, 659.25, 0.16)
        tone(samples, 0.105, 0.18, 987.77, 0.15)
        tone(samples, 0.22, 0.34, 1318.51, 0.16)
        tone(samples, 0.22, 0.32, 659.25, 0.06, 0.02)
    elif role == 'BATTLE_15_RESIDUAL_DAMAGE':
        tone(samples, 0, 0.145, 185, 0.18, 0.23, 105)
        rustle(samples, 1501, 0.004, 0.055, 0.14, 0.18)
        tone(samples, 0.055, 0.095, 91, 0.035, 0.0)
    else:
        raise ValueError(role)
    # Match the current effects' approximate RMS without clipping. The existing
    # transport still applies user volume and its 0.30 one-shot attenuation.
    rms = math.sqrt(sum(x * x for x in samples) / len(samples))
    target_rms = 0.085 if 'STEP_' in role or 'RESIDUAL_' in role else 0.10
    scale = min(target_rms / rms, 0.62 / max(abs(x) for x in samples))
    # A final short fade also guarantees exactly silent boundary samples.
    fade = round(0.004 * RATE)
    samples = [x * scale * min(1.0, i / fade, (len(samples) - 1 - i) / fade) for i, x in enumerate(samples)]
    return [round(x * 32767) for x in samples]


DURATIONS = {
    'UIFIELD_14_STEP_GRASS': 0.16,
    'UIFIELD_20_RECOVERY': 0.88,
    'BATTLE_13_STATUS_CURED': 0.46,
    'BATTLE_14_MOVE_LEARNED': 0.58,
    'BATTLE_15_RESIDUAL_DAMAGE': 0.17,
}


def main():
    SOURCE.mkdir(parents=True, exist_ok=True)
    PUBLIC.mkdir(parents=True, exist_ok=True)
    records = []
    for role, duration in DURATIONS.items():
        samples = synthesize(role, duration)
        path = SOURCE / (role + '.wav')
        with wave.open(str(path), 'wb') as output:
            output.setnchannels(1)
            output.setsampwidth(2)
            output.setframerate(RATE)
            output.writeframes(struct.pack('<' + 'h' * len(samples), *samples))
        public = PUBLIC / path.name
        # Keep authoring originals in one place, following this project's local
        # resource-link convention. Packaging must dereference these as usual.
        if not public.exists() and not public.is_symlink():
            import os
            public.symlink_to(os.path.relpath(path, public.parent))
        if public.read_bytes() != path.read_bytes():
            raise RuntimeError('Resource collision: ' + str(public))
        records.append({
            'role': role, 'file': path.name, 'seconds': duration, 'sampleRate': RATE,
            'channels': 1, 'bits': 16, 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'peak': round(max(abs(x) for x in samples) / 32768, 6),
            'rms': round(math.sqrt(sum(x * x for x in samples) / len(samples)) / 32768, 6),
        })
    manifest = {'version': 1, 'provenance': 'Original procedural synthesis for Geoje Monsters; no external samples, music, ROM, or private reference material.', 'generator': 'tools/generate-gameplay-sfx-r2.py', 'assets': records}
    (SOURCE / 'gameplay-sfx-r2-provenance.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
