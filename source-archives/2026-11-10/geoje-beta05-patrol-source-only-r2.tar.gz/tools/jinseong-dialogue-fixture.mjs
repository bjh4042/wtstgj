import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture,memory,deps,load,hash,stable} from './forest-test-fixture.mjs';
const {cellPosition}=await load('world/definition.mjs');
const {createCanonicalCreature}=await load('canonical-session.mjs');
const {GYM,GYM_BINDINGS}=await load('native-connected/jinseong-scene.mjs');
async function runtime(){const a=await fixture();try{const r=a.world.snapshot(),c=a.world.story.contract,p=r.progress;p.completedStages=['PROLOGUE','S1','S2','S3'];const events=new Set(p.completedEvents),trainers=new Set();function addEvent(id){if(events.has(id))return;events.add(id);for(const pre of c.events[id].requiresEvents)addEvent(pre);if(c.events[id].trainerId)trainers.add(c.events[id].trainerId)}for(const stage of p.completedStages){for(const id of c.stages[stage].eventIds)addEvent(id);for(const id of c.stages[stage].requiredTrainerIds)trainers.add(id)}for(const id of trainers)if(c.trainers[id].eventId)addEvent(c.trainers[id].eventId);p.completedEvents=[...events];p.defeatedTrainers=[...trainers];p.flags=Object.fromEntries(Object.values(c.flags).map(f=>[f.id,f.set_by.some(id=>events.has(c.aliases[id]??id))]));p.gymClears=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.id);p.badges=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.badgeId);p.rewardClaims=Object.values(c.rewards).filter(v=>events.has(v.triggerEvent)).map(v=>v.id);p.currentStage='S4';r.position=cellPosition('world:hub:S4',33,3,'up');r.world.mapId=r.position.scene;r.world.visitedMaps.push(r.position.scene);r.party=[createCanonicalCreature(a.world.catalog,'SPECIES_001',100)];return r}finally{a.dispose()}}
const initial=await runtime();
async function gym(options={}){const a=await fixture({initialRuntime:structuredClone(initial),...options});await a.world.interact('gym-entry:4');a.sync();return a}
async function steps(a,d,n){for(let i=0;i<n;i++)await a.moveExterior(d)}
async function open(a){a.exterior.arrival([650,925]);await a.world.interact('puzzle:4:step:1');a.sync();await steps(a,'up',15);assert(a.world.nearby().some(p=>p.id==='puzzle:4'));await a.world.interact('puzzle:4');a.sync()}


export {gym,open,initial,steps};
