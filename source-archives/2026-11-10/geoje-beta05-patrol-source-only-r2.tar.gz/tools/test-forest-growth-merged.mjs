import test from 'node:test';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
import {fixture,deps,memory,load,fs,source,BINDINGS,hash,stable} from './forest-test-fixture.mjs';
const {mountBattleGrowth}=await load('ui/growth/growth-battle-bridge.mjs');
const {createCanonicalCreature}=await load('canonical-session.mjs');
const {nativeSlotKey,SESSION_REVISION}=await load('native-connected/session.mjs');
const {importNativeSave}=await load('native-connected/file-import.mjs');
const {FOREST}=await load('native-connected/forest-plan.mjs');
const previousPrefixes=['unified-native-r1','native-forest-wild-r1','growth-connected-r1'];

async function wild({action='win',failure=false}={}){
 const backing=memory();
 for(const prefix of previousPrefixes)backing.setItem(`geoje.dev.interior-pilot.${prefix}.v1.SLOT_1`,'UNCHANGED-'+prefix);
 let armed=false,failed=false,rolls=0;
 const storage={...backing,setItem(k,v){
  if(armed&&failure&&!failed&&k===nativeSlotKey('SLOT_1')&&JSON.parse(v).data.canonical.encounter.safeStepsRemaining===5){failed=true;throw Error('TEST_MERGED_AFTERMATH_SAVE_FAILURE')}
  backing.setItem(k,v);
 }};
 const seed=await fixture();const runtime=seed.world.snapshot();runtime.party=[createCanonicalCreature(seed.world.catalog,'SPECIES_001',20)];runtime.inventory.ecology_ball=10;seed.dispose();
 const {document}=parseHTML('<html><body><div id="growth"></div></body></html>');
 let session,bridge,before,after,begins=0,finishes=0,settled=false;
 session=await fixture({initialRuntime:runtime,storage,worldOptions:{...deps.worldOptions,rng:()=>{rolls++;return 0},hooks:{
  battleReady(snapshot){
   begins++;assert.equal(snapshot.kind,'wild');before=structuredClone(snapshot);assert(bridge.begin(session.world,begins,snapshot));
   assert.equal(session.world.inputLocked,true);
   for(let i=0;i<150;i++){
    const state=session.world.story.battleSnapshot();if(state.phase==='ended')break;
    const move=state.party[state.active].moves.find(m=>m.pp>0&&session.world.catalog.getMoveById(m.id)?.power>0)??state.party[state.active].moves.find(m=>m.pp>0);
    const command=action==='flee'?{type:'flee'}:action==='capture'?{type:'capture',ballId:'ecology_ball'}:{type:'move',moveId:move?.id??'SYSTEM_STRUGGLE'};
    session.world.actBattle(command);
   }
   after=session.world.story.battleSnapshot();assert.equal(after.phase,'ended');
  },
  battleFinished(outcome){
   finishes++;settled=bridge.settle(session.world,begins,outcome,session.world.story.battleSnapshot());
   assert.equal(bridge.tick(),false,'growth remains hidden before movement/battle operation commits');
   assert.equal(bridge.state.receipt,null);
  }
 }}});
 bridge=mountBattleGrowth({target:document.querySelector('#growth'),getWorld:()=>session.world,ready:()=>true});
 session.exterior.arrival(BINDINGS['area-entry:P_ECO_CENTER_EDGE'].foot);await session.world.interact('area-entry:P_ECO_CENTER_EDGE');session.sync();
 assert.equal(session.world.snapshot().position.scene,FOREST.mapId);session.exterior.arrival([650,150]);
 for(let i=0;i<3;i++)await session.moveExterior('right');armed=true;
 return {session,bridge,document,storage,backing,move:()=>session.moveExterior('right'),get state(){return{before,after,begins,finishes,settled,rolls,failed}},dispose(){bridge.dispose();session.dispose()}};
}

test('merged native grass -> real interactive wild engine -> committed growth, same foot and no UI writes',async()=>{
 const x=await wild();try{
  await x.move();assert.equal(x.state.begins,1);assert.equal(x.state.finishes,1);assert.equal(x.state.after.outcome,'won');assert(x.state.settled);
  assert.deepEqual(x.session.exterior.player,[698,150]);assert.equal(x.session.world.snapshot().position.scene,FOREST.mapId);
  const saved=x.session.world.snapshot(),bytes=[...x.backing.m];assert(x.bridge.tick());
  const row=x.bridge.state.receipt.rows[0];assert.equal(row.gained,saved.party[0].totalExp-x.state.before.party[0].totalExp);assert(row.gained>0);
  assert.equal(row.toLevel,saved.party[0].level);assert.equal(x.session.world.snapshot().encounter.safeStepsRemaining,5);
  x.document.querySelector('.eco-growth-close').click();for(let i=0;i<5;i++)assert.equal(x.bridge.tick(),false);x.document.querySelector('.eco-growth-reopen').click();
  assert.deepEqual(x.session.world.snapshot(),saved);assert.deepEqual([...x.backing.m],bytes);
  for(const prefix of previousPrefixes)assert.equal(x.storage.getItem(`geoje.dev.interior-pilot.${prefix}.v1.SLOT_1`),'UNCHANGED-'+prefix);
 }finally{x.dispose()}
});

test('real wild victory waits through failed persistence and one retry, with no reroll or duplicated growth',async()=>{
 const x=await wild({failure:true});try{
  await assert.rejects(x.move(),/TEST_MERGED_AFTERMATH_SAVE_FAILURE/);assert(x.state.failed);assert(x.session.world.story.pendingCommit);assert.equal(x.bridge.tick(),false);
  const rolls=x.state.rolls;await x.session.world.story.retryCommit();x.session.world.syncField();x.session.sync();
  assert.equal(x.state.begins,1);assert.equal(x.state.finishes,1);assert.equal(x.state.rolls,rolls);assert.deepEqual(x.session.exterior.player,[698,150]);
  assert(x.bridge.tick());const receipt=x.bridge.state.receipt;assert.equal(receipt.rows[0].gained,x.session.world.snapshot().party[0].totalExp-x.state.before.party[0].totalExp);
  for(let i=0;i<5;i++)assert.equal(x.bridge.tick(),false);assert.equal(x.bridge.state.receipt,receipt);
 }finally{x.dispose()}
});

test('real wild flee has no growth, capture shows only awarded EXP; native return, ball and party remain canonical',async()=>{
 for(const action of ['flee','capture']){
  const x=await wild({action});try{
   const before=x.session.world.snapshot();await x.move();assert.equal(x.state.begins,1);assert.equal(x.state.finishes,1);assert.equal(x.state.after.outcome,action==='flee'?'fled':'captured');
   assert.deepEqual(x.session.exterior.player,[698,150]);
   const after=x.session.world.snapshot();if(action==='capture'){assert.equal(after.captureHistory.entries.length,1);assert.equal(after.captureHistory.entries[0].speciesId,after.party.at(-1).speciesId);assert.equal(after.captureHistory.entries[0].mapId,FOREST.mapId)}else assert.equal(after.captureHistory,undefined);const gained=after.party[0].totalExp-before.party[0].totalExp;
   assert.equal(x.bridge.tick(),gained>0);if(gained>0)assert.equal(x.bridge.state.receipt.rows[0].gained,gained);else assert.equal(x.bridge.state.receipt,null);
   assert.equal(after.party.length,before.party.length+(action==='capture'?1:0));assert.equal(after.inventory.ecology_ball,before.inventory.ecology_ball-(action==='capture'?1:0));
  }finally{x.dispose()}
 }
});

test('merged save and title preferences are isolated; foreign candidate file revisions are rejected read-only',async()=>{
 const x=await wild();try{
  await x.move();await x.session.save();const raw=x.storage.getItem(nativeSlotKey('SLOT_1'));assert.equal(JSON.parse(raw).data.nativeCandidateRevision,SESSION_REVISION);
  const before=[...x.backing.m];
  for(const revision of ['BETA05_UNIFIED_NATIVE_CANDIDATE_R1','BETA05_NATIVE_FOREST_WILD_CANDIDATE_R1','BETA05_GROWTH_CONNECTED_CANDIDATE_R1']){
   const envelope=JSON.parse(raw);envelope.data.nativeCandidateRevision=revision;envelope.sha256=hash(stable(envelope.data));
   assert.throws(()=>importNativeSave({raw:JSON.stringify(envelope),storage:x.storage,slot:'SLOT_2',ownerCurrent:()=>true,dependencies:deps}),/REVISION/);
  }
  assert.deepEqual([...x.backing.m],before);
  const entry=await fs.readFile(new URL('native-connected/game-entry.mjs',source),'utf8');assert(entry.includes('geoje.gameplay-patrol-r1.title.v1'));assert(!entry.includes('geoje.native-forest-wild-r1.title.v1'));
  x.dispose();const resumed=await fixture({storage:x.storage});const bridge=mountBattleGrowth({target:x.document.createElement('div'),getWorld:()=>resumed.world,ready:()=>true});
  assert.equal(bridge.tick(),false);assert.equal(bridge.state.receipt,null);assert.deepEqual(resumed.exterior.player,[698,150]);bridge.dispose();resumed.dispose();
 }finally{x.dispose()}
});
test('capture ledger is acknowledged with capture transaction and retry never adds duplicate or changes its clock',async()=>{const x=await wild({action:'capture',failure:true});try{await assert.rejects(x.move(),/TEST_MERGED_AFTERMATH_SAVE_FAILURE/);assert.equal(x.session.world.snapshot().captureHistory,undefined);await x.session.world.story.retryCommit();const h=structuredClone(x.session.world.snapshot().captureHistory);assert.equal(h.entries.length,1);await x.session.save();assert.deepEqual(x.session.world.snapshot().captureHistory,h);const resumed=await fixture({storage:x.storage});try{assert.deepEqual(resumed.world.snapshot().captureHistory,h)}finally{resumed.dispose()}}finally{x.dispose()}});
