import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash,webcrypto} from 'node:crypto';
import {HouseScene,renderHouse} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/house-scene.mjs';
import {HOUSE_RESIDENTS} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/residents.mjs';
import {loadSelectedHouse} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/load-selected-house.mjs';
import {createNativeHousePort} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/native-pilot/port.mjs';
import {createHouseNativeView} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/native-pilot/view.mjs';
import {APPROVED_NPC_ASSET_IDENTITIES,APPROVED_NPC_FRAMES} from '../dist/native_world_selected_s9_boss_source_r3/source/art/approved-npc-bindings.mjs';

const resources=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/',import.meta.url);
const readBytes=async name=>new Uint8Array(await readFile(new URL(name,resources)));
const sha256=bytes=>createHash('sha256').update(bytes).digest('hex');
const registration=JSON.parse(await readFile(new URL('registration.json',resources),'utf8'));
const safe=Object.fromEntries(await Promise.all(['1F','2F'].map(async floor=>[floor,await readBytes(floor+'-safe.u8')])));
const config={registration,safe,sourceHashes:Object.fromEntries(Object.entries(registration.floors).map(([floor,data])=>[floor,data.sourceSHA]))};
const newScene=options=>new HouseScene({...config,...options});
const state=(floor,foot)=>({revision:registration.revision,floor,foot,transfers:0});
const ART='038580aac4dba41ce4c0712a76bb8977766b5e11b2a0b8507070104ec4b6eafd';
const four=[[1,0],[-1,0],[0,1],[0,-1]];

// Test the actual pixel-foot path, including resident occupancy. No teleport during a walk.
function walk(scene,target){
 const start=scene.snapshot(),width=696,height=464,index=([x,y])=>y*width+x;
 const parent=new Int32Array(width*height).fill(-1),queue=new Int32Array(width*height);
 let read=0,write=1;queue[0]=index(start.foot);parent[queue[0]]=queue[0];
 while(read<write&&parent[index(target)]===-1){
  const current=queue[read++],x=current%width,y=Math.floor(current/width);
  for(const [dx,dy] of four){
   const foot=[x+dx,y+dy];
   if(foot[0]<0||foot[0]>=width||foot[1]<0||foot[1]>=height)continue;
   const next=index(foot);
   if(parent[next]!==-1||!scene.valid({floor:start.floor,foot})||scene.occupied(start.floor,foot))continue;
   parent[next]=current;queue[write++]=next;
  }
 }
 assert.notEqual(parent[index(target)],-1,'destination must remain reachable: '+target);
 const path=[];for(let node=index(target);node!==index(start.foot);node=parent[node])path.push(node);
 for(const node of path.reverse()){
  const before=scene.snapshot().foot;
  assert.equal(scene.move(node%width-before[0],Math.floor(node/width)-before[1]),true);
 }
 assert.deepEqual(scene.snapshot().foot,target);
}

test('selected house bytes still pass every asset pin and install two stationary residents',async()=>{
 const loaded=await loadSelectedHouse({enabled:true,mode:'development',readBytes,sha256});
 try{
  assert.equal(loaded.runtimeApplied,false);
  assert.equal(loaded.scene.residents.length,2);
  assert.deepEqual(loaded.scene.residents.map(n=>n.floor),['1F','2F']);
  for(const n of HOUSE_RESIDENTS){
   assert.equal(n.stationary,true);assert(Object.isFrozen(n)&&Object.isFrozen(n.foot)&&Object.isFrozen(n.dialogue));
   assert.deepEqual(n.topics,['village','game','joke']);assert(n.dialogue.every(line=>typeof line==='string'&&line.length>0));
   assert(loaded.scene.valid({floor:n.floor,foot:n.foot}));
   const identity=APPROVED_NPC_ASSET_IDENTITIES[n.fieldAssetId];assert(identity);assert(APPROVED_NPC_FRAMES[identity+'.FRONT.IDLE']);
  }
  const before=loaded.scene.snapshot(),residents=structuredClone(loaded.scene.residents);
  for(let i=0;i<1000;i++)loaded.scene.tick(i*20);
  assert.deepEqual(loaded.scene.snapshot(),before);assert.deepEqual(loaded.scene.residents,residents);
 }finally{loaded.scene.dispose();}
});

test('walk from entrance to both residents, use both stairs, and return without blocking the door',()=>{
 const scene=newScene();
 try{
  assert.equal(scene.canExit({freshPress:true,direction:'down'}),false);
  walk(scene,[400,329]);assert.equal(scene.talk({facing:'up'}).id,HOUSE_RESIDENTS[0].id);
  walk(scene,registration.floors['1F'].endpoint);
  assert.equal(scene.stairs(),false);assert.equal(scene.stairs({freshPress:true}),true);
  assert.equal(scene.stairs({freshPress:true}),false,'arrival must not immediately return');
  walk(scene,[351,260]);assert.equal(scene.talk({facing:'right'}).id,HOUSE_RESIDENTS[1].id);
  walk(scene,registration.floors['2F'].endpoint);assert.equal(scene.stairs({freshPress:true}),true);
  walk(scene,registration.floors['1F'].exitReadFoot);
  assert.equal(scene.canExit({freshPress:true,direction:'up'}),false);
  assert.equal(scene.canExit({freshPress:true,direction:'down'}),true);
  assert.equal(scene.snapshot().transfers,2);
 }finally{scene.dispose();}
});

for(const resident of HOUSE_RESIDENTS)test(resident.floor+': collision, nearby facing, copies, and stationary restore are enforced',()=>{
 const scene=newScene({state:state(resident.floor,[resident.foot[0]-49,resident.foot[1]])});
 try{
  const before=scene.snapshot();assert.equal(scene.move(1,0),false);assert.deepEqual(scene.snapshot(),before);
  const dialogue=scene.talk({facing:'right'});assert.equal(dialogue.id,resident.id);assert.equal(dialogue.label,resident.label);
  dialogue.lines[0]='MUTATED';assert.equal(scene.talk({facing:'right'}).lines[0],resident.dialogue[0]);
  assert.equal(scene.talk({facing:'left'}),null);for(const facing of ['bad','constructor','__proto__'])assert.equal(scene.talk({facing}),null);
  const restored=newScene({state:scene.snapshot()});assert.deepEqual(restored.snapshot(),scene.snapshot());restored.dispose();
  assert.throws(()=>newScene({state:state(resident.floor,[...resident.foot])}),/HOUSE_STATE_INVALID/);
  scene.blocked=true;assert.equal(scene.talk({facing:'right'}),null);assert.equal(scene.move(-1,0),false);
  scene.blocked=false;scene.dispose();assert.equal(scene.talk({facing:'right'}),null);
 }finally{scene.dispose();}
});

test('distant, different-floor, or furniture-obstructed conversation is not selected',()=>{
 const far=newScene();assert.equal(far.talk(),null);far.dispose();
 const mask=new Uint8Array(safe['1F']);mask[310*696+400]=0;
 const blocked=newScene({safe:{...safe,'1F':mask},state:state('1F',[400,329])});
 assert.equal(blocked.talk({facing:'up'}),null);blocked.dispose();
 const upstairs=newScene({state:state('2F',[351,260])});
 assert.equal(upstairs.talk({facing:'right'}).id,HOUSE_RESIDENTS[1].id);upstairs.dispose();
});

test('native exterior entry, both resident conversations, and exit use the real isolated port',async()=>{
 let scene,owner=true;
 const port=await createNativeHousePort({enabled:true,dev:true,contractBytes:await readBytes('native-pilot/exterior-contract.json'),crypto:webcrypto,ownerCurrent:()=>owner,createHouse:async()=>scene=newScene({ownerCurrent:()=>owner})});
 try{
  assert.deepEqual(port.snapshot().foot,[757,790]);
  for(let y=790;y>719;y--)assert.equal(port.move(0,-1),true);
  assert.equal(await port.enter({freshPress:true,direction:'up',artSHA:ART}),true);
  walk(scene,[400,329]);assert.equal(port.talk({facing:'up'}).id,HOUSE_RESIDENTS[0].id);
  walk(scene,registration.floors['1F'].endpoint);assert.equal(port.stairs({freshPress:true}),true);
  walk(scene,[351,260]);assert.equal(port.talk({facing:'right'}).id,HOUSE_RESIDENTS[1].id);
  port.setBlocked(true);assert.equal(port.talk({facing:'right'}),null);port.setBlocked(false);
  walk(scene,registration.floors['2F'].endpoint);assert.equal(port.stairs({freshPress:true}),true);
  walk(scene,registration.floors['1F'].exitReadFoot);assert.equal(port.exit({freshPress:true,direction:'down'}),true);
  assert.equal(port.snapshot().house,null);assert.deepEqual(port.snapshot().foot,[757,790]);assert.equal(port.snapshot().canonicalApplied,false);
  owner=false;assert.equal(port.move(0,-1),false);assert.equal(port.talk(),null);
 }finally{port.dispose();}
});

function fakeView(){
 const calls={move:[],talk:[],dialogue:[],disposed:0},npc=HOUSE_RESIDENTS[0];let owner=true,blocked=false;
 const port={snapshot:()=>({house:{floor:'1F'}}),setBlocked(){},move:(...args)=>calls.move.push(args),exit:()=>false,stairs:()=>false,talk(input){calls.talk.push(input);return {id:npc.id,label:npc.label,lines:[...npc.dialogue]};},dispose(){calls.disposed++;}};
 const view=createHouseNativeView({port,exterior:{width:4294,height:2400},houseImages:{},drawActor(){},ownerCurrent:()=>owner,isBlocked:()=>blocked,onDialogue:d=>calls.dialogue.push(d)});
 return {view,calls,setOwner:value=>owner=value,setBlocked:value=>blocked=value};
}
const key=(view,key,repeat=false)=>view.keydown({key,repeat,preventDefault(){}});

test('dialogue pages stop movement, avoid key repeats, close and reopen cleanly',async()=>{
 const {view,calls}=fakeView();
 try{
  key(view,'ArrowUp');await view.interact();assert.deepEqual(calls.talk,[{facing:'up'}]);
  assert.equal(view.dialogueSnapshot().index,0);assert.equal(view.dialogueSnapshot().line,HOUSE_RESIDENTS[0].dialogue[0]);
  const snapshot=view.dialogueSnapshot();snapshot.lines[0]='MUTATED';assert.equal(view.dialogueSnapshot().line,HOUSE_RESIDENTS[0].dialogue[0]);
  key(view,'ArrowRight');for(let t=0;t<=500;t+=20)view.tick(t);assert.deepEqual(calls.move,[]);
  key(view,'Enter',true);assert.equal(view.dialogueSnapshot().index,0);
  key(view,'Enter');assert.equal(view.dialogueSnapshot().index,1);assert.equal(calls.talk.length,1);
  key(view,'Escape');assert.equal(view.dialogueSnapshot(),null);assert.equal(calls.dialogue.at(-1),null);
  for(let t=600;t<=800;t+=20)view.tick(t);assert.deepEqual(calls.move,[],'old held movement must not resume');
  await view.interact();assert.equal(view.dialogueSnapshot().index,0);
  for(let i=0;i<HOUSE_RESIDENTS[0].dialogue.length;i++)await view.interact();
  assert.equal(view.dialogueSnapshot(),null);assert.equal(calls.talk.length,2);
  key(view,'ArrowDown');view.tick(900);view.tick(920);assert(calls.move.length>0);
 }finally{view.dispose();}
});

test('hidden or stale view cannot advance, reopen, or move; dispose clears dialogue and input',async()=>{
 const {view,calls,setOwner,setBlocked}=fakeView(),listeners=new Map();
 view.attach({addEventListener:(type,fn)=>listeners.set(type,fn),removeEventListener:(type,fn)=>{if(listeners.get(type)===fn)listeners.delete(type);}});
 await view.interact();setBlocked(true);assert.equal(await view.interact(),false);assert.equal(view.dialogueSnapshot().index,0);
 key(view,'ArrowUp');view.tick(100);assert.equal(calls.move.length,0);
 setBlocked(false);await view.interact();assert.equal(view.dialogueSnapshot().index,1);
 setOwner(false);assert.equal(await view.interact(),false);assert.equal(key(view,'Enter'),false);
 view.dispose();assert.equal(view.dialogueSnapshot(),null);assert.equal(calls.dialogue.at(-1),null);assert.equal(listeners.size,0);assert.equal(calls.disposed,1);
 view.dispose();assert.equal(calls.disposed,1);assert.equal(await view.interact(),false);
});

test('house renderer uses only the current floor resident and retains distinct approved art and scale',()=>{
 for(const resident of HOUSE_RESIDENTS){
  const scene=newScene({state:state(resident.floor,registration.floors[resident.floor].arrival)}),drawn=[];
  const g={canvas:{width:960,height:540},save(){},restore(){},clearRect(){},translate(){},scale(){},drawImage(){}};
  renderHouse(g,scene,{'1F':{},'2F':{}},(_,actor)=>drawn.push(actor));
  assert.deepEqual(drawn.filter(a=>a.id!=='player').map(a=>a.id),[resident.id]);
  assert.equal(drawn.find(a=>a.id===resident.id).fieldAssetId,resident.fieldAssetId);
  assert(drawn.every(a=>a.visibleHeight===80));scene.dispose();
 }
});

test('browser entry contains an accessible paged dialogue and remains development-only',async()=>{
 const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
 const html=await readFile(new URL('house-native-pilot.html',root),'utf8');
 const boot=await readFile(new URL('world/internal-interiors/house/native-pilot/browser-boot.mjs',root),'utf8');
 assert.match(html,/<dialog id="resident-dialog" aria-labelledby="resident-name" aria-describedby="resident-line">/);
 assert.match(boot,/residentDialog\.showModal\(\)/);assert.match(boot,/residentDialog\.addEventListener\('cancel'/);
 assert.match(boot,/retired=import\.meta\.env\.DEV!==true/);
 assert.doesNotMatch(boot,/localStorage|sessionStorage|\.save\(/);
});
