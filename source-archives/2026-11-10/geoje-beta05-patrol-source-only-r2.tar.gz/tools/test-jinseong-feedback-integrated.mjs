// Tests the integrated project modules against the preserved pre-integration patrol scene.
import test from 'node:test';
import assert from 'node:assert/strict';
import {createJinseongGateFeedback,drawJinseongGates,drawJinseongInteraction,jinseongPromptState} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/jinseong-feedback.mjs';
import {projectProgress,GATES,MAP} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/jinseong-geometry.mjs';
import {createJinseongScene,GYM_BINDINGS} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/jinseong-scene.mjs';
import {createJinseongScene as originalScene} from '../../jinseong-feedback-integration-r1/preimage/native-connected/jinseong-scene.mjs';
const closed=()=>projectProgress({});
const first=()=>projectProgress({world:{interactions:['puzzle:4:step:1']}});
const complete=()=>projectProgress({world:{puzzles:['gym-switch:4']}});
function context(width=800,height=600){const calls=[];return {calls,canvas:{width,height},save(){calls.push(['save'])},restore(){calls.push(['restore'])},measureText(t){return{width:t.length*13}},...Object.fromEntries(['drawImage','fillRect','strokeRect','fillText','beginPath','arc','fill','stroke','moveTo','lineTo'].map(name=>[name,(...args)=>calls.push([name,...args])]))}}

test('first draw and restored completed saves never replay a gate animation',()=>{
 let time=100;const f=createJinseongGateFeedback({clock:()=>time,reducedMotion:()=>false});
 assert.deepEqual(f.sample(complete()).map(x=>[x.reveal,x.glow]),[[1,0],[1,0],[1,0]]);
 f.reset();assert.deepEqual(f.sample(first()).map(x=>x.reveal),[1,0,0]);
});
test('first existing receipt animates only lower gate, with no restart on repeated draws',()=>{
 let time=0;const f=createJinseongGateFeedback({clock:()=>time,reducedMotion:()=>false});f.sample(closed());
 const p=first(),before=JSON.stringify(p);assert.deepEqual(f.sample(p).map(x=>x.reveal),[0,0,0]);
 time=210;assert.deepEqual(f.sample(p).map(x=>x.reveal),[.5,0,0]);
 time=420;assert.deepEqual(f.sample(p).map(x=>x.reveal),[1,0,0]);
 time=850;assert.equal(f.sample(p)[0].glow,0);assert.equal(JSON.stringify(p),before);
});
test('second existing receipt opens both remaining visual gates at the same time',()=>{
 let time=0;const f=createJinseongGateFeedback({clock:()=>time,reducedMotion:()=>false});f.sample(first());f.sample(complete());
 time=105;const frame=f.sample(complete());assert.equal(frame[0].reveal,1);assert.equal(frame[1].reveal,.25);assert.deepEqual(frame[1],frame[2]);
});
test('reduced motion settles immediately, including when preference changes mid-animation',()=>{
 let reduce=false;const f=createJinseongGateFeedback({clock:()=>100,reducedMotion:()=>reduce});f.sample(closed());f.sample(first());reduce=true;
 assert.deepEqual(f.sample(complete()).map(x=>[x.reveal,x.glow]),[[1,0],[1,0],[1,0]]);
 reduce=false;assert.equal(f.sample(complete())[0].glow,0);
});
test('return to closed state clears old transitions and preserves closed gate crops',()=>{
 let time=0;const f=createJinseongGateFeedback({clock:()=>time,reducedMotion:()=>false});f.sample(first());f.sample(complete());time=1000;
 const ctx=context(),images={closed:'closed',open:'open'};drawJinseongGates(ctx,images,f.sample(closed()));
 assert.equal(ctx.calls.filter(x=>x[0]==='drawImage').length,3);
 GATES.forEach((g,i)=>assert.deepEqual(ctx.calls[i].slice(2,6),[g.rect[0],g.rect[1],g.rect[2]-g.rect[0],g.rect[3]-g.rect[1]]));
});
test('retracting panel draws remain in each original gate rectangle; settled gates draw no overlay',()=>{
 let time=0;const f=createJinseongGateFeedback({clock:()=>time,reducedMotion:()=>false});f.sample(closed());f.sample(complete());time=210;
 const ctx=context();drawJinseongGates(ctx,{closed:'closed'},f.sample(complete()));
 const draws=ctx.calls.filter(x=>x[0]==='drawImage');assert.equal(draws.length,6);
 for(let i=0;i<draws.length;i++){const a=draws[i],g=GATES[Math.floor(i/2)].rect;assert(a[6]>=g[0]);assert(a[6]+a[8]<=g[2]);assert.equal(a[7],g[1]);assert.equal(a[9],g[3]-g[1]);}
 time=900;ctx.calls.length=0;drawJinseongGates(ctx,{closed:'closed'},f.sample(complete()));assert.equal(ctx.calls.length,0);
});
test('interaction cards show two stages and completion, never create a third stage or fake key binding',()=>{
 assert.deepEqual([jinseongPromptState('puzzle:4:step:1',closed()).step,jinseongPromptState('puzzle:4',first()).step],[1,2]);
 assert(jinseongPromptState('puzzle:4:step:1',first()).done);assert(jinseongPromptState('puzzle:4',complete()).done);
 assert.equal(jinseongPromptState('puzzle:4:step:3',complete()).step,0);
 const ctx=context(320,180);drawJinseongInteraction(ctx,{id:'puzzle:4',binding:GYM_BINDINGS['puzzle:4'],label:'방문 확인',origin:[630,590],near:true,progress:first()});
 const texts=ctx.calls.filter(x=>x[0]==='fillText');assert(texts[1][1].includes('Z / Enter · 터치 A'));
 const card=ctx.calls.find(x=>x[0]==='fillRect');assert(card[1]>=8&&card[2]>=8);assert(card[1]+card[3]<=320-8);assert(card[2]+card[4]<=180-8);
 assert.equal(ctx.calls.filter(x=>x[0]==='save').length,ctx.calls.filter(x=>x[0]==='restore').length);
});
test('scene draw uses new prompts while moves, captures, near checks and save validation match patrol',()=>{
 const save={world:{interactions:[],puzzles:[]}},definition={points:Object.fromEntries(Object.entries(GYM_BINDINGS).map(([id,b])=>[id,{...b,mapId:MAP,label:b.label??id}])),maps:{[MAP]:{actors:[]}}};
 const options={definition,snapshot:()=>save,renderer:{jinseong:{drawPose:()=>({origin:[250,486]})}},current:()=>true};
 const old=originalScene(options),updated=createJinseongScene(options);
 function equal(){assert.deepEqual(updated.capture(),old.capture());for(const id of Object.keys(GYM_BINDINGS))assert.equal(updated.near(id),old.near(id));}
 equal();for(let n=0;n<20;n++){old.move('up');updated.move('up');equal()}
 assert(updated.player[1]>=829);
 for(const s of [old,updated])s.arrival([650,925]);save.world.interactions.push('puzzle:4:step:1');
 for(let n=0;n<15;n++){old.move('up');updated.move('up');equal()}
 save.world.puzzles.push('gym-switch:4');for(let n=0;n<36;n++){old.move('up');updated.move('up');equal()}
 assert(updated.player[1]<451);assert(updated.validate(old.capture()));
 updated.arrival([650,750]);const ctx=context();assert(updated.draw(ctx));assert(ctx.calls.some(x=>x[0]==='fillText'&&x[1]==='방문 확인'));
 assert(ctx.calls.some(x=>x[0]==='fillText'&&x[1]==='안내 2/2 · 확인 완료'));
});
