import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const load=p=>import(new URL(p,source));
const {CanonicalWorld}=await load('world/service.mjs');
const {cellPosition,createWorldDefinition}=await load('world/definition.mjs');
const {GRID_HOUSE,VILLAGE_HOUSES,applyGridHouseProposal,prepareGridHouse,createGridHouseController,gridHouseLayers}=await load('world/internal-interiors/house/grid-candidate.mjs');
const {HOUSE_RESIDENTS}=await load('world/internal-interiors/house/residents.mjs');
const {NATIVE_HOUSE_DOORS,validateNativeHouseDoors,nativeDoorHome}=await load('world/internal-interiors/house/native-door-bindings.mjs');
const {createConnectedSession,nativeSlotKey}=await load('native-connected/session.mjs');
const authority=await load('world/interior-pilot-authority.mjs');
const {validateCanonicalStorySave:validateCanonical}=await load('story/save.mjs');
const {validateWorldLocation:validateLocation}=await load('world/state.mjs');
const {sha256:hash,stableJSON:stable}=await load('compatibility/codec.mjs');
const mask=new Uint8Array(await fs.readFile(new URL('../public-resources/native-restoration/main-r2.safe.u8',import.meta.url)));
const configs={},reuse=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/reuse/',import.meta.url);
for(const kind of ['center','shop']){const dir=kind==='center'?'center/assets/':'shop/';configs[kind]={registration:JSON.parse(await fs.readFile(new URL(kind==='center'?'center/layout.json':'shop/REGISTRATION.json',reuse),'utf8')),floor:new Uint8Array(await fs.readFile(new URL(dir+(kind==='center'?'player_floor.u8':'floor.u8'),reuse))),staffFloor:kind==='center'?new Uint8Array(await fs.readFile(new URL(dir+'doctor_support.u8',reuse))):null}}

const {loadApprovedLatestRuntimeAdapter}=await load('compatibility/approved-latest-runtime-adapter.mjs');
const text=dir=>async f=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await fs.readFile(new URL('data/'+dir+'/'+f,source)));
const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:text('canonical-handoff-v1')},stagedOptions:{readStaging:text('staging-20260927')}});
const resources=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/',import.meta.url);
const readBytes=async p=>new Uint8Array(await fs.readFile(new URL(p,resources)));
const sha256=b=>createHash('sha256').update(b).digest('hex');
const prepared=await prepareGridHouse({enabled:true,mode:'development',readBytes,sha256});
const registration=prepared.config.registration;
const options={villageHouseCandidate:true,interiorPilot:true,interiorPilotStages:['PROLOGUE','S2','S3','S4']};
async function runtimeFixture(){
 const seed=new CanonicalWorld({adapter});
 try{
  for(const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER'])await seed.story.runEvent(id);
  const r=seed.snapshot(),c=seed.story.contract,p=r.progress;
  p.completedStages=['PROLOGUE','S1','S2','S3'];
  const events=new Set(p.completedEvents),trainers=new Set();
  function addEvent(id){if(events.has(id))return;events.add(id);for(const prerequisite of c.events[id].requiresEvents)addEvent(prerequisite);if(c.events[id].trainerId)trainers.add(c.events[id].trainerId)}
  for(const stage of p.completedStages){for(const id of c.stages[stage].eventIds)addEvent(id);for(const id of c.stages[stage].requiredTrainerIds)trainers.add(id)}
  for(const id of trainers)if(c.trainers[id].eventId)addEvent(c.trainers[id].eventId);
  p.completedEvents=[...events];p.defeatedTrainers=[...trainers];
  p.flags=Object.fromEntries(Object.values(c.flags).map(f=>[f.id,f.set_by.some(id=>events.has(c.aliases[id]??id))]));
  p.gymClears=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.id);p.badges=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.badgeId);
  p.rewardClaims=Object.values(c.rewards).filter(r=>events.has(r.triggerEvent)).map(r=>r.id);p.currentStage='S4';
  r.position=cellPosition('world:hub:S4',22,11,'up');r.world.mapId=r.position.scene;r.world.visitedMaps.push(r.position.scene);return r;
 }finally{seed.dispose()}
}

const runtime=await runtimeFixture();
function fixture(home=GRID_HOUSE){
 let owned=true,allowed=true,writes=0;const state=structuredClone(runtime);state.position=cellPosition(home.mapId,...home.readCell,'up');state.world.mapId=home.mapId;if(!state.world.visitedMaps.includes(home.mapId))state.world.visitedMaps.push(home.mapId);
 const native=home.stageId==='PROLOGUE',storage={getItem:()=>null,setItem(){writes++;throw Error('UNEXPECTED_SAVE')}};
 const session=native?createConnectedSession({World:CanonicalWorld,worldOptions:options,adapter,initialRuntime:state,configs,storage,key:nativeSlotKey('SLOT_1'),ownerCurrent:()=>owned,authority,validateCanonical,validateLocation,hash,stable,mask,renderer:{drawPose:()=>({origin:[0,0]})},drawNPC(){}}):null;
 const world=session?.world??new CanonicalWorld({adapter,...options,runtime:state,persist(){writes++;throw Error('UNEXPECTED_SAVE')}});
 const face=d=>{if(session){const pose=session.exterior.capture();pose.facing=d;session.exterior.restore(pose)}else world.field.facing=d};
 if(session){validateNativeHouseDoors(session.exterior);session.exterior.arrival(NATIVE_HOUSE_DOORS.find(d=>d.houseId===home.id).foot);face('up')}
 const before=world.snapshot(),nativeBefore=session?.exterior.capture(),messages=[];
 const controller=createGridHouseController({world,prepared,current:()=>owned,canInput:()=>allowed,nativeScene:()=>session?.exterior??null,say:m=>messages.push(m)});
 return {world,session,controller,before,nativeBefore,messages,face,get writes(){return writes},setOwned:v=>owned=v,setAllowed:v=>allowed=v,close(){controller.dispose();session?.dispose();if(!session)world.dispose()}};
}

function walk(c,target){
 const start=c.snapshot(),width=696,height=464,index=([x,y])=>y*width+x,safe=prepared.config.safe[start.floor];
 const occupied=p=>HOUSE_RESIDENTS.some(n=>n.floor===start.floor&&Math.abs(n.foot[0]-p[0])<49&&Math.abs(n.foot[1]-p[1])<37);
 const parent=new Int32Array(width*height).fill(-1),queue=new Int32Array(width*height);let read=0,write=1;queue[0]=index(start.foot);parent[queue[0]]=queue[0];
 while(read<write&&parent[index(target)]===-1){const current=queue[read++],x=current%width,y=Math.floor(current/width);for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const foot=[x+dx,y+dy];if(foot[0]<0||foot[0]>=width||foot[1]<0||foot[1]>=height)continue;const next=index(foot);if(parent[next]!==-1||!safe[next]||occupied(foot))continue;parent[next]=current;queue[write++]=next;}}
 assert.notEqual(parent[index(target)],-1);const path=[];for(let node=index(target);node!==index(start.foot);node=parent[node])path.push(node);
 for(const node of path.reverse()){const before=c.snapshot().foot,dx=node%width-before[0],dy=Math.floor(node/width)-before[1];assert.equal(c.step(dx===1?'right':dx===-1?'left':dy===1?'down':'up'),true);}
 assert.deepEqual(c.snapshot().foot,target);
}
test('all ten new homes fit actual 0.5 maps; points, NPC routes and original objects remain unchanged',async()=>{
 const before=JSON.parse(await fs.readFile(new URL('./fixtures/house-maps-before.json',import.meta.url),'utf8'));
 const def=createWorldDefinition(adapter,options);assert.deepEqual(JSON.parse(JSON.stringify(def.points)),before.points);assert.equal(VILLAGE_HOUSES.length,10);
 for(const [id,base] of Object.entries(before.maps)){
  const m=def.maps[id],homes=VILLAGE_HOUSES.filter(h=>h.mapId===id&&h.stageId!=='PROLOGUE');assert.equal(homes.length,id==='world:hub:PROLOGUE'?0:2);
  for(const key of Object.keys(base).filter(k=>!['tiles','solidObjects'].includes(k)))assert.deepEqual(m[key],base[key],id+':'+key);
  assert.deepEqual(m.solidObjects.slice(0,base.solidObjects.length),base.solidObjects);
  let changed=0;for(let y=0;y<24;y++)for(let x=0;x<40;x++)if(m.tiles[y][x]!==base.tiles[y][x]){changed++;assert(homes.some(h=>x>=h.rect[0]&&x<h.rect[0]+h.rect[2]&&y>=h.rect[1]&&y<h.rect[1]+h.rect[3]));assert.equal(m.tiles[y][x],1)}assert.equal(changed,homes.length*20);
  const q=[m.spawn],reached=new Set([m.spawn.join(',')]);for(let i=0;i<q.length;i++){const [x,y]=q[i];for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const X=x+dx,Y=y+dy,key=X+','+Y;if(X<0||X>=40||Y<0||Y>=24||m.tiles[Y][X]===1||reached.has(key))continue;reached.add(key);q.push([X,Y]);}}
  for(const pid of m.points){const p=def.points[pid];assert(reached.has(p.x+','+p.y),pid)}
  for(const p of Object.values(def.points).filter(p=>p.targetMapId===id))assert(reached.has(p.target.join(',')),p.id);
  for(const h of homes){assert(reached.has(h.readCell.join(',')));assert.equal(h.nativeDoorEquivalent,false);assert.equal(h.residents.length,2);assert(h.residents.every(n=>n.stationary&&n.dialogue.length===6));}
  assert.equal(gridHouseLayers(m).length,homes.length*2);
 }
});
test('all ten doors, twenty residents, stairs and exits work with zero canonical save or progress writes',()=>{
 let visits=0,talks=0;
 for(const home of VILLAGE_HOUSES){const f=fixture(home),c=f.controller;try{
  f.face('down');assert.equal(c.enter(),false);f.face('up');assert(c.enter());assert.equal(c.snapshot().houseId,home.id);assert.equal(c.label,home.label);
  walk(c,[400,330]);c.step('up');assert(c.action());assert.equal(c.snapshot().dialogue.id,home.residents[0].id);assert(f.messages.at(-1).includes(home.residents[0].dialogue[0]));assert.equal(c.step('left'),false);for(const line of home.residents[0].dialogue){assert(f.messages.at(-1).includes(line));assert(c.action())}assert.equal(c.talking,false);talks++;
  walk(c,registration.floors['1F'].endpoint);assert(c.action());assert.equal(c.snapshot().floor,'2F');assert.equal(c.action(),false);
  walk(c,[350,260]);c.step('right');assert(c.action());assert.equal(c.snapshot().dialogue.id,home.residents[1].id);assert(f.messages.at(-1).includes(home.residents[1].dialogue[0]));for(const line of home.residents[1].dialogue){assert(f.messages.at(-1).includes(line));assert(c.action())}assert.equal(c.talking,false);talks++;
  walk(c,registration.floors['2F'].endpoint);assert(c.action());walk(c,[242,350]);c.step('down');assert(c.action());assert.equal(c.active,false);assert.deepEqual(f.world.snapshot(),f.before);assert.equal(f.writes,0);if(f.session)assert.deepEqual(f.session.exterior.capture(),f.nativeBefore);visits++;
 }finally{f.close()}}
 console.log('MINIMAL_EXECUTION '+JSON.stringify({homes:visits,residents:talks,dialogueLines:VILLAGE_HOUSES.flatMap(h=>h.residents).reduce((a,n)=>a+n.dialogue.length,0),canonicalWrites:0}));
});

test('native doors use independent pixel coordinates, preserved image/mask and reachable R2 paths',async()=>{
 const {PROLOGUE_SCENE:R}=await load('native-restoration/r2-scene.mjs');
 assert.equal(sha256(mask),R.maskSHA);assert.equal(sha256(await fs.readFile(new URL('../public-resources/native-restoration/prologue.png',import.meta.url))),R.imageSHA);
 const seen=new Uint8Array(mask.length),queue=new Int32Array(mask.length);let read=0,write=1;queue[0]=R.landing[1]*R.width+R.landing[0];seen[queue[0]]=1;
 while(read<write){const i=queue[read++],x=i%R.width,y=Math.floor(i/R.width);for(const n of [x?i-1:-1,x<R.width-1?i+1:-1,y?i-R.width:-1,y<R.height-1?i+R.width:-1])if(n>=0&&mask[n]===1&&!seen[n]){seen[n]=1;queue[write++]=n}}
 for(const d of NATIVE_HOUSE_DOORS){assert.equal(seen[d.foot[1]*R.width+d.foot[0]],1);assert.equal(d.provenance,'NEW_NATIVE_DOOR_APPROACH_CANDIDATE');const h=VILLAGE_HOUSES.find(h=>h.id===d.houseId);assert.notDeepEqual(d.foot,h.readCell.map(n=>n*48+24))}
});
test('native visit refuses wrong facing, remote, changed pose, pause and lost ownership',()=>{
 const f=fixture(VILLAGE_HOUSES[0]),c=f.controller,n=f.session.exterior;
 try{f.face('down');assert.equal(c.enter(),false);f.face('up');assert(c.enter());c.pause();assert.equal(c.action(),false);assert.equal(c.step('up'),false);c.resume();assert.equal(c.blocked,false);f.setAllowed(false);assert.equal(c.action(),false);assert.equal(c.step('up'),false);f.setAllowed(true);assert.equal(c.blocked,false);
 const original=n.capture();n.arrival([945,560]);assert.equal(c.blocked,true);assert.equal(c.recover(),false);assert.equal(c.step('up'),false);n.restore(original);assert.equal(c.blocked,false);assert(c.recover());assert.equal(f.writes,0);
 n.arrival([945,560]);f.face('up');assert.equal(c.atDoor(),false);assert.equal(c.enter(),false);n.restore(original);assert(c.enter());f.setOwned(false);assert.equal(c.action(),false);assert.equal(c.recover(),false);
 }finally{f.close()}
});
test('R3 namespace never aliases original grid or native R2 saves',async()=>{
 assert.equal(nativeSlotKey('SLOT_1'),'geoje.dev.interior-pilot.gameplay-patrol-r1.v1.SLOT_1');
 assert.notEqual(nativeSlotKey('SLOT_1'),'geoje.dev.interior-pilot.native-prologue-r2.v1.SLOT_1');
 const {BINDING_REVISION}=await load('native-connected/bindings.mjs');assert.equal(BINDING_REVISION,'PROLOGUE_NATIVE_HOUSES_CANDIDATE_R3');
});
test('native render retains original 18 markers and adds exactly two house approach markers',()=>{
 const f=fixture(VILLAGE_HOUSES[0]),rects=[],labels=[];
 const ctx={canvas:{width:960,height:600},save(){},restore(){},fillRect(...args){rects.push(args)},strokeRect(){},fillText(t){labels.push(t)}};
 try{assert(f.session.exterior.draw(ctx));assert.equal(rects.filter(a=>a[2]===24&&a[3]===8).length,2);assert(labels.some(t=>t.includes('장승포 1번집')))}finally{f.close()}
});

test('ordinary and tile-only entry definitions contain no candidate homes without explicit opt-in',()=>{const def=createWorldDefinition(adapter,{...options,villageHouseCandidate:false});for(const map of Object.values(def.maps))assert.equal(map.solidObjects.some(o=>o.assetId==='building.grid-house-proposal'),false)});

test('repeat native visits and X close leave the same outside pose and no writes',()=>{const f=fixture(VILLAGE_HOUSES[1]),c=f.controller;try{for(let i=0;i<3;i++){assert(c.enter());walk(c,[400,330]);c.step('up');assert(c.action());assert(c.talking);assert(c.close());assert.equal(c.talking,false);assert.equal(c.close(),false);assert(c.recover());assert.deepEqual(f.session.exterior.capture(),f.nativeBefore);assert.deepEqual(f.world.snapshot(),f.before)}assert.equal(f.writes,0)}finally{f.close()}});
