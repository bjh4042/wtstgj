import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {townNpcLiveMessage} from '../dist/native_world_selected_s9_boss_source_r3/source/world/town-npc-live-dialogue.mjs';
import {loadApprovedLatestRuntimeAdapter} from '../dist/native_world_selected_s9_boss_source_r3/source/compatibility/approved-latest-runtime-adapter.mjs';
import {CanonicalWorld} from '../dist/native_world_selected_s9_boss_source_r3/source/world/service.mjs';
import {cellPosition,createWorldDefinition} from '../dist/native_world_selected_s9_boss_source_r3/source/world/definition.mjs';
import {createInteriorController} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/entry-pilot/controller.mjs';
import {createInteriorSession} from '../dist/native_world_selected_s9_boss_source_r3/source/beta05-interior-dev/interior-session.mjs';
import * as authority from '../dist/native_world_selected_s9_boss_source_r3/source/world/interior-pilot-authority.mjs';
import {validateCanonicalStorySave as validateCanonical} from '../dist/native_world_selected_s9_boss_source_r3/source/story/save.mjs';
import {validateWorldLocation as validateLocation} from '../dist/native_world_selected_s9_boss_source_r3/source/world/state.mjs';
import {sha256 as hash,stableJSON as stable} from '../dist/native_world_selected_s9_boss_source_r3/source/compatibility/codec.mjs';

const point={kind:'town-npc',stageId:'PROLOGUE',dialogueRole:'shop-customer',dialogueIndex:0,message:'나는 손님이야. 계산은 캐셔에게 부탁해.'};
const policyId='ECONOMY_CAPTURE_APPROVED_V1';
const catalog={economyPolicy:{id:policyId},itemContract:{
 ecology_ball:{id:'ecology_ball',name:'생태볼',pocket:'capture_balls',shop:true,price:200,unlock:'PROLOGUE'},
 affinity_ball:{id:'affinity_ball',name:'친화볼',pocket:'capture_balls',shop:true,price:600,unlock:'BADGE2'},
 geoje_ball:{id:'geoje_ball',name:'거제볼',pocket:'capture_balls',shop:false,price:null}
}};
const save=()=>({economy:{policyId,money:3000},progress:{badges:[]},inventory:{ecology_ball:0,affinity_ball:0,geoje_ball:0}});
const say=(s,c=catalog,p=point)=>townNpcLiveMessage({point:p,save:s,catalog:c});

test('empty inventory advice uses current price, money and exact affordability',()=>{
 const s=save(),before=structuredClone(s);
 assert.match(say(s),/포획용 볼이 없네/);
 assert.match(say(s),/생태볼은 1개에 200/);
 assert.match(say(s),/가진 돈으로 1개를 살 수 있어/);
 assert.ok(say(s).startsWith(point.message+'\n'));
 assert.deepEqual(s,before);
 s.economy.money=200;assert.match(say(s),/1개를 살 수 있어/);
 s.economy.money=199;assert.match(say(s),/소지금이 1 부족해/);assert.doesNotMatch(say(s),/1개를 살 수 있어/);
 s.economy.money=0;assert.match(say(s),/소지금이 200 부족해/);
});
test('all capture-ball types count, including non-shop balls',()=>{
 const s=save();s.inventory.affinity_ball=2;s.inventory.geoje_ball=1;
 assert.match(say(s),/포획용 볼이 모두 3개/);assert.doesNotMatch(say(s),/포획용 볼이 없네/);
 s.inventory.ecology_ball=1;assert.match(say(s),/포획용 볼이 모두 4개/);
});
test('catalog price and name are authoritative; unavailable products are not recommended',()=>{
 const c=structuredClone(catalog);c.itemContract.ecology_ball.price=350;c.itemContract.ecology_ball.name='검증볼';
 assert.match(say(save(),c),/검증볼은 1개에 350/);
 for(const change of [c=>c.itemContract.ecology_ball.shop=false,c=>c.itemContract.ecology_ball.unlock='BADGE2',c=>c.itemContract.ecology_ball.price=null,c=>c.economyPolicy.id=null]){
  const changed=structuredClone(c);change(changed);assert.equal(say(save(),changed),point.message);
 }
});
test('partial, corrupt or unknown inventory does not invent empty-bag advice',()=>{
 for(const change of [s=>delete s.inventory.geoje_ball,s=>s.inventory.ecology_ball=-1,s=>s.inventory.ecology_ball=0.5,s=>s.inventory.ecology_ball=10000,s=>s.inventory.unknown_ball=1,s=>s.economy.money=null,s=>delete s.inventory]){
  const s=save();change(s);assert.equal(say(s),point.message);
 }
 assert.equal(townNpcLiveMessage({point}),point.message);
 assert.equal(townNpcLiveMessage({}),undefined);
});
test('other speakers retain their authored dialogue exactly',()=>{
 for(const change of [{dialogueIndex:1},{dialogueRole:'center-visitor'},{dialogueRole:'house'},{dialogueRole:'outdoor'},{kind:'trainer'}])assert.equal(say(save(),catalog,{...point,...change}),point.message);
});

const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const read=dir=>async file=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await readFile(new URL(`data/${dir}/${file}`,root)));
const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:read('canonical-handoff-v1')},stagedOptions:{readStaging:read('staging-20260927')}});
const stages=['PROLOGUE','S2','S3','S4'];
const definition=createWorldDefinition(adapter,{interiorPilot:true,interiorPilotStages:stages});

for(const stage of stages)test(`${stage}: native talk reads the current snapshot on every conversation`,()=>{
 const map=definition.maps[`world:interior:${stage}:shop`],current=save();
 const npcs=map.actors.filter(a=>definition.points[a.pointId]?.kind==='town-npc');
 const scene={player:[100,160],npcs:[{point:[100,100]},{point:[300,100]}],healing:{pause(){},resume(){}}};
 let snapshots=0;
 const world={map,definition,catalog,busy:false,snapshot(){snapshots++;return current}};
 const controller=createInteriorController({session:{world,scene,sync(){},dispose(){}},assets:{},drawActor(){}});
 try{
  assert.match(controller.beginDialogue(),/포획용 볼이 없네/);
  assert.equal(controller.beginDialogue(),null,'duplicate interaction stays blocked while dialogue is open');
  controller.endDialogue();current.inventory.ecology_ball=1;
  assert.match(controller.beginDialogue(),/포획용 볼이 모두 1개/);controller.endDialogue();
  scene.player=[300,160];assert.equal(controller.beginDialogue(),definition.points[npcs[1].pointId].message);controller.endDialogue();
  scene.player=[900,900];assert.equal(controller.beginDialogue(),null);
  controller.pause();scene.player=[100,160];assert.equal(controller.beginDialogue(),null);controller.resume();
  assert.ok(snapshots>=3);
 }finally{controller.dispose()}
});

test('canonical grid conversation uses live advice without saving or granting items',async()=>{
 const seed=new CanonicalWorld({adapter,beta05:true,interiorPilot:true});let runtime,p;
 try{p=Object.values(seed.definition.points).find(p=>p.mapId==='world:interior:PROLOGUE:shop'&&p.dialogueRole==='shop-customer'&&p.dialogueIndex===0);runtime=seed.snapshot();runtime.position=cellPosition(p.mapId,p.x,p.y+1);runtime.world.mapId=p.mapId;runtime.world.visitedMaps.push(p.mapId)}finally{seed.dispose()}
 let writes=0;const world=new CanonicalWorld({adapter,beta05:true,interiorPilot:true,runtime,persist:async()=>{writes++}});
 try{const before=world.snapshot(),result=await world.interact(p.id);assert.match(result.message,/포획용 볼이 없네/);assert.deepEqual(world.snapshot(),before);assert.equal(writes,0)}finally{world.dispose()}
});

test('real native purchase updates the next conversation and talking does not write storage',async()=>{
 const resource=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/reuse/shop/',import.meta.url);
 const configs={shop:{registration:JSON.parse(await readFile(new URL('REGISTRATION.json',resource))),floor:new Uint8Array(await readFile(new URL('floor.u8',resource)))}};
 const seed=new CanonicalWorld({adapter,beta05:true,interiorPilot:true});let runtime;
 try{const p=seed.definition.points['interior-entry:PROLOGUE:shop'];runtime=seed.snapshot();runtime.position=cellPosition(p.mapId,p.x,p.y)}finally{seed.dispose()}
 const values=new Map;let writes=0;
 const storage={getItem:k=>values.get(k)??null,setItem(k,v){writes++;values.set(k,v)}};
 const session=createInteriorSession({World:CanonicalWorld,worldOptions:{beta05:true},initialRuntime:runtime,adapter,configs,storage,key:'geoje.dev.interior-pilot.beta05.v1.SLOT_1',ownerCurrent:()=>true,authority,validateCanonical,validateLocation,hash,stable});
 const controller=createInteriorController({session,assets:{},drawActor(){}});
 try{
  await session.world.interact('interior-entry:PROLOGUE:shop');session.sync();
  session.scene.player=[180,410];assert.equal(session.scene.support(session.scene.player),true);
  const before=session.world.snapshot(),beforeWrites=writes;
  assert.match(controller.beginDialogue(),/포획용 볼이 없네/);controller.endDialogue();
  assert.deepEqual(session.world.snapshot(),before);assert.equal(writes,beforeWrites);
  session.scene.player=[...session.scene.r.points.counter_front];
  await controller.service({itemId:'ecology_ball',quantity:1,transactionId:'live-dialogue-purchase'});
  const purchased=session.world.snapshot(),purchaseWrites=writes;
  assert.equal(purchased.inventory.ecology_ball,1);assert.equal(purchased.economy.money,before.economy.money-session.world.catalog.itemContract.ecology_ball.price);
  session.scene.player=[180,410];assert.match(controller.beginDialogue(),/포획용 볼이 모두 1개/);controller.endDialogue();
  assert.deepEqual(session.world.snapshot(),purchased);assert.equal(writes,purchaseWrites);
 }finally{controller.dispose()}
});
