import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {parseHTML} from 'linkedom';
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const {mountBeta05Opening}=await import(new URL('ui/beta05-opening-player.mjs',source));
const {OPENING_SCENES,OPENING_SPECIES,OPENING_DURATION_MS}=await import(new URL('ui/beta05-opening-scenes.mjs',source));
const {PRESENTATION_ART}=await import(new URL('world/ending-scenes.mjs',source));
const {setBattleMotionReduced}=await import(new URL('presentation/battle-motion-preference.mjs',source));
const {OPENING_STYLE}=await import(new URL('ui/beta05-opening-style.mjs',source));
function fixture(){
 const {document}=parseHTML('<html><body><section></section></body></html>');
 let visibility='visible',time=0,sequence=0,done=0;const timers=new Map,tracks=[];
 Object.defineProperty(document,'visibilityState',{get:()=>visibility});
 const clock={setTimeout(fn,delay){const id=++sequence;timers.set(id,{at:time+delay,fn});return id},clearTimeout:id=>timers.delete(id)};
 function tick(ms){const end=time+ms;let limit=100;while(timers.size){const [id,job]=[...timers].sort((a,b)=>a[1].at-b[1].at)[0];if(job.at>end)break;assert(limit-->0,'timer loop');time=job.at;timers.delete(id);job.fn()}time=end}
 function audioFactory({onChange}){const record={plays:0,pauses:0,disposed:false,playing:false,pending:false};tracks.push(record);const emit=()=>onChange(record);return {get state(){return record},playFromGesture(){record.plays++;record.playing=true;emit();return Promise.resolve(record)},pause(){record.pauses++;record.playing=false;emit()},dispose(){record.disposed=true;record.playing=false;emit()}}}
 const host=document.querySelector('section'),player=mountBeta05Opening({host,audioFactory,clock,now:()=>time,onDone:()=>done++});
 const button=label=>{const n=[...host.querySelectorAll('button')].find(n=>n.textContent===label);assert(n,'button '+label);return n};
 return {document,host,player,tracks,timers,tick,button,visibility(value){visibility=value;document.dispatchEvent(new document.defaultView.Event('visibilitychange'))},get done(){return done}};
}
test('six distinct scenes total 28.4 seconds and completion occurs only once without autoplay',()=>{
 const f=fixture();try{f.player.play();assert.equal(OPENING_DURATION_MS,28400);assert.equal(new Set(OPENING_SCENES.map(s=>s.id)).size,6);assert.equal(f.timers.size,1);f.tick(28399);assert.equal(f.player.state.index,5);assert.equal(f.done,0);f.tick(1);assert.equal(f.done,1);assert.equal(f.timers.size,0);assert.equal(f.host.hidden,true);f.tick(100000);assert.equal(f.done,1);assert(f.tracks.every(a=>a.plays===0))}finally{f.player.dispose()}
});
test('pause preserves the current frame and exact remaining duration, then resumes in place',()=>{
 const f=fixture();try{f.player.play();f.tick(1300);const shot=f.host.querySelector('.geoje-opening-shot');f.button('일시정지').click();assert.equal(f.player.state.remaining,2900);assert.equal(f.timers.size,0);f.tick(60000);assert.equal(f.player.state.index,0);assert.equal(f.host.querySelector('.geoje-opening-shot'),shot);assert.equal(f.host.querySelector('.geoje-opening-stage').dataset.paused,'true');f.button('계속 보기').click();f.tick(2899);assert.equal(f.player.state.index,0);f.tick(1);assert.equal(f.player.state.index,1)}finally{f.player.dispose()}
});
test('hidden tabs suspend time and animation without rebuilding the shot',()=>{
 const f=fixture();try{f.player.play();f.tick(1700);const shot=f.host.querySelector('.geoje-opening-shot');f.visibility('hidden');assert.equal(f.player.state.remaining,2500);assert.equal(f.timers.size,0);f.tick(20000);f.visibility('visible');assert.equal(f.host.querySelector('.geoje-opening-shot'),shot);f.tick(2500);assert.equal(f.player.state.index,1);f.button('일시정지').click();f.visibility('hidden');f.visibility('visible');assert.equal(f.timers.size,0)}finally{f.player.dispose()}
});
test('skip cancels timers and replay resets pause, scene, media and progress',()=>{
 const f=fixture();try{f.player.play();f.button('다음').click();f.button('일시정지').click();f.button('건너뛰기').click();assert.equal(f.done,1);assert.equal(f.timers.size,0);f.player.play();assert.equal(f.player.state.index,0);assert.equal(f.player.state.paused,false);assert.equal(f.timers.size,1);assert.equal(f.host.querySelectorAll('[data-state=done]').length,0);assert.equal(f.host.querySelectorAll('[data-state=current]').length,1);f.tick(4200);assert.equal(f.player.state.index,1);assert.equal(f.done,1)}finally{f.player.dispose()}
});
test('music is gesture-only and explicit pause/resume preserves the chosen playback state',async()=>{
 const f=fixture();try{f.player.play();const track=f.tracks.at(-1);assert.equal(track.plays,0);f.button('오프닝 음악 재생').click();assert.equal(track.plays,1);f.button('일시정지').click();assert.equal(track.playing,false);f.button('계속 보기').click();assert.equal(track.plays,2);f.button('음악 일시정지').click();f.button('일시정지').click();f.button('계속 보기').click();assert.equal(track.plays,2);f.button('건너뛰기').click();assert.equal(track.playing,false)}finally{f.player.dispose()}
});
test('next respects pause and every scene includes a caption, visible progress, and the intended original actors',()=>{
 const f=fixture();try{f.player.play();f.button('일시정지').click();for(let i=0;i<6;i++){assert.equal(f.player.state.index,i);assert.equal(f.host.querySelector('.geoje-opening-shot').dataset.scene,OPENING_SCENES[i].id);assert.equal(f.host.querySelector('.geoje-opening-caption p').textContent,OPENING_SCENES[i].body);assert.equal(f.host.querySelectorAll('.geoje-opening-actor').length,OPENING_SCENES[i].actors.length);assert.equal(f.host.querySelectorAll('[data-state=done]').length,i);assert.equal(f.timers.size,0);if(i===1){assert.equal(f.host.querySelectorAll('svg.geoje-opening-actor image').length,3)}if(i===3)assert(f.host.querySelector('.opening-explorer'));if(i===5){assert.equal(f.host.querySelector('.geoje-opening-title-region').textContent,'거제도');f.button('시작 메뉴로').click()}else f.button('다음').click()}assert.equal(f.done,1)}finally{f.player.dispose()}
});
test('disposed or hidden presentations never call completion from a stale timer or visibility event',()=>{
 const f=fixture();f.player.play();const stale=[...f.timers.values()][0].fn;f.player.hide();stale();assert.equal(f.done,0);f.player.play();f.player.dispose();f.visibility('hidden');f.visibility('visible');f.tick(100000);f.player.play();assert.equal(f.timers.size,0);assert.equal(f.done,0);assert(f.tracks.every(a=>a.disposed));
});
test('reduced-motion preference disables animation and CSS retains a static explorer frame',()=>{
 const f=fixture();try{setBattleMotionReduced(true);f.player.play();assert.equal(f.host.querySelector('.geoje-opening-stage').dataset.moving,'false');assert.match(OPENING_STYLE,/@media\(prefers-reduced-motion:reduce\)/);assert.match(OPENING_STYLE,/\.opening-walk-0\{opacity:1!important\}/)}finally{setBattleMotionReduced(false);f.player.dispose()}
});
test('all scene art is local and readable; existing species atlas hashes are unchanged',async()=>{
 for(const scene of OPENING_SCENES){assert(scene.duration>=4000);assert(Object.isFrozen(scene));if(!scene.field){const p=PRESENTATION_ART[scene.art].src;assert(p.startsWith('./assets/'));assert((await readFile(new URL(p,source))).length>0)}for(const actor of scene.actors)if(actor.portrait)assert((await readFile(new URL(PRESENTATION_ART[actor.portrait].src,source))).length>0)}
 for(const atlas of Object.values(OPENING_SPECIES)){const bytes=await readFile(new URL(atlas.src,source));assert.equal(createHash('sha256').update(bytes).digest('hex'),atlas.sha256)}
 for(const filename of ['ui/beta05-opening-player.mjs','ui/beta05-opening-style.mjs','ui/beta05-opening-scenes.mjs']){const code=await readFile(new URL(filename,source),'utf8');assert.doesNotMatch(code,/localStorage|sessionStorage|fetch\(|setItem\(|removeItem\(/)}
});
