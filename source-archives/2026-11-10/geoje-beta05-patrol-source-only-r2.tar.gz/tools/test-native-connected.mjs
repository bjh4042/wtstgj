import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url),load=p=>import(new URL(p,source));
const {CanonicalWorld}=await load('world/service.mjs');
const {loadApprovedLatestRuntimeAdapter}=await load('compatibility/approved-latest-runtime-adapter.mjs');
const read=dir=>async f=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await fs.readFile(new URL('data/'+dir+'/'+f,source)));
const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:read('canonical-handoff-v1')},stagedOptions:{readStaging:read('staging-20260927')}});
const {createGameplayReleases}=await load('compatibility/gameplay-release.mjs'),{createBeta05Sessions}=await load('beta05/session.mjs');
const releases=createGameplayReleases({historical:adapter,latest:adapter});
const {createConnectedSession,nativeSlotKey}=await load('native-connected/session.mjs');
const {BINDINGS,MAP}=await load('native-connected/bindings.mjs');
const {S4_WORLD_OPTIONS}=await load('beta05-interior-dev/s4-entry-policy.mjs');
const {validateCanonicalStorySave:validateCanonical}=await load('story/save.mjs');
const {validateWorldLocation:validateLocation}=await load('world/state.mjs');
const {sha256:hash,stableJSON:stable}=await load('compatibility/codec.mjs');
const authority=await load('world/interior-pilot-authority.mjs');
const {PROLOGUE_SCENE:R}=await load('native-restoration/r2-scene.mjs');
const configs={},base=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/reuse/',import.meta.url);
for(const kind of ['center','shop']){const dir=kind==='center'?'center/assets/':'shop/';configs[kind]={registration:JSON.parse(await fs.readFile(new URL(kind==='center'?'center/layout.json':'shop/REGISTRATION.json',base),'utf8')),floor:new Uint8Array(await fs.readFile(new URL(dir+(kind==='center'?'player_floor.u8':'floor.u8'),base))),staffFloor:kind==='center'?new Uint8Array(await fs.readFile(new URL(dir+'doctor_support.u8',base))):null}}
const mask=new Uint8Array(await fs.readFile(new URL('../public-resources/native-restoration/main-r2.safe.u8',import.meta.url)));
const memory=()=>{const m=new Map;return{m,getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v),removeItem:k=>m.delete(k),get length(){return m.size},key:i=>[...m.keys()][i]??null}};
const deps={World:CanonicalWorld,worldOptions:S4_WORLD_OPTIONS,adapter,configs,authority,validateCanonical,validateLocation,hash,stable,mask,renderer:{drawPose:()=>({origin:[0,0]})},drawNPC(){},ownerCurrent:()=>true,key:nativeSlotKey('SLOT_1')};
async function fixture(options={}){const storage=options.storage??memory(),api=createBeta05Sessions(memory(),releases),initialRuntime=(await api.newGame('SLOT_1',{starterId:'SPECIES_001',playerName:'검증',appearance:'boy'})).runtime;return createConnectedSession({...deps,initialRuntime,storage,...options})}

test('all 18 explicit bindings use the pinned R2 component and preserve paired canonical destinations',async()=>{
 assert.equal(createHash('sha256').update(mask).digest('hex'),R.maskSHA);
 const a=await fixture();try{assert.equal(Object.keys(BINDINGS).length,18);assert.equal(Object.values(BINDINGS).filter(b=>b.provenance==='ARCHIVED_SOURCE_ENDPOINT').length,3);const seen=new Uint8Array(mask.length),queue=new Int32Array(mask.length);let r=0,w=0;const initial=R.landing[1]*R.width+R.landing[0];seen[initial]=1;queue[w++]=initial;while(r<w){const n=queue[r++],x=n%R.width,y=Math.floor(n/R.width);for(const next of [x?n-1:-1,x<R.width-1?n+1:-1,y?n-R.width:-1,y<R.height-1?n+R.width:-1])if(next>=0&&mask[next]===1&&!seen[next]){seen[next]=1;queue[w++]=next}}for(const b of Object.values(BINDINGS)){assert.equal(seen[b.foot[1]*R.width+b.foot[0]],1,b.id);if(b.returnFoot)assert.equal(seen[b.returnFoot[1]*R.width+b.returnFoot[0]],1,b.id+' return');}
 const seed=new CanonicalWorld({...S4_WORLD_OPTIONS,villageHouseCandidate:true,adapter,interiorPilot:true});assert.deepEqual(a.world.definition,seed.definition);seed.dispose();
 }finally{a.dispose()}
});
test('native movement, blocked tile movement and canonical counters share one explicit authority',async()=>{
 const a=await fixture();try{await a.save();const before=a.world.snapshot(),foot=a.exterior.player;assert.equal(await a.moveExterior('down'),true);assert.equal(a.exterior.player[1],foot[1]+12);assert.deepEqual(a.world.snapshot().position,before.position);assert.equal(a.world.snapshot().economy.walkedDistance,(before.economy.walkedDistance??0)+12);assert.equal(a.world.snapshot().world.nativePrologueWalkRemainder,12);await assert.rejects(a.world.move('right'),/NATIVE_CONNECTED/);await assert.rejects(a.world.story.worldCommand({type:'native-connected-walk'}),/RECEIPT/)}finally{a.dispose()}
});
test('native event and live resident gift use measured proximity; far and duplicate gift denied',async()=>{
 const a=await fixture();try{await assert.rejects(a.world.interact('event:P00_HOME_START'),/가까이/);a.exterior.arrival([270,575]);await a.world.interact('event:P00_HOME_START');assert(a.world.snapshot().progress.completedEvents.includes('P00_HOME_START'));
 a.exterior.arrival([880,590]);await a.world.interact('event:P01_ECO_CENTER');assert(a.world.snapshot().progress.completedEvents.includes('P01_ECO_CENTER'));
 a.exterior.arrival([1100,597]);const point='town-npc:world:hub:PROLOGUE:2',before=a.world.snapshot().inventory.ecology_ball;await a.world.interact(point);assert.equal(a.world.snapshot().inventory.ecology_ball,before+1);await a.world.interact(point);assert.equal(a.world.snapshot().inventory.ecology_ball,before+1);
 }finally{a.dispose()}
});
for(const kind of ['center','shop'])test(kind+' native door uses original interior and returns to paired native landing across restart',async()=>{
 const storage=memory();storage.setItem('original','unchanged');let a=await fixture({storage}),b;try{a.exterior.arrival([...BINDINGS['interior-entry:PROLOGUE:'+kind].foot]);await a.world.interact('interior-entry:PROLOGUE:'+kind);a.sync();assert.equal(a.scene.kind,kind);assert.equal(a.exterior,null);await a.save();const expected=a.world.snapshot();a.dispose();b=await fixture({storage});assert.deepEqual(b.world.snapshot(),expected);assert.equal(b.scene.kind,kind);b.scene.player=[...b.scene.r.points.entry];b.scene.exitArmed=true;await b.exit({freshPress:true,direction:'down'});assert.equal(b.world.snapshot().position.scene,MAP);assert.deepEqual(b.exterior.player,BINDINGS['interior-entry:PROLOGUE:'+kind].returnFoot);assert.equal(storage.getItem('original'),'unchanged');assert.equal(storage.m.size,2)}finally{a.dispose();b?.dispose()}
});
for(const id of ['area-entry:P_ECO_CENTER_EDGE','area-entry:P_JANGSEUNGPO_COAST'])test(id+' keeps the tile-area destination and returns to the paired native endpoint',async()=>{
 const a=await fixture();try{a.exterior.arrival([...BINDINGS[id].foot]);const p=a.world.definition.points[id];await a.world.interact(id);a.sync();assert.equal(a.world.snapshot().position.scene,p.targetMapId);const reverse=a.world.definition.points[p.reverseId];assert.equal(a.world.nearby().some(p=>p.id===reverse.id),true);await a.world.interact(reverse.id);a.sync();assert.equal(a.world.snapshot().position.scene,MAP);assert.deepEqual(a.exterior.player,BINDINGS[id].returnFoot)}finally{a.dispose()}
});
test('north stage exit retains story gate rather than authorizing progress from native location',async()=>{const a=await fixture();try{a.exterior.arrival([2690,610]);await assert.rejects(a.world.interact('route:PROLOGUE:S1'));assert.equal(a.world.snapshot().position.scene,MAP)}finally{a.dispose()}});
test('paired native pose resumes exactly and old/unsafe/unknown-revision saves fail closed',async()=>{
 const storage=memory();let a=await fixture({storage});a.exterior.arrival([1400,610]);await a.save();const expected=a.exterior.capture();a.dispose();a=await fixture({storage});assert.deepEqual(a.exterior.capture(),expected);a.dispose();const raw=storage.getItem(deps.key);for(const mutate of [n=>n.foot=[1,1],n=>n.bindingRevision='OLD',n=>delete n.patrols]){const e=JSON.parse(raw);mutate(e.data.native);e.sha256=hash(stable(e.data));storage.setItem(deps.key,JSON.stringify(e));await assert.rejects(fixture({storage}),/NATIVE_SAVE/)}
});
test('ordinary tile world remains unaffected when no native owner is installed',async()=>{
 const world=new CanonicalWorld({...S4_WORLD_OPTIONS,adapter,interiorPilot:true});try{const before=world.snapshot().position;await world.move('down');assert.notDeepEqual(world.snapshot().position,before);assert.equal(authority.interiorPointNear(world.host,world.snapshot(),world.definition.points['event:P00_HOME_START']),null)}finally{world.dispose()}
});
for(const outcome of ['won','lost'])test('real rival engine '+outcome+' returns through paired native/interior persistence',async()=>{
 const {createCanonicalCreature}=await load('canonical-session.mjs');let a=await fixture(),b;
 try{for(const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER'])await a.world.story.runEvent(id);
 const runtime=a.world.snapshot(),mon=createCanonicalCreature(a.world.catalog,'SPECIES_001',outcome==='won'?100:5);if(outcome==='lost'){mon.hp=1;for(const move of mon.moves)move.pp=0;}runtime.party=[mon];a.dispose();
 const drive=battle=>{for(let n=0;n<150;n++){const s=battle.snapshot();if(s.phase==='ended')return;const m=s.party[s.active],move=m.moves.find(x=>x.pp>0);battle.act({type:'move',moveId:move?.id??'SYSTEM_STRUGGLE'})}throw Error('TEST_BATTLE_BOUND')};
 const storage=memory();a=await fixture({storage,initialRuntime:runtime,worldOptions:{...S4_WORLD_OPTIONS,battleDriver:drive,rng:()=>.5}});a.exterior.arrival([1540,620]);await a.world.interact('trainer:RIVAL_00');a.sync();
 if(outcome==='won'){assert(a.world.snapshot().progress.defeatedTrainers.includes('RIVAL_00'));assert.deepEqual(a.exterior.player,[1540,620]);}
 else{assert.equal(a.world.snapshot().economy.recovery?.status,'RETURNED_VERIFIED_HOST');assert.equal(a.scene.kind,'center');assert.equal(a.exterior,null)}
 const expected=a.world.snapshot();a.dispose();b=await fixture({storage});assert.deepEqual(b.world.snapshot(),expected);if(outcome==='won')assert.deepEqual(b.exterior.player,[1540,620]);else assert.equal(b.scene.kind,'center');
 }finally{a.dispose();b?.dispose()}
});
test('native .stm restores only its own revision into an empty slot without altering a source',async()=>{
 const {importNativeSave}=await load('native-connected/file-import.mjs'),{encodePCSave,decodePCSave}=await load('beta05-interior-dev/file-save.mjs');const storage=memory(),a=await fixture({storage});await a.save();const raw=storage.getItem(deps.key),file=encodePCSave(raw);a.dispose();
 const destination=memory();destination.setItem('ordinary-original','opaque');importNativeSave({raw:decodePCSave(file),storage:destination,slot:'SLOT_1',ownerCurrent:()=>true,dependencies:deps});assert.equal(destination.getItem(deps.key),raw);assert.equal(destination.getItem('ordinary-original'),'opaque');assert.equal(storage.getItem(deps.key),raw);assert.throws(()=>importNativeSave({raw,storage:destination,slot:'SLOT_1',ownerCurrent:()=>true,dependencies:deps}),/빈/);
 const old=JSON.parse(raw);delete old.data.nativeCandidateRevision;old.sha256=hash(stable(old.data));assert.throws(()=>importNativeSave({raw:JSON.stringify(old),storage:destination,slot:'SLOT_2',ownerCurrent:()=>true,dependencies:deps}),/REVISION/);assert.equal(destination.getItem(nativeSlotKey('SLOT_2')),null);
});
test('save write failure holds native movement until the same canonical commit is retried',async()=>{
 const storage=memory(),a=await fixture({storage});try{await a.save();const original=storage.getItem(deps.key),set=storage.setItem;let denied=true;storage.setItem=(k,v)=>{if(denied)throw Error('SIMULATED_QUOTA');set(k,v)};
 // The store captures methods at creation. Recreate after arming the failure.
 a.dispose();const b=await fixture({storage});try{await assert.rejects(b.moveExterior('down'),/SIMULATED_QUOTA/);assert.equal(b.world.story.pendingCommit,true);const moved=b.exterior.player;await assert.rejects(b.moveExterior('right'),/UNAVAILABLE/);assert.deepEqual(b.exterior.player,moved);assert.equal(storage.getItem(deps.key),original);denied=false;await b.world.story.retryCommit();assert.equal(b.world.story.pendingCommit,false);b.sync();assert.deepEqual(b.exterior.player,moved);assert.equal(b.world.snapshot().world.nativePrologueWalkRemainder,12)}finally{b.dispose()}
 }finally{a.dispose()}
});
test('controller reuses the game clock, respects focus/input and never moves from ordinary tiles',async()=>{
 const {createConnectedController}=await load('native-connected/controller.mjs');const a=await fixture();let current=true,allow=true;const ctrl=createConnectedController({session:a,current:()=>current,canInput:()=>allow,assets:{},drawActor(){}});try{assert.equal(ctrl.exteriorActive,true);const before=a.exterior.player;allow=false;assert.equal(await ctrl.step('down',{now:100}),false);assert.deepEqual(a.exterior.player,before);allow=true;ctrl.pause();assert.equal(await ctrl.step('down',{now:200}),false);ctrl.resume();assert.equal(await ctrl.step('down',{now:300}),true);assert.equal(ctrl.consumeChanged(),true);assert.equal(ctrl.consumeChanged(),false);current=false;assert.equal(ctrl.active,false);assert.equal(await ctrl.step('down',{now:400}),false)}finally{ctrl.dispose();a.dispose()}
});
test('resident patrol endpoints do not seal the original path to any of the five doors',async()=>{
 const a=await fixture();try{for(const phase of [0,15]){const floor=new Uint8Array(mask),points=[[880,570],[1560,620],[1030,600],...Object.values(BINDINGS).filter(b=>b.patrol).map((b,i)=>b.patrol[(phase>>i)&1])];for(const [x,y]of points)for(let Y=y-19;Y<=y+19;Y++)for(let X=x-19;X<=x+19;X++)if(Math.hypot(X-x,Y-y)<20)floor[Y*R.width+X]=0;
 const seen=new Uint8Array(floor.length),queue=new Int32Array(floor.length);let r=0,w=0;queue[w++]=R.landing[1]*R.width+R.landing[0];seen[queue[0]]=1;while(r<w){const n=queue[r++],x=n%R.width,y=Math.floor(n/R.width);for(const k of [x?n-1:-1,x<R.width-1?n+1:-1,y?n-R.width:-1,y<R.height-1?n+R.width:-1])if(k>=0&&floor[k]&&!seen[k]){seen[k]=1;queue[w++]=k}}for(const b of Object.values(BINDINGS).filter(b=>b.returnFoot))assert.equal(seen[b.foot[1]*R.width+b.foot[0]],1,b.id+' phase '+phase);
 }}finally{a.dispose()}
});
