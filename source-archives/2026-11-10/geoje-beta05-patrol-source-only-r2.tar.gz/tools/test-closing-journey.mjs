import test from 'node:test';import assert from 'node:assert/strict';import{readFile}from'node:fs/promises';import{parseHTML}from'linkedom';
const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const {makeClosingJourney,CLOSING_JOURNEYS,CLOSING_JOURNEY_STYLE}=await import(new URL('ui/beta05-closing-journey.mjs',root));
const {CLOSING_SCENES,CLOSING_PARTNERS,CLOSING_DURATION_MS,canShowFourBadgeClosing}=await import(new URL('ui/beta05-closing-scenes.mjs',root));
test('all seven existing story scenes gain original-art staging without changing duration or story',()=>{
 const{document}=parseHTML('<html><body></body></html>');assert.equal(CLOSING_DURATION_MS,29400);assert.equal(Object.keys(CLOSING_JOURNEYS).length,7);
 for(const scene of CLOSING_SCENES){const layer=makeClosingJourney(document,scene),plan=CLOSING_JOURNEYS[scene.id];assert.equal(layer.getAttribute('aria-hidden'),'true');assert.equal(layer.dataset.motion,plan.motion);assert.equal(layer.querySelectorAll('.closing-traveler').length,plan.partners.length);assert.equal(layer.querySelectorAll('.closing-weather i').length,7);for(const [i,img]of [...layer.querySelectorAll('image')].entries())assert.equal(img.getAttribute('href'),CLOSING_PARTNERS[plan.partners[i]].src)}
});
test('water, owl glide, leaf-cat bounds and final companion composition are distinct',()=>{
 assert.equal(CLOSING_JOURNEYS.water.motion,'leap');assert.deepEqual(CLOSING_JOURNEYS.wind.partners,[1]);assert.equal(CLOSING_JOURNEYS.wind.motion,'glide');assert.deepEqual(CLOSING_JOURNEYS.life.partners,[0]);assert.equal(CLOSING_JOURNEYS.life.motion,'bound');assert.deepEqual(CLOSING_JOURNEYS.together.partners,[0,1,2]);assert.equal(CLOSING_JOURNEYS.credits.motion,'rest');
});
test('CSS motion shares existing pause and reduced-motion controls; caption is never hidden in reduced mode',()=>{
 assert(CLOSING_JOURNEY_STYLE.includes('[data-paused=true]'));assert(CLOSING_JOURNEY_STYLE.includes('animation-play-state:paused!important'));assert(CLOSING_JOURNEY_STYLE.includes('prefers-reduced-motion:reduce'));assert(CLOSING_JOURNEY_STYLE.includes('opacity:1!important'));assert(CLOSING_JOURNEY_STYLE.includes('pointer-events:none'));
});
test('new view layer owns no game state, timer, audio, network or save; beta gate remains strict',async()=>{
 const code=await readFile(new URL('ui/beta05-closing-journey.mjs',root),'utf8');for(const forbidden of ['setTimeout(','requestAnimationFrame(','localStorage','fetch(','new Audio(','Math.random('])assert(!code.includes(forbidden));
 const valid={enabled:true,version:'0.5',development:true,candidate:true,badgeTarget:4,complete:true,pendingSave:false};assert(canShowFourBadgeClosing(valid));assert(!canShowFourBadgeClosing({...valid,version:'1.0'}));assert(!canShowFourBadgeClosing({...valid,pendingSave:true}));assert(!canShowFourBadgeClosing({...valid,complete:false}));
 const player=await readFile(new URL('ui/beta05-closing-player.mjs',root),'utf8');assert(player.includes('shot.append(makeClosingJourney(doc,scene))'));assert(player.includes('kind:\'main\''));assert(player.includes('onClose()'));
});
