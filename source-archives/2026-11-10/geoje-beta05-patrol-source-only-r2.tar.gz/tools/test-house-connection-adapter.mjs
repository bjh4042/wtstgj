import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {prepareHouseConnection,HOUSE_CONNECTION} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/connection-adapter.mjs';
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const load=p=>import(new URL(p,source));
const {CanonicalWorld}=await load('world/service.mjs');
const {cellPosition}=await load('world/definition.mjs');
const {loadApprovedLatestRuntimeAdapter}=await load('compatibility/approved-latest-runtime-adapter.mjs');
const text=dir=>async f=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await fs.readFile(new URL('data/'+dir+'/'+f,source)));
const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:text('canonical-handoff-v1')},stagedOptions:{readStaging:text('staging-20260927')}});
const base=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/house/',import.meta.url);
const readBytes=async p=>new Uint8Array(await fs.readFile(new URL(p,base)));
const sha256=b=>createHash('sha256').update(b).digest('hex');
const registration=JSON.parse(await fs.readFile(new URL('registration.json',base),'utf8'));
const exterior=JSON.parse(await fs.readFile(new URL('native-pilot/exterior-contract.json',base),'utf8'));

// Synthetic, validator-accepted S4 unit fixture. This is not a playthrough or a
// real doorway binding: [15,12] is ONLY its unchanged canonical outside anchor.
async function runtimeFixture(){
 const seed=new CanonicalWorld({adapter});
 try{
  for(const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER'])await seed.story.runEvent(id);
  const r=seed.snapshot(),c=seed.story.contract,p=r.progress;
  p.completedStages=['PROLOGUE','S1','S2','S3'];
  const events=new Set(p.completedEvents),trainers=new Set();
  function addEvent(id){if(events.has(id))return;events.add(id);for(const prerequisite of c.events[id].requiresEvents)addEvent(prerequisite);if(c.events[id].trainerId)trainers.add(c.events[id].trainerId)}
  for(const stage of p.completedStages){for(const id of c.stages[stage].eventIds)addEvent(id);for(const id of c.stages[stage].requiredTrainerIds)trainers.add(id)}
  for(const id of trainers)if(c.trainers[id].eventId)addEvent(c.trainers[id].eventId);
  p.completedEvents=[...events];p.defeatedTrainers=[...trainers];
  p.flags=Object.fromEntries(Object.values(c.flags).map(f=>[f.id,f.set_by.some(id=>events.has(c.aliases[id]??id))]));
  p.gymClears=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.id);p.badges=c.gyms.filter(g=>trainers.has(g.id)).map(g=>g.badgeId);
  p.rewardClaims=Object.values(c.rewards).filter(r=>events.has(r.triggerEvent)).map(r=>r.id);p.currentStage='S4';
  r.position=cellPosition('world:hub:S4',15,12,'up');r.world.mapId=r.position.scene;r.world.visitedMaps.push(r.position.scene);return r;
 }finally{seed.dispose()}
}
const runtime=await runtimeFixture();
async function fixture(){
 let owned=true,writes=0;
 const world=new CanonicalWorld({adapter,runtime:structuredClone(runtime),persist(){writes++;throw Error('NO_SAVE_WRITE_ALLOWED')}});
 const before=world.snapshot();
 const connection=await prepareHouseConnection({enabled:true,mode:'development',world,readBytes,sha256,ownerCurrent:()=>owned});
 return {world,before,connection,setOwned:v=>owned=v,get writes(){return writes},close(){connection.dispose();world.dispose()}};
}
function grant({failure=null}={}){
 let current=true,held=true,returns=0;
 const view={mapId:HOUSE_CONNECTION.mapId,spatialMode:'native-pixel',revision:HOUSE_CONNECTION.revision,state:'OPEN',artSHA:exterior.hub.art[0].sha256,foot:[757,719],facing:'up'};
 return {view,get returns(){return returns},setCurrent:v=>current=v,setHeld:v=>held=v,
  current:()=>current,inputHeld:()=>held,readExterior:()=>structuredClone(view),
  returnOutside(request){returns++;assert.deepEqual(request.foot,[757,790]);assert.equal(request.facing,'down');if(failure==='before'){failure=null;throw Error('BEFORE_RETURN')};view.foot=[...request.foot];view.facing=request.facing;held=false;if(failure==='after'){failure=null;throw Error('AFTER_RETURN')};return true}
 };
}
const enter=(connection,lease,checkpoint=null)=>connection.enter({freshPress:true,direction:'up',lease,checkpoint});
function armExit(connection){for(let i=0;i<37;i++)assert.equal(connection.move(0,-1),true);for(let i=0;i<37;i++)assert.equal(connection.move(0,1),true)}

test('off-by-default and asset pin failures never activate or change a canonical save',async()=>{
 assert.equal(await prepareHouseConnection(),null);
 await assert.rejects(prepareHouseConnection({enabled:true}),/DEVELOPMENT/);
 const f=await fixture();try{
  assert.equal(f.connection.runtimeApplied,false);assert.equal(f.connection.active,false);
  await assert.rejects(prepareHouseConnection({enabled:true,mode:'development',world:f.world,ownerCurrent:()=>true,sha256,readBytes:async p=>p.endsWith('exterior-contract.json')?new Uint8Array([1]):readBytes(p)}),/EXTERIOR_PIN/);
  assert.deepEqual(f.world.snapshot(),f.before);assert.equal(f.writes,0);
 }finally{f.close()}
});

test('a grid location or checkpoint alone never grants native household entry',async()=>{
 const f=await fixture();try{
  assert.equal(f.connection.enter({freshPress:true,direction:'up'}),false);
  for(const mutate of [g=>g.view.spatialMode='grid',g=>g.view.foot=[744,600],g=>g.view.artSHA='0'.repeat(64),g=>g.view.facing='down',g=>g.setHeld(false),g=>g.setCurrent(false)]){
   const g=grant();mutate(g);assert.equal(enter(f.connection,g),false);assert.equal(g.returns,0);
  }
  assert.equal(f.connection.enter({freshPress:false,direction:'up',lease:grant()}),false);
  assert.equal(f.connection.enter({freshPress:true,direction:'left',lease:grant()}),false);
  assert.deepEqual(f.world.snapshot(),f.before);assert.equal(f.writes,0);
 }finally{f.close()}
});

test('native entrance, exact normal exit, and canonical snapshot remain separate',async()=>{
 const f=await fixture(),g=grant();try{
  assert.equal(enter(f.connection,g),true);assert.equal(f.connection.snapshot().floor,'1F');
  assert.equal(f.connection.leave({freshPress:true,direction:'down'}),false);
  armExit(f.connection);assert.equal(f.connection.leave({freshPress:true,direction:'up'}),false);
  assert.equal(f.connection.leave({freshPress:true,direction:'down'}),true);
  assert.equal(f.connection.active,false);assert.deepEqual(g.view.foot,[757,790]);assert.equal(g.returns,1);
  assert.deepEqual(f.world.snapshot(),f.before);assert.equal(f.writes,0);
 }finally{f.close()}
});

test('two-floor checkpoint export and resume preserve floor, facing, exit safety and residents',async()=>{
 const f=await fixture(),g=grant();let other;
 try{
  assert.equal(enter(f.connection,g),true);const checkpoint=f.connection.checkpoint();
  checkpoint.data.native.foot=[...registration.floors['1F'].endpoint];
  assert.equal(f.connection.leave({freshPress:true,recover:true}),true);
  assert.equal(enter(f.connection,grant(),checkpoint),true);
  assert.equal(f.connection.stairs({freshPress:false}),false);
  assert.equal(f.connection.stairs({freshPress:true}),true);assert.equal(f.connection.snapshot().floor,'2F');
  const upstairs=f.connection.checkpoint();upstairs.data.native.foot=[351,260];upstairs.facing='right';upstairs.exitArmed=true;
  assert.equal(f.connection.leave({freshPress:true,recover:true}),true);
  assert.equal(enter(f.connection,grant(),upstairs),true);assert.equal(f.connection.talk().id,'gohyeon-house3-upstairs-resident');
  const exported=f.connection.checkpoint();other=await fixture();
  assert.equal(enter(other.connection,grant(),exported),true);assert.deepEqual(other.connection.snapshot(),f.connection.snapshot());
  assert.deepEqual(other.connection.checkpoint(),exported);
  other.connection.setPaused(true);assert.equal(other.connection.move(1,0),false);assert.equal(other.connection.talk(),null);other.connection.setPaused(false);
  assert.equal(other.connection.leave({freshPress:true,recover:true}),true);
  assert.deepEqual(f.world.snapshot(),f.before);assert.deepEqual(other.world.snapshot(),other.before);assert.equal(f.writes+other.writes,0);
 }finally{f.close();other?.close()}
});

test('bad checkpoint, changed canonical owner or lost lease cannot restore, move or return',async()=>{
 const f=await fixture();try{
  assert.equal(enter(f.connection,grant()),true);const checkpoint=f.connection.checkpoint();f.connection.leave({freshPress:true,recover:true});
  const bad=structuredClone(checkpoint);bad.data.native.foot=[0,0];assert.throws(()=>enter(f.connection,grant(),bad),/HOUSE_STATE_INVALID/);
  const changed=structuredClone(checkpoint);changed.data.canonical.revision++;assert.throws(()=>enter(f.connection,grant(),changed),/WORLD_MISMATCH/);
  const g=grant();assert.equal(enter(f.connection,g),true);g.setCurrent(false);
  assert.equal(f.connection.move(0,-1),false);assert.equal(f.connection.stairs({freshPress:true}),false);assert.equal(f.connection.leave({freshPress:true,recover:true}),false);assert.throws(()=>f.connection.checkpoint(),/UNAVAILABLE/);
  g.setCurrent(true);f.setOwned(false);assert.equal(f.connection.move(0,-1),false);f.connection.dispose();assert.equal(g.returns,0);assert.deepEqual(f.world.snapshot(),f.before);assert.equal(f.writes,0);
 }finally{f.close()}
 const f2=await fixture(),g2=grant();try{
  assert.equal(enter(f2.connection,g2),true);const original=f2.world.snapshot.bind(f2.world);f2.world.snapshot=()=>({...original(),revision:original().revision+1});
  assert.equal(f2.connection.move(0,-1),false);assert.equal(f2.connection.leave({freshPress:true,recover:true}),false);assert.equal(g2.returns,0);
 }finally{f2.close()}
});

test('return failure retains the visit and reads an uncertain landing before retrying',async()=>{
 for(const failure of ['before','after']){
  const f=await fixture(),g=grant({failure});try{
   assert.equal(enter(f.connection,g),true);
   assert.throws(()=>f.connection.leave({freshPress:true,recover:true}),/RETURN/);
   assert.equal(f.connection.active,true);assert.equal(f.connection.returnPending,true);assert.equal(f.connection.move(0,-1),false);
   assert.equal(f.connection.leave({freshPress:true,recover:true}),true);
   assert.equal(g.returns,failure==='before'?2:1);assert.equal(f.connection.active,false);assert.deepEqual(f.world.snapshot(),f.before);assert.equal(f.writes,0);
  }finally{f.close()}
 }
});
