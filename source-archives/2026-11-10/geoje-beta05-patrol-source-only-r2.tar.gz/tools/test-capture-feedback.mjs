import {test} from 'node:test';
import assert from 'node:assert/strict';
import * as current from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/capture-animation.mjs';
import * as baseline from '../../reference/capture-animation.mjs';
import {captureFeedbackParticles as particles} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/capture-feedback-particles.mjs';
const layout={width:432,height:240,player:{x:110,y:220,size:100},enemy:{x:325,y:140,size:90}};
const cue=(mode='attempt',reducedMotion=false,ballId='ecology_ball')=>({kind:'sequence',id:'SEQ_CAPTURE',mode,reducedMotion,duration:2000,ballName:'생태볼',event:{ballId}});
const sample=(c,t,l=layout)=>{const frame=current.captureAnimationFrame(c,t*c.duration),ball=current.captureBallGeometry(frame,l);return {frame,ball,parts:particles(c,frame,ball,l)}};
test('all capture frames, actor anchors and ball geometry match baseline at 6006 samples',()=>{
 for(const mode of ['attempt','success','failure'])for(const reduced of [false,true])for(let i=0;i<=1000;i++){
  const c=cue(mode,reduced),t=i/1000,b=baseline.captureAnimationFrame(c,t*c.duration),n=current.captureAnimationFrame(c,t*c.duration);
  assert.deepEqual(n,b);assert.deepEqual(current.captureActorAnchor(layout.enemy,n),baseline.captureActorAnchor(layout.enemy,b));assert.deepEqual(current.captureBallGeometry(n,layout),baseline.captureBallGeometry(b,layout));
 }
});
test('particles require the authoritative phase, success never appears during attempt or failure',()=>{
 for(const mode of ['attempt','success','failure'])for(let i=0;i<=1000;i++){
  const c=cue(mode),{frame,parts}=sample(c,i/1000);
  if(frame.done||mode==='attempt'&&frame.phase!=='absorb'||mode==='failure'&&frame.phase!=='return')assert.equal(parts.length,0);
  for(const p of parts){assert.equal(p.mode,mode==='attempt'?'absorb':mode==='failure'?'release':'success');assert.equal(p.shape==='leaf',mode==='success')}
 }
});
test('absorption converges, release expands, and successful leaves rise',()=>{
 const distance=s=>Math.abs(s.parts[0].y-s.ball.y)/.72;
 assert.ok(distance(sample(cue(),.30))>distance(sample(cue(),.50)));
 assert.ok(distance(sample(cue('failure'),.15))<distance(sample(cue('failure'),.65)));
 assert.ok(sample(cue('success'),.8).parts[0].y<sample(cue('success'),.2).parts[0].y);
 for(const [mode,t] of [['attempt',.28],['attempt',.52],['failure',.12],['failure',.70],['success',0],['success',1]])assert.equal(sample(cue(mode),t).parts.length,0);
});
test('reduced motion, missing inputs, invalid geometry and completed cues emit no new motion',()=>{
 for(const mode of ['attempt','success','failure'])for(const t of [0,.3,.4,.6,.9,1,2])assert.equal(sample(cue(mode,true),t).parts.length,0);
 assert.deepEqual(particles(),[]);const c=cue(),s=sample(c,.4);assert.deepEqual(particles(c,s.frame,{...s.ball,x:NaN},layout),[]);
});
test('finite bounded deterministic samples do not mutate inputs at different viewport sizes',()=>{
 for(const factor of [.65,1,2])for(const mode of ['attempt','success','failure'])for(let i=0;i<=100;i++){
  const l={width:432*factor,height:240*factor,player:{x:110*factor,y:220*factor,size:100*factor},enemy:{x:325*factor,y:140*factor,size:90*factor}},c=cue(mode),s=sample(c,i/100,l),snapshot=JSON.stringify([c,s.frame,s.ball,l]);
  assert.deepEqual(s.parts,particles(c,s.frame,s.ball,l));assert.equal(JSON.stringify([c,s.frame,s.ball,l]),snapshot);
  for(const p of s.parts){for(const key of ['x','y','radius','angle','alpha'])assert.ok(Number.isFinite(p[key]));assert.ok(p.alpha>=0&&p.alpha<=.7);assert.ok(Math.abs(p.x-s.ball.x)<=76);assert.ok(Math.abs(p.y-s.ball.y)<=100)}
 }
});
test('all four ball palettes render with balanced canvas state and unchanged return frame',()=>{
 for(const mode of ['attempt','success','failure'])for(const ballId of ['ecology_ball','affinity_ball','resonance_ball','geoje_ball'])for(const t of [.1,.4,.6,.8,1]){
  let depth=0;const ctx=new Proxy({save(){depth++},restore(){assert.ok(depth>0);depth--}},{get(o,k){return k in o?o[k]:(...args)=>{for(const n of args)if(typeof n==='number')assert.ok(Number.isFinite(n))}}});
  const c=cue(mode,false,ballId);assert.deepEqual(current.drawCaptureAnimation(ctx,c,c.duration*t,layout),baseline.captureAnimationFrame(c,c.duration*t));assert.equal(depth,0);
 }
});
