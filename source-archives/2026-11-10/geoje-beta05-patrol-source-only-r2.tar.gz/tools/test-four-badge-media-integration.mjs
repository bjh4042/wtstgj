import test from 'node:test';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
import {installOrdinaryOriginalSfx} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/ordinary-original-sfx.mjs';
import {createAudioHooks} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/audio-hooks.mjs';

// Only the overlap between closing R1's ordinary-audio change and SFX R2's
// routing is exercised here. Their completed feature suites are not repeated.
test('closing BGM focus preserves all five R2 effects through the actual ordinary-audio wrapper', async () => {
 const {document,window}=parseHTML('<html><body><main><button>음악</button></main></body></html>');
 const root=document.querySelector('main'),button=root.querySelector('button'),hooks=createAudioHooks();
 const bgm=[],effects=[];let writes=0;
 class Media {
  constructor(src,list){this.src=src;this.playing=false;list.push(this)}
  play(){this.playing=true;return Promise.resolve()}
  pause(){this.playing=false}
  addEventListener(){} removeEventListener(){} removeAttribute(){} load(){}
 }
 const previous=globalThis.Audio;globalThis.Audio=class extends Media {constructor(src){super(src,bgm)}};
 const backend={createMedia:src=>new Media(src,effects),unlock(){},setSuspended(){},dispose(){}};
 const audio=installOrdinaryOriginalSfx({root,document,window,hooks,backend,storage:{getItem:()=>JSON.stringify({sound:true,sfx:.5}),setItem(){writes++}}});
 try {
  hooks.emit('bgm.field.coast',{channel:'map-bgm'});
  const gesture=new window.Event('click',{bubbles:true});Object.defineProperty(gesture,'isTrusted',{value:true});button.dispatchEvent(gesture);
  await Promise.resolve();assert.equal(bgm.filter(item=>item.playing).length,1);
  const owner={};hooks.emit('beta05-closing',{channel:'film-presentation',owner,active:true});
  assert.equal(bgm.filter(item=>item.playing).length,0);
  audio.step({moved:true,from:{scene:'field',x:24,y:24},to:{scene:'field',x:72,y:24},map:{grid:48},tileAt:()=>({tallGrass:true})});
  audio.fieldResult({kind:'heal'},{type:'heal'});
  for(const cue of [
   {kind:'status-cured',event:{type:'status-cured',status:'sleep'}},
   {kind:'move-learning',event:{type:'learned-move',moveId:'leaf'}},
   {kind:'residual',event:{type:'residual',status:'poison',amount:2}}
  ])hooks.emit(null,{channel:'original-sfx-cue',cue});
  await Promise.resolve();
  assert.deepEqual(effects.map(item=>new URL(item.src).pathname.split('/').pop()),[
   'UIFIELD_14_STEP_GRASS.wav','UIFIELD_20_RECOVERY.wav','BATTLE_13_STATUS_CURED.wav','BATTLE_14_MOVE_LEARNED.wav','BATTLE_15_RESIDUAL_DAMAGE.wav'
  ]);
  assert.equal(audio.state().transport.effects,4);
  assert(effects.every(item=>item.volume===.15));
  assert.equal(bgm.filter(item=>item.playing).length,0);
  hooks.emit('bgm.field.forest',{channel:'map-bgm'});
  hooks.emit('beta05-closing',{channel:'film-presentation',owner,active:false});
  await Promise.resolve();assert.equal(bgm.filter(item=>item.playing).length,1);
  assert.match(bgm.find(item=>item.playing).src,/ost-06/);assert.equal(writes,0);
 } finally {audio.dispose();globalThis.Audio=previous}
});
