import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import vm from 'node:vm';
import {battleCommandAckRole as ack} from '../dist/native_world_selected_s9_boss_source_r3/source/presentation/battle-command-sfx.mjs';
const before=(kind='wild')=>({kind,phase:'turn',turn:1,active:0,party:[{instanceId:'ally'}],events:[]});
const after=(b,event)=>({...b,turn:b.turn+1,events:[...b.events,event]});
test('wild and trainer/gym use the same neutral acknowledgement for accepted moves and switches',()=>{
 for(const kind of ['wild','trainer']){const b=before(kind);assert.equal(ack({type:'move',moveId:'MV001'},b,after(b,{type:'move',side:'player',moveId:'MV001'})),'UIFIELD_01_CURSOR');assert.equal(ack({type:'switch',index:1},b,after(b,{type:'switch',side:'player',index:1})),'UIFIELD_01_CURSOR')}
});
test('capture acknowledges both outcomes without predicting success; flee requires resolved end',()=>{
 const b=before();for(const success of [false,true])assert.equal(ack({type:'capture',ballId:'ecology_ball'},b,after(b,{type:'capture',ballId:'ecology_ball',success})),'UIFIELD_01_CURSOR');assert.equal(ack({type:'flee'},b,after(b,{type:'end',outcome:'fled'})),'UIFIELD_01_CURSOR');assert.equal(ack({type:'flee'},b,after(b,{type:'end',outcome:'won'})),null)
});
test('invalid, duplicate, ended, trainer capture/flee and already-sounded item commands are silent',()=>{
 const b=before();assert.equal(ack({type:'move',moveId:'MV001'},b,b),null);assert.equal(ack({type:'item'},b,after(b,{type:'item'})),null);assert.equal(ack({type:'move'},{...b,phase:'ended'},after(b,{type:'move',side:'player'})),null);for(const type of ['capture','flee'])assert.equal(ack({type},before('trainer'),after(before('trainer'),{type:'end',outcome:'fled'})),null);assert.equal(ack(null,null,null),null)
});
test('accepted sleep/paralysis turn is neutral confirmation, not a successful-hit sound',()=>{
 const b=before(),a=after(b,{type:'cannot-act',instanceId:'ally'}),snapshot=JSON.stringify([b,a]);assert.equal(ack({type:'move',moveId:'MV001'},b,a),'UIFIELD_01_CURSOR');assert.equal(JSON.stringify([b,a]),snapshot);
});
test('actual patched action closure is once-only, preserves item sound, and suppresses stale/busy/rejected commands',()=>{
 const text=fs.readFileSync(new URL('../dist/native_world_selected_s9_boss_source_r3/source/world/entry.mjs',import.meta.url),'utf8');const start=text.indexOf('act=a=>{'),end=text.indexOf(';if(!visual?.busy)updateBattleHUD',start);assert.ok(start>0&&end>start);const closure=text.slice(start+4,end);
 function run({type='move',busy=false,pending=false,reject=false,stale=false}={}){const b=before(),sounds=[],consumed=[],ctx={battle:b,actionBattle:b,world:null,actionWorld:null,visual:{busy,consume(x){consumed.push(x)}},presentationTail:{pending},battleCommandAckRole:ack,originalSfx:{play(id){sounds.push(id)}},adapter:{moves:{}},render(){},priorEventCount:0};const w={catalog:{itemContract:{}},actBattle(){if(reject)throw Error('rejected');return after(b,type==='item'?{type:'item'}:{type:'move',side:'player',moveId:'MV001'})}};ctx.world=w;ctx.actionWorld=stale?{}:w;const action=vm.runInNewContext('('+closure+')',ctx);try{action({type,moveId:'MV001'});action({type,moveId:'MV001'})}catch(e){assert.equal(e.message,'rejected')}return {sounds,consumed}}
 assert.deepEqual(run().sounds,['UIFIELD_01_CURSOR']);assert.equal(run().consumed.length,1);assert.deepEqual(run({type:'item'}).sounds,['UIFIELD_09_ITEM']);for(const options of [{busy:true},{pending:true},{reject:true},{stale:true}])assert.deepEqual(run(options).sounds,[]);
});
test('integration is limited to import and one post-acceptance acknowledgement',()=>{
 const original=fs.readFileSync(new URL('../../reference/entry.mjs',import.meta.url),'utf8'),changed=fs.readFileSync(new URL('../dist/native_world_selected_s9_boss_source_r3/source/world/entry.mjs',import.meta.url),'utf8');const stripped=changed.replace("import {battleCommandAckRole} from '../presentation/battle-command-sfx.mjs';\n",'').replace('const commandAck=battleCommandAckRole(a,actionBattle,battle);if(commandAck)originalSfx?.play(commandAck);','');assert.equal(stripped,original);
});
