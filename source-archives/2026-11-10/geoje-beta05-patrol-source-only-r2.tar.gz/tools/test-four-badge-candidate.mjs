import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {parseHTML} from 'linkedom';
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const load=p=>import(new URL(p,source));
const {CanonicalWorld}=await load('world/service.mjs');
const {loadApprovedLatestRuntimeAdapter}=await load('compatibility/approved-latest-runtime-adapter.mjs');
const read=dir=>async f=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await fs.readFile(new URL('data/'+dir+'/'+f,source)));
const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:read('canonical-handoff-v1')},stagedOptions:{readStaging:read('staging-20260927')}});
const {createInteriorSession}=await load('beta05-interior-dev/interior-session.mjs');
const authority=await load('world/interior-pilot-authority.mjs');
const {validateCanonicalStorySave:validateCanonical}=await load('story/save.mjs');
const {validateWorldLocation:validateLocation}=await load('world/state.mjs');
const {sha256:hash,stableJSON:stable}=await load('compatibility/codec.mjs');
const {s4TitleStorage,s4SlotKey,S4_WORLD_OPTIONS}=await load('beta05-interior-dev/s4-entry-policy.mjs');
const {listFourBadgeCopySources,readFourBadgeCopySource,importFourBadgeSave}=await load('beta05-interior-dev/four-badge-save-policy.mjs');
const {beta05InteriorKey}=await load('beta05-interior-dev/isolated-entry.mjs');
const {createFileSessionStorage,encodePCSave,decodePCSave}=await load('beta05-interior-dev/file-save.mjs');
const {betaStatus,betaStageAllowed}=await load('world/beta05-scope.mjs');
const {FOUR_BADGE_CANDIDATE:FOUR}=await load('world/beta05-four-badge-profile.mjs');
const {mountBeta05TitleMenu}=await load('ui/beta05-title-menu.mjs');
const {appendBeta05Completion}=await load('ui/beta05-completion.mjs');
const configs={},base=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/reuse/',import.meta.url);
for(const kind of ['center','shop']){const dir=kind==='center'?'center/assets/':'shop/';configs[kind]={registration:JSON.parse(await fs.readFile(new URL(kind==='center'?'center/layout.json':'shop/REGISTRATION.json',base),'utf8')),floor:new Uint8Array(await fs.readFile(new URL(dir+(kind==='center'?'player_floor.u8':'floor.u8'),base))),staffFloor:kind==='center'?new Uint8Array(await fs.readFile(new URL(dir+'doctor_support.u8',base))):null}}
function memory(){const m=new Map;return {m,getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v)}}
const deps={World:CanonicalWorld,adapter,configs,authority,validateCanonical,validateLocation,hash,stable,ownerCurrent:()=>true};
const oldKey=beta05InteriorKey('SLOT_1');
async function fixture(){const storage=memory();const session=createInteriorSession({...deps,worldOptions:{beta05:true},storage,key:oldKey});await session.save();const snapshot=session.world.snapshot();session.dispose();return {storage,raw:storage.getItem(oldKey),snapshot}}
function validate(raw){const session=createInteriorSession({...deps,worldOptions:S4_WORLD_OPTIONS,storage:createFileSessionStorage(raw),key:oldKey});session.dispose()}
const options=(storage,raw,extra={})=>({storage,raw,slot:'SLOT_1',sourceKey:oldKey,validate,ownerCurrent:()=>true,...extra});

test('explicit 1-badge copy preserves every source byte and resumes in the same S4 namespace',async()=>{
 const {storage,raw,snapshot}=await fixture();storage.setItem('ordinary-save','opaque');storage.setItem('geoje.dev.interior-pilot.s2-boundary.v1.SLOT_2','opaque');const before=new Map(storage.m);
 assert.equal(listFourBadgeCopySources(storage).length,2);assert.equal(readFourBadgeCopySource(storage,oldKey),raw);
 assert.equal(importFourBadgeSave(options(storage,raw)),s4SlotKey('SLOT_1'));
 for(const [key,value]of before)assert.equal(storage.getItem(key),value);
 assert.equal(s4TitleStorage(storage).getItem(oldKey),raw);assert.equal(decodePCSave(encodePCSave(raw)),raw);
 const restored=createInteriorSession({...deps,worldOptions:S4_WORLD_OPTIONS,storage,key:s4SlotKey('SLOT_1')});
 assert.deepEqual(restored.world.snapshot(),snapshot);assert.equal(restored.world.host.s4Development,true);restored.dispose();
 assert.equal(storage.m.size,before.size+1);
});
test('occupied target, arbitrary source and damaged input cannot overwrite existing data',async()=>{
 const {storage,raw}=await fixture();storage.setItem(s4SlotKey('SLOT_1'),'damaged target');const before=new Map(storage.m);
 assert.throws(()=>importFourBadgeSave(options(storage,raw)),/빈 저장/);assert.throws(()=>readFourBadgeCopySource(storage,'ordinary-save'),/SCOPE/);
 assert.throws(()=>importFourBadgeSave(options(storage,'invalid',{slot:'SLOT_2'})),/INVALID/);assert.deepEqual(storage.m,before);
});
test('validation failure, lost owner and changed source perform no target write',async()=>{
 for(const failure of ['validation','owner','source']){const {storage,raw}=await fixture();let owner=true;const original=storage.getItem(oldKey);
 const checked=()=>{if(failure==='validation')throw Error('VALIDATION_FAILURE');if(failure==='owner')owner=false;if(failure==='source')storage.setItem(oldKey,raw+' ')};
 assert.throws(()=>importFourBadgeSave(options(storage,raw,{validate:checked,ownerCurrent:()=>owner})),/VALIDATION_FAILURE|ENTRY_RETIRED|SOURCE_CHANGED/);
 assert.equal(storage.getItem(s4SlotKey('SLOT_1')),null);if(failure!=='source')assert.equal(storage.getItem(oldKey),original);
 }
});
test('storage failure preserves originals and never deletes uncertain target writes',async()=>{
 for(const written of [false,true]){const {storage,raw}=await fixture(),set=storage.setItem;storage.setItem=(k,v)=>{if(k===s4SlotKey('SLOT_1')){if(written)set(k,v);throw Error('QUOTA')}set(k,v)};
 assert.throws(()=>importFourBadgeSave(options(storage,raw)),/QUOTA/);assert.equal(storage.getItem(oldKey),raw);assert.equal(storage.getItem(s4SlotKey('SLOT_1')),written?raw:null);
 }
});
test('.stm import uses the same validation and empty-target policy without a browser source',async()=>{
 const {raw}=await fixture(),storage=memory();importFourBadgeSave(options(storage,decodePCSave(encodePCSave(raw)),{sourceKey:undefined}));assert.equal(storage.getItem(s4SlotKey('SLOT_1')),raw);assert.equal(storage.m.size,1);
});
test('four-badge completion requires all four S4 reward signals; first-badge behavior stays unchanged',()=>{
 const s={progress:{completedEvents:['S4_GYM_STORY'],badges:['BADGE_04'],flags:{BADGE_04:true},rewardClaims:['TX_S4_GYM_REWARD']}};
 const view=betaStatus(true,s,false,false,true);assert.equal(view.complete,true);assert.equal(view.title,FOUR.completeTitle);assert.equal(view.badgeTarget,4);assert.match(view.message,/S5 이후/);assert.equal(betaStatus(true,s).complete,false);
 for(const field of ['completedEvents','badges','rewardClaims']){const v=structuredClone(s);v.progress[field]=[];assert.equal(betaStatus(true,v,false,false,true).complete,false)}
 const v=structuredClone(s);v.progress.flags.BADGE_04=false;assert.equal(betaStatus(true,v,false,false,true).complete,false);
 for(const stage of ['PROLOGUE','S1','S2','S3','S4'])assert.equal(betaStageAllowed(true,stage,false,false,true),true);
 assert.equal(betaStageAllowed(true,'S5',false,false,true),false);assert.equal(betaStageAllowed(true,'S2'),false);
 const {document}=parseHTML('<html><body></body></html>');const complete=appendBeta05Completion({parent:document.body,readStatus:()=>view});assert.equal(complete.heading.textContent,FOUR.completeTitle);assert.doesNotMatch(complete.copy.textContent,/첫 물방울/);
 const pending=appendBeta05Completion({parent:document.body,readStatus:()=>({...view,pendingSave:true})});assert.match(pending.copy.textContent,/아직 저장/);
});
function titleFixture(extra={}){const {document}=parseHTML('<html><body><section></section></body></html>');document.defaultView.confirm=()=>true;const host=document.querySelector('section'),storage=memory(),calls=[];const menu=mountBeta05TitleMenu({host,storage,catalog:{starterIds:['SPECIES_001'],getDisplayName:x=>x},audioFactory:()=>({state:{},pause(){},dispose(){}}),onLaunch:async selection=>calls.push(selection),...extra});const click=text=>{const b=[...host.querySelectorAll('button')].find(n=>n.textContent===text);assert(b,'button '+text);b.click();return b};click('건너뛰기');return {document,host,storage,calls,menu,click}}
test('default title has no copy action; four-badge title shows consistent scope and save policy',()=>{
 const plain=titleFixture();try{assert(!plain.host.textContent.includes('이전 후보 기록 복사'))}finally{plain.menu.dispose()}
 const candidate=titleFixture({noticeText:FOUR.notice,saveNoticeText:FOUR.savePolicy,listCopySources:()=>[]});try{assert(candidate.host.textContent.includes(FOUR.notice));assert(candidate.host.textContent.includes(FOUR.savePolicy));candidate.click('이전 후보 기록 복사');assert.match(candidate.menu.status.textContent,/\.stm 백업/)}finally{candidate.menu.dispose()}
});
test('copy UI cancellation/back do not launch; confirmed repeated clicks start only one empty-target copy',async()=>{
 let resolveLaunch;const calls=[];const candidate=titleFixture({listCopySources:()=>[{key:oldKey,label:'1배지 후보 · 모험 1'}],onLaunch:async selection=>{calls.push(selection);await new Promise(r=>resolveLaunch=r)}});
 try{candidate.click('이전 후보 기록 복사');candidate.document.defaultView.confirm=()=>false;candidate.click('1배지 후보 · 모험 1 복사');assert.equal(calls.length,0);candidate.click('뒤로');assert.equal(calls.length,0);
 candidate.document.defaultView.confirm=()=>true;candidate.click('이전 후보 기록 복사');const b=candidate.click('1배지 후보 · 모험 1 복사');b.click();assert.equal(calls.length,1);assert.deepEqual(calls[0],{mode:'continue',slot:'SLOT_1',starter:'SPECIES_001',sourceKey:oldKey});resolveLaunch();await Promise.resolve();
 }finally{candidate.menu.dispose()}
});
test('four-badge route retains loopback gate and physical lock/save keys, while old first-badge files remain byte-identical',async()=>{
 const entry=await fs.readFile(new URL('beta05-interior-dev/s4-dev-entry.mjs',source),'utf8');assert.match(entry,/assertBeta05LocalAccess/);assert.match(entry,/navigator\.locks\.request\(s4SlotKey\(selection.slot\)/);assert.match(entry,/navigator\.locks\.request\(selection.sourceKey/);assert.match(entry,/worldOptions:S4_WORLD_OPTIONS/);
 const alias=await fs.readFile(new URL('beta05-four-badge-candidate.html',source),'utf8');assert.match(alias,/s4-dev-entry.mjs/);
 const {assertBeta05LocalAccess}=await load('beta05/local-access.mjs');assert.throws(()=>assertBeta05LocalAccess({localBuild:true,hostname:'example.com'}),/LOCAL_TEST_ONLY/);
 const {createHash}=await import('node:crypto');const protectedFiles=JSON.parse(await fs.readFile(new URL('../../../beta_four_badge_integration/protected-baseline.json',import.meta.url)));
 for(const record of protectedFiles){const bytes=await fs.readFile(new URL(record.file,source));assert.equal(createHash('sha256').update(bytes).digest('hex'),record.sha256,record.file)}
});
