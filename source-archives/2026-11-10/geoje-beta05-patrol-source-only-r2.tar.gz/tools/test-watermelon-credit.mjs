import test from'node:test';import assert from'node:assert/strict';import{readFile}from'node:fs/promises';import{createHash}from'node:crypto';import{parseHTML}from'linkedom';
const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url),base=new URL('../../../beta05_opening_full_music_candidate_r1/project/',import.meta.url);
const{mountBeta05Opening}=await import(new URL('ui/beta05-opening-player.mjs',root));
test('every R2 shot including final title shows exact requested copyright line',()=>{
 const{document}=parseHTML('<html><body><section></section></body></html>');const host=document.querySelector('section');const player=mountBeta05Opening({host,clock:{setTimeout:()=>1,clearTimeout(){}},audioFactory:()=>({state:{},pause(){},dispose(){},playFromGesture(){}})});
 try{player.play();for(let i=0;i<6;i++){assert.equal(host.querySelector('.geoje-opening-mark').textContent,'© WATERMELON');if(i<5)[...host.querySelectorAll('button')].find(b=>b.textContent==='다음').click()}assert.equal(host.querySelector('.geoje-opening-shot').dataset.scene,'title')}finally{player.dispose()}
});
test('existing menu and closing credit stay present with separate external license link',async()=>{
 const closing=await readFile(new URL('ui/beta05-closing-player.mjs',root),'utf8'),menu=await readFile(new URL('ui/beta05-title-menu.mjs',root),'utf8');assert(closing.includes("'© WATERMELON'"));assert(menu.includes("'© WATERMELON'"));assert(closing.includes("notice.href='./assets/legal/NOTICE.txt'"));assert(closing.includes('OST20'));
});
test('third-party notices and licenses remain byte-identical; no new exclusivity assertion',async()=>{
 for(const name of ['Galmuri-OFL.txt','Nanum-OFL.txt']){const path='public-resources/assets/legal/'+name;assert.deepEqual(await readFile(new URL('../'+path,import.meta.url)),await readFile(new URL(path,base)))}
 assert.equal(createHash('sha256').update(await readFile(new URL('../public-resources/assets/legal/NOTICE.txt',import.meta.url))).digest('hex'),'9a8598835ae023c8271ce452866ece82b69f0c2016b5be2b6bb5c76c6d1b6737');
 const notice=await readFile(new URL('../public-resources/assets/legal/NOTICE.txt',import.meta.url),'utf8');assert(notice.includes('AI 생성물의 저작권 보호 여부를 보증하지 않습니다.'));assert(notice.includes('SIL Open Font License 1.1'));
 const opening=await readFile(new URL('ui/beta05-opening-player.mjs',root),'utf8');assert(!opening.includes('All rights reserved'));assert(!opening.includes('독점'));
});
