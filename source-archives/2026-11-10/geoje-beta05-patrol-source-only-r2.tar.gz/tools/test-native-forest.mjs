import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fixture, memory, deps, load, fs, MAP, BINDINGS, hash, stable } from './forest-test-fixture.mjs';
const { FOREST, FOREST_BINDINGS, forestSafe, FOREST_CORRIDORS } = await load('native-connected/forest-plan.mjs');
const { SESSION_REVISION, nativeSlotKey } = await load('native-connected/session.mjs');
const forward = 'area-entry:P_ECO_CENTER_EDGE', back = forward + ':return';
async function enter(session) {
  session.exterior.arrival([...BINDINGS[forward].foot]);
  await session.world.interact(forward); session.sync();
  assert.equal(session.exterior.kind, 'forest');
}

test('unchanged selected original art, four candidate bindings and all connected safe corridors', async () => {
  const art = await fs.readFile(new URL('../public-resources/native-restoration/prologue.png', import.meta.url));
  assert.equal(createHash('sha256').update(art).digest('hex'), FOREST.imageSHA);
  const seen = new Set(), queue = [[...FOREST.landing]];
  seen.add(queue[0].join(','));
  for (let i = 0; i < queue.length; i++) {
    const [x,y] = queue[i];
    for (const p of [[x-1,y],[x+1,y],[x,y-1],[x,y+1]]) {
      const key = p.join(',');
      if (forestSafe(p) && !seen.has(key)) { seen.add(key); queue.push(p); }
    }
  }
  assert.equal(Object.keys(FOREST_BINDINGS).length, 4);
  for (const p of Object.values(FOREST_BINDINGS)) assert(seen.has(p.foot.join(',')), p.id);
  assert.equal(forestSafe([700, 130]), true, 'new candidate grass is open');
  assert.equal(forestSafe([1, 1]), false);
  assert.equal(forestSafe([570.5, 270]), false);
  assert.equal(FOREST.randomEncounters, 'EXISTING_CANONICAL_TABLE_CONNECTED');
  assert(FOREST_CORRIDORS.length > 0);
});

test('real paired warp selects original-art forest and returns to R2 native hub landing', async () => {
  const a = await fixture();
  try {
    const canonicalBefore = a.world.definition;
    await enter(a);
    assert.equal(a.world.snapshot().position.scene, FOREST.mapId);
    assert.deepEqual(a.exterior.player, FOREST.landing);
    assert.equal(a.scene, null);
    assert(a.world.nearby().some(p => p.id === back));
    await a.world.interact(back); a.sync();
    assert.equal(a.exterior.kind, 'prologue');
    assert.deepEqual(a.exterior.player, BINDINGS[forward].returnFoot);
    assert.deepEqual(a.world.definition, canonicalBefore);
  } finally { a.dispose(); }
});

test('pixel walk records actual distance, blocks tile bypass and stops at forest boundaries', async () => {
  const a = await fixture();
  try {
    await enter(a); const before = a.world.snapshot();
    await a.moveExterior('up');
    assert.deepEqual(a.exterior.player, [570, 258]);
    assert.equal(a.world.snapshot().economy.walkedDistance, (before.economy.walkedDistance ?? 0) + 12);
    assert.deepEqual(a.world.snapshot().position, before.position);
    await assert.rejects(a.world.move('up'), /NATIVE_CONNECTED/);
    a.sync(); a.exterior.arrival([540, 260]); await a.save(); a.sync();
    assert.equal(await a.moveExterior('left'), false);
    assert.deepEqual(a.exterior.player, [540, 260]);
    await assert.rejects(a.world.story.worldCommand({type:'native-connected-walk'}), /RECEIPT/);
  } finally { a.dispose(); }
});

test('forest pose resumes and foreign R2 or off-path native data is rejected without writes', async () => {
  const storage = memory(); storage.setItem('geoje.dev.interior-pilot.native-prologue-r2.v1.SLOT_1', 'R2_UNCHANGED');
  let a = await fixture({storage});
  try {
    await enter(a); a.exterior.arrival([700, 223]); await a.save(); const expected = a.exterior.capture();
    a.dispose(); a = await fixture({storage});
    assert.deepEqual(a.exterior.capture(), expected);
    assert.equal(storage.getItem('geoje.dev.interior-pilot.native-prologue-r2.v1.SLOT_1'), 'R2_UNCHANGED');
    const raw = storage.getItem(deps.key); a.dispose();
    for (const mutate of [e => e.nativeCandidateRevision = 'PROLOGUE_NATIVE_GAMEPLAY_CANDIDATE_R2', e => e.native.foot = [610,100]]) {
      const envelope = JSON.parse(raw); mutate(envelope.data); envelope.sha256 = hash(stable(envelope.data));
      const candidate = JSON.stringify(envelope); storage.setItem(deps.key, candidate);
      await assert.rejects(fixture({storage}), /NATIVE_SAVE_REVISION|FOREST_SAVE_POSE/);
      assert.equal(storage.getItem(deps.key), candidate);
    }
  } finally { a.dispose(); }
});

test('original tutorial gates remain and real capture returns to the same forest native pose', async () => {
  let a = await fixture();
  try {
    await enter(a); await assert.rejects(a.world.interact('tutorial:PROLOGUE'), /가까이/);
    a.exterior.arrival([700,223]);
    await assert.rejects(a.world.interact('tutorial:PROLOGUE'), /unavailable/i);
    a.dispose(); a = await fixture();
    for (const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER']) await a.world.story.runEvent(id);
    const {createCanonicalCreature}=await load('canonical-session.mjs');
    const ready=a.world.snapshot(); ready.party=[createCanonicalCreature(a.world.catalog,'SPECIES_001',100)]; a.dispose();
    a=await fixture({initialRuntime:ready,worldOptions:{...deps.worldOptions,rng:()=>.5,battleDriver:battle=>{
      for(let i=0;i<150&&battle.snapshot().phase!=='ended';i++){
        const state=battle.snapshot(),move=state.party[state.active].moves.find(m=>m.pp>0);
        battle.act({type:'move',moveId:move?.id??'SYSTEM_STRUGGLE'});
      }
      assert.equal(battle.snapshot().outcome,'won');
    }}});
    await a.world.story.runTrainer('RIVAL_00',a.world.options());
    await a.world.story.runEvent('P03_TUTORIAL');
    a.sync(); a.exterior.arrival([1100,597]);
    await a.world.interact('town-npc:world:hub:PROLOGUE:2');
    const runtime = a.world.snapshot(); a.dispose();
    let battles = 0;
    a = await fixture({initialRuntime: runtime, worldOptions: {...deps.worldOptions, rng: () => 0, battleDriver: battle => {
      battles++;
      for (let n = 0; n < 12 && battle.snapshot().phase !== 'ended'; n++) battle.act({type:'capture',ballId:'ecology_ball'});
      assert.equal(battle.snapshot().outcome, 'captured');
    }}});
    await enter(a); a.exterior.arrival([700,223]);
    const partyBefore = a.world.snapshot().party.length;
    const result = await a.world.interact('tutorial:PROLOGUE'); a.sync();
    assert.equal(result.outcome, 'captured'); assert.equal(battles, 1);
    assert.equal(a.world.snapshot().party.length, partyBefore + 1);
    assert.equal(a.world.snapshot().economy.tutorial.completed, true);
    assert.deepEqual(a.exterior.player, [700,223]);
    assert.equal(a.exterior.kind, 'forest');
  } finally { a.dispose(); }
});

test('forest observation uses actual native proximity and the original active-quest rule', async () => {
  let a = await fixture();
  try {
    await enter(a); a.exterior.arrival([1095,170]);
    await assert.rejects(a.world.interact('SURVEY_CENTER_FOREST', {transactionId:'forest-no-quest'}), /의뢰/);
    const runtime = a.world.snapshot(); a.dispose();
    // Test fixture only. Does not alter real saves or add a game shortcut.
    runtime.economy.quest = {round:1,active:true,observed:[]};
    a = await fixture({initialRuntime:runtime});
    await assert.rejects(a.world.interact('SURVEY_CENTER_FOREST',{transactionId:'forest-too-far'}), /가까이/);
    a.exterior.arrival([1095,170]);
    await a.world.interact('SURVEY_CENTER_FOREST',{transactionId:'forest-observe-1'});
    await a.world.interact('SURVEY_CENTER_FOREST',{transactionId:'forest-observe-2'});
    assert.deepEqual(a.world.snapshot().economy.quest.observed,['SURVEY_CENTER_FOREST']);
  } finally { a.dispose(); }
});

test('candidate file import supports only its own forest saves and empty candidate slots', async () => {
  const {importNativeSave} = await load('native-connected/file-import.mjs');
  const storage=memory(), a=await fixture({storage});
  try {
    await enter(a); await a.save(); const raw=storage.getItem(deps.key);
    assert.equal(JSON.parse(raw).data.nativeCandidateRevision,SESSION_REVISION);
    const destination=memory();
    importNativeSave({raw,storage:destination,slot:'SLOT_2',ownerCurrent:()=>true,dependencies:deps});
    assert.equal(destination.getItem(nativeSlotKey('SLOT_2')),raw);
    assert.throws(()=>importNativeSave({raw,storage:destination,slot:'SLOT_2',ownerCurrent:()=>true,dependencies:deps}),/빈/);
  } finally { a.dispose(); }
});

test('forest renderer pins the original PNG, uses native pixels and disposes its bitmap', async () => {
  const {prepareForestRenderer}=await load('native-connected/forest-renderer.mjs');
  const bytes=await fs.readFile(new URL('../public-resources/native-restoration/prologue.png',import.meta.url));
  let closed=0; const image={width:FOREST.width,height:FOREST.height,close(){closed++}};
  const renderer=await prepareForestRenderer({readBytes:async()=>bytes,decodeImage:async()=>image});
  const calls=[],ctx={canvas:{width:960,height:540},save(){},restore(){},clearRect(){},drawImage(...args){calls.push(args)}};
  renderer.drawPose(ctx,{mapId:FOREST.mapId,revision:FOREST.revision,foot:FOREST.landing});
  assert.equal(calls.length,1); assert.equal(calls[0][0],image);
  assert.deepEqual(calls[0].slice(3,5),calls[0].slice(7,9),'source and destination sizes are equal');
  assert.throws(()=>renderer.drawPose(ctx,{mapId:FOREST.mapId,revision:FOREST.revision,foot:[610,100]}),/POSE/);
  renderer.dispose();renderer.dispose();assert.equal(closed,1);
  await assert.rejects(prepareForestRenderer({readBytes:async()=>new Uint8Array([1]),decodeImage:async()=>image}),/PIN/);
});
