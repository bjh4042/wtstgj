import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {parseHTML} from 'linkedom';
import {capturePartyItemSelections,appendPartyItemControls} from '../dist/native_world_selected_s9_boss_source_r3/source/ui/party-item-selection.mjs';
import {installOrdinaryMenu} from '../dist/native_world_selected_s9_boss_source_r3/source/ui/ordinary-menu.mjs';

const mon={instanceId:'friend-a',speciesId:'SPECIES_001',moves:[{id:'MOVE_A',pp:3},{id:'MOVE_B',pp:1}]};
const choice=(itemId,extra={})=>({itemId,instanceId:mon.instanceId,label:itemId+' (2)',...extra});
const medicines=[choice('potion'),choice('antidote'),choice('ether',{moveSlot:1})];
function fixture(){
 const {document,window}=parseHTML('<html><body><main><aside><section data-w="party"></section><section data-w="state"></section><details><div data-w="guide"></div></details><section aria-label="저장 메뉴"></section></aside></main></body></html>');
 let focused=document.body;Object.defineProperty(document,'activeElement',{get:()=>focused});
 window.HTMLElement.prototype.focus=function(){if(!this.disabled){focused=this;this.dispatchEvent(new window.Event('focus'))}};
 const root=document.querySelector('main'),parent=root.querySelector('[data-w="party"]'),calls=[];
 const button=(target,label,fn,disabled)=>{const b=document.createElement('button');b.textContent=label;b.disabled=disabled;b.onclick=fn;target.append(b);return b};
 const add=({choices=medicines,party=[mon],selection,disabled=false,onUse=action=>calls.push(action)}={})=>{
  const row=document.createElement('p');row.dataset.menuEntity=party[0].instanceId;parent.append(row);
  return {row,...appendPartyItemControls({parent:row,party,choices,selection,button,disabled,onUse})};
 };
 const rebuild=(options={})=>{const saved=capturePartyItemSelections(parent);parent.replaceChildren();return add({...options,selection:saved.get((options.party??[mon])[0].instanceId)})};
 return {document,window,root,parent,calls,add,rebuild};
}
function pick(view,index){const options=[...view.select.options];options.forEach(option=>option.selected=false);options[index].selected=true;view.select.dispatchEvent(new view.select.ownerDocument.defaultView.Event('change'))}
function selected(view){return [...view.select.options].find(option=>option.value===view.select.value)}

test('non-first medicine survives Use-button focus, quantity changes and option reorder',()=>{
 const f=fixture();let view=f.add();pick(view,1);view.use.focus();view.use.onclick();
 view=f.rebuild({choices:[choice('ether',{moveSlot:1}),choice('potion'),choice('antidote',{label:'해독제 (1)'})]});
 assert.equal(selected(view).textContent,'해독제 (1)');assert.equal(view.use.disabled,false);assert.match(view.detail.textContent,/해독제 \(1\)/);
 view.use.onclick();assert.deepEqual(f.calls,[{itemId:'antidote',instanceId:mon.instanceId},{itemId:'antidote',instanceId:mon.instanceId}]);
});

test('exhaustion never selects another item; prompt survives repeated refreshes until explicitly changed',()=>{
 const f=fixture();let view=f.add();pick(view,1);view.use.onclick();
 for(let i=0;i<3;i++){
  view=f.rebuild({choices:[choice('potion'),choice('ether',{moveSlot:1})]});
  assert.equal(view.select.value,'');assert.equal(view.use.disabled,true);assert.match(view.detail.textContent,/다시 골라/);view.use.onclick();
 }
 assert.equal(f.calls.length,1);pick(view,2);assert.equal(view.use.disabled,false);view.use.onclick();
 assert.deepEqual(f.calls.at(-1),{itemId:'ether',instanceId:mon.instanceId,moveSlot:1});
});

test('PP medicine keeps its move through labels but requires reselection after that move is replaced',()=>{
 const f=fixture();let view=f.add();pick(view,2);
 view=f.rebuild({party:[{...mon,moves:[{id:'MOVE_A',pp:3},{id:'MOVE_B',pp:7}]}],choices:medicines.map(c=>({...c,label:c.label+' · PP 변경'}))});
 assert.equal(view.select.value,'2');view.use.onclick();assert.equal(f.calls.length,1);
 view=f.rebuild({party:[{...mon,moves:[{id:'MOVE_A',pp:3},{id:'MOVE_C',pp:1}]}]});
 assert.equal(view.select.value,'');view.use.onclick();assert.equal(f.calls.length,1);
});

test('each creature retains its own selection across party reordering',()=>{
 const f=fixture(),a=f.add(),second={...mon,instanceId:'friend-b'},b=f.add({party:[second],choices:medicines.map(c=>({...c,instanceId:second.instanceId}))});pick(a,2);pick(b,1);
 const selections=capturePartyItemSelections(f.parent);f.parent.replaceChildren();
 const nextB=f.add({party:[second],choices:medicines.map(c=>({...c,instanceId:second.instanceId})),selection:selections.get(second.instanceId)}),nextA=f.add({selection:selections.get(mon.instanceId)});
 nextB.use.onclick();nextA.use.onclick();assert.deepEqual(f.calls,[{itemId:'antidote',instanceId:second.instanceId},{itemId:'ether',instanceId:mon.instanceId,moveSlot:1}]);
});

test('locked, disconnected and invalid controls cannot dispatch a replacement action',()=>{
 const f=fixture(),locked=f.add({disabled:true});locked.use.onclick();pick(locked,1);assert.equal(locked.use.disabled,true);locked.use.onclick();
 f.parent.replaceChildren();const stale=f.add();f.parent.replaceChildren();stale.use.onclick();
 const current=f.add();const invalid=f.document.createElement('option');invalid.value='';invalid.textContent='선택';current.select.prepend(invalid);pick(current,0);current.use.onclick();
 assert.deepEqual(f.calls,[]);
});

test('view creation and restoration do not mutate party, choices or transaction payloads',()=>{
 const f=fixture(),party=structuredClone([mon]),choices=structuredClone(medicines),before=JSON.stringify({party,choices});
 let view=f.add({party,choices});pick(view,2);view=f.rebuild({party,choices});view.use.onclick();
 assert.equal(JSON.stringify({party,choices}),before);assert.deepEqual(Object.keys(f.calls[0]).sort(),['instanceId','itemId','moveSlot']);
});

test('ordinary menu returns exhausted Use-button focus to the prompt and preserves Back behavior',()=>{
 const f=fixture();let view=f.add();
 const state={player:{name:'탐험가'},dex:{seen:[],caught:[]},inventory:{},progress:{items:{}},party:[mon]};
 const menu=installOrdinaryMenu({root:f.root,onExit(){}}),catalog={records:[]};menu.update(state,{catalog,open:true});
 f.root.querySelector('[data-menu-page="bag"]').click();f.root.querySelector('[data-open-party]').click();pick(view,1);view.use.focus();
 const focusState=menu.captureFocus();view=f.rebuild({choices:[choice('potion')]});menu.update(state,{catalog,open:true,focusState});
 assert.equal(f.document.activeElement,view.select);assert.equal(view.select.value,'');menu.activate();assert.deepEqual(f.calls,[]);
 pick(view,1);view.use.focus();const nextFocus=menu.captureFocus();view=f.rebuild({choices:[choice('potion')]});menu.update(state,{catalog,open:true,focusState:nextFocus});
 assert.equal(f.document.activeElement,view.use);menu.activate();assert.equal(f.calls[0].itemId,'potion');
 assert.equal(menu.back(),true);assert.equal(menu.page,'bag');assert.equal(menu.back(),true);assert.equal(menu.page,'main');menu.dispose();
});

test('world entry captures before replacing rows and limits new controls to ordinary party UI',async()=>{
 const source=await readFile(new URL('../dist/native_world_selected_s9_boss_source_r3/source/world/entry.mjs',import.meta.url),'utf8');
 assert.match(source,/itemSelections=capturePartyItemSelections\(el\('party'\)\);el\('party'\)\.replaceChildren\(\)/);
 assert.match(source,/if\(ordinary&&parent\.dataset\.menuEntity\)return appendPartyItemControls/);
 assert.match(source,/world\.inputLocked,partyIndex,itemSelections\.get\(mon\.instanceId\)\)/);
 assert.match(source,/itemControls\(actions,battle\.party,battle\.bagItems,a=>act\(\{type:'item',\.\.\.a,transactionId:devRequestId\(\)\}\),blocked\|\|battle\.phase!=='turn'\)/);
});

test('selected medicine uses the existing canonical transaction and persistence path exactly once',async()=>{
 const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
 const {CanonicalWorld}=await import(new URL('world/service.mjs',root));
 const {loadApprovedLatestRuntimeAdapter}=await import(new URL('compatibility/approved-latest-runtime-adapter.mjs',root));
 const {itemUseChoices}=await import(new URL('economy/item-use-choices.mjs',root));
 const read=dir=>async file=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await readFile(new URL(`data/${dir}/${file}`,root)));
 const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:read('canonical-handoff-v1')},stagedOptions:{readStaging:read('staging-20260927')}});
 const seed=new CanonicalWorld({adapter,beta05:true});let runtime;
 try{for(const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER'])await seed.story.runEvent(id);runtime=seed.snapshot()}finally{seed.dispose()}
 runtime.progress.items={...runtime.progress.items,potion:2,antidote:1};runtime.party[0].status='poison';
 const writes=[],world=new CanonicalWorld({adapter,beta05:true,runtime,persist:snapshot=>writes.push(structuredClone(snapshot))});
 try{
  const f=fixture(),before=world.snapshot(),choices=itemUseChoices(world.catalog,before.progress.items,before.party),index=choices.findIndex(c=>c.itemId==='antidote');
  const view=f.add({party:before.party,choices,onUse:action=>world.useItem(action.itemId,action.instanceId,'ui-item-selection-test',action.moveSlot)});pick(view,index);await view.use.onclick();
  const after=world.snapshot();assert.equal(after.progress.items.potion,2);assert.equal(after.progress.items.antidote,0);assert.equal(after.party[0].status,null);assert.equal(writes.length,1);assert.deepEqual(writes[0],after);
  const refreshed=f.rebuild({party:after.party,choices:itemUseChoices(world.catalog,after.progress.items,after.party)});await refreshed.use.onclick();assert.equal(writes.length,1);assert.deepEqual(world.snapshot(),after);
 }finally{world.dispose()}
});
