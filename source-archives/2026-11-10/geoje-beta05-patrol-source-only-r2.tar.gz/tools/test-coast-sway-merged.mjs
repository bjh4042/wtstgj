import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture,memory,deps,load,BINDINGS} from './forest-test-fixture.mjs';
const {nativeSlotKey,SESSION_REVISION}=await load('native-connected/session.mjs');
const {importNativeSave}=await load('native-connected/file-import.mjs');
test('one session walks animated forest, visits coast, saves and resumes without motion leaking into save data',async()=>{
 const storage=memory(),calls=[],foreground=[];let a=await fixture({storage,renderer:{...deps.renderer,forest:{drawPose(ctx,pose,opts){calls.push(opts);return{origin:[0,0]}},drawForeground(ctx,pose,opts){foreground.push({pose,opts})}}}});
 const ctx={canvas:{width:960,height:540},save(){},restore(){},fillRect(){},fillText(){}};
 try{
  a.exterior.arrival(BINDINGS['area-entry:P_ECO_CENTER_EDGE'].foot);await a.world.interact('area-entry:P_ECO_CENTER_EDGE');a.sync();
  a.exterior.tick(80);a.exterior.draw(ctx);assert.equal(calls.at(-1).elapsedMs,80);assert.equal(foreground.at(-1).opts.elapsedMs,80);assert.equal(foreground.at(-1).pose.kind,'forest');const pose=a.exterior.capture();a.exterior.tick(100,{paused:true});a.exterior.draw(ctx);assert.equal(calls.at(-1).elapsedMs,80);assert.deepEqual(a.exterior.capture(),pose);
  await a.world.interact('area-entry:P_ECO_CENTER_EDGE:return');a.sync();a.exterior.arrival(BINDINGS['area-entry:P_JANGSEUNGPO_COAST'].foot);await a.world.interact('area-entry:P_JANGSEUNGPO_COAST');a.sync();assert.equal(a.exterior.kind,'coast');await a.moveExterior('down');await a.save();const coast=a.exterior.capture();assert.equal('elapsedMs' in coast,false);a.dispose();a=await fixture({storage});assert.deepEqual(a.exterior.capture(),coast);assert.equal(a.exterior.kind,'coast');
 }finally{a.dispose()}
});
test('merged namespace rejects coast and sway predecessor files without modifying their save slots',async()=>{
 const storage=memory();for(const key of ['coast-native-r1','grass-sway-r1','forest-growth-merged-r1','coast-sway-merged-r1','grass-occlusion-r1'])storage.setItem(`geoje.dev.interior-pilot.${key}.v1.SLOT_1`,'UNCHANGED');const a=await fixture({storage});try{await a.save();assert.equal(SESSION_REVISION,'BETA05_GAMEPLAY_PATROL_CANDIDATE_R1');const raw=storage.getItem(nativeSlotKey('SLOT_1'));const {hash,stable}=await import('./forest-test-fixture.mjs');for(const old of ['BETA05_COAST_NATIVE_CANDIDATE_R1','BETA05_GRASS_SWAY_CANDIDATE_R1','BETA05_COAST_SWAY_MERGED_CANDIDATE_R1','BETA05_GRASS_OCCLUSION_CANDIDATE_R1']){const e=JSON.parse(raw);e.data.nativeCandidateRevision=old;e.sha256=hash(stable(e.data));const dest=memory();assert.throws(()=>importNativeSave({raw:JSON.stringify(e),storage:dest,slot:'SLOT_2',ownerCurrent:()=>true,dependencies:deps}),/REVISION/);assert.equal(dest.m.size,0)}for(const key of ['coast-native-r1','grass-sway-r1','forest-growth-merged-r1','coast-sway-merged-r1','grass-occlusion-r1'])assert.equal(storage.getItem(`geoje.dev.interior-pilot.${key}.v1.SLOT_1`),'UNCHANGED')}finally{a.dispose()}
});
