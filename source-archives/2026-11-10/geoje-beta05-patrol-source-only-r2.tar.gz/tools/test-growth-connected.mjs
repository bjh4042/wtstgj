import test from 'node:test';
import assert from 'node:assert/strict';
import {parseHTML} from 'linkedom';
import {fixture, deps, memory, load, fs, source} from './forest-test-fixture.mjs';
const {mountBattleGrowth}=await load('ui/growth/growth-battle-bridge.mjs');
const {nativeSlotKey,SESSION_REVISION}=await load('native-connected/session.mjs');
const {createCanonicalCreature}=await load('canonical-session.mjs');

function small(){
 const {document,window}=parseHTML('<html><body><button id="field">필드</button><div id="target"></div></body></html>');
 const before={phase:'turn',party:[{instanceId:'p',speciesId:'SPECIES_001',level:8,totalExp:700}],events:[]};
 const after={phase:'ended',outcome:'won',party:[{...before.party[0],level:9,totalExp:780}],events:[{type:'exp',instanceId:'p',amount:80,totalExp:780},{type:'end',outcome:'won'}]};
 let saved=structuredClone(before),open=true;
 const owner={catalog:{getDisplayName:()=>'<도토람>'},inputLocked:false,story:{pendingCommit:false,busy:false},snapshot:()=>structuredClone(saved)};
 let selected=owner;
 const target=document.querySelector('#target'),bridge=mountBattleGrowth({target,getWorld:()=>selected,ready:()=>open});
 return {document,window,target,bridge,owner,before,after,commit:()=>saved=structuredClone(after),setOpen:v=>open=v,changeOwner:()=>selected={}};
}

test('ended engine result waits for the committed party and presentation readiness, without writes',()=>{
 const x=small(),before=JSON.stringify([x.before,x.after,x.owner.snapshot()]);
 assert(x.bridge.begin(x.owner,1,x.before));assert(x.bridge.settle(x.owner,1,'won',x.after));
 assert.equal(x.bridge.tick(),false);assert.equal(x.bridge.state.receipt,null);
 assert.equal(JSON.stringify([x.before,x.after,x.owner.snapshot()]),before);
 x.commit();x.setOpen(false);assert.equal(x.bridge.tick(),false);assert(x.target.hidden);
 x.setOpen(true);x.owner.story.pendingCommit=true;assert.equal(x.bridge.tick(),false);
 x.owner.story.pendingCommit=false;x.owner.story.busy=true;assert.equal(x.bridge.tick(),false);
 x.owner.story.busy=false;const committed=JSON.stringify(x.owner.snapshot());assert(x.bridge.tick());
 assert.equal(x.bridge.state.receipt.rows[0].gained,80);assert.equal(x.bridge.state.receipt.rows[0].toLevel,9);
 assert.equal(JSON.stringify(x.owner.snapshot()),committed);assert.equal(x.document.querySelector('.eco-growth-row strong').textContent,'<도토람>');
 x.bridge.dispose();
});

test('same battle does not reopen or announce twice; close/reopen only change the UI',()=>{
 const x=small();x.bridge.begin(x.owner,1,x.before);x.bridge.settle(x.owner,1,'won',x.after);x.commit();x.bridge.tick();
 const original=JSON.stringify(x.owner.snapshot()),row=x.document.querySelector('.eco-growth-row'),live=x.document.querySelector('[role=status]').textContent;
 x.document.querySelector('.eco-growth-close').click();assert.equal(x.bridge.state.visible,false);
 assert.equal(x.bridge.begin(x.owner,1,x.before),false);assert.equal(x.bridge.settle(x.owner,1,'won',x.after),false);
 for(let i=0;i<20;i++)assert.equal(x.bridge.tick(),false);
 assert.equal(x.bridge.state.visible,false);assert.equal(x.document.querySelector('.eco-growth-row'),row);
 assert.equal(x.document.querySelector('[role=status]').textContent,'');
 x.document.querySelector('.eco-growth-reopen').click();assert(x.bridge.state.visible);
 assert.equal(JSON.stringify(x.owner.snapshot()),original);x.bridge.dispose();
});

test('a new battle collapses prior history; no-growth result never reopens an old card',()=>{
 const x=small();x.bridge.begin(x.owner,1,x.before);x.bridge.settle(x.owner,1,'won',x.after);x.commit();x.bridge.tick();
 assert(x.bridge.state.visible);x.bridge.begin(x.owner,2,{phase:'turn',party:x.after.party,events:[]});assert.equal(x.bridge.state.visible,false);
 x.bridge.settle(x.owner,2,'fled',{...x.after,outcome:'fled',events:[{type:'end',outcome:'fled'}]});
 assert.equal(x.bridge.tick(),false);assert.equal(x.bridge.state.visible,false);assert.equal(x.document.querySelector('[role=status]').textContent,'');x.bridge.dispose();
});

test('restore, owner replacement, reset, no-growth result and disposal fail closed',()=>{
 const x=small();assert.equal(x.bridge.begin(x.owner,1,x.before,{restoring:true}),false);
 assert.equal(x.bridge.settle(x.owner,1,'won',x.after),false);x.commit();assert.equal(x.bridge.tick(),false);
 x.bridge.begin(x.owner,2,x.before);x.bridge.settle(x.owner,2,'won',x.after);x.changeOwner();assert.equal(x.bridge.tick(),false);
 x.bridge.reset();assert.equal(x.bridge.state.receipt,null);assert(x.target.hidden);x.bridge.dispose();assert.equal(x.bridge.tick(),false);
 assert.equal(x.document.querySelector('[data-growth-region]'),null);
 const y=small();y.bridge.begin(y.owner,1,y.before);assert.equal(y.bridge.settle(y.owner,1,'won',{...y.before,phase:'ended',outcome:'won',events:[{type:'end',outcome:'won'}]}),false);assert.equal(y.bridge.tick(),false);y.bridge.dispose();
});

test('growth buttons isolate field hotkeys and X closes without reaching document commands',()=>{
 const x=small();x.bridge.begin(x.owner,1,x.before);x.bridge.settle(x.owner,1,'won',x.after);x.commit();x.bridge.tick();
 let commands=0;x.document.addEventListener('keydown',()=>commands++);
 for(const key of ['ArrowUp','z','m','Enter','x']){
  const event=new x.window.Event('keydown',{bubbles:true,cancelable:true});event.key=key;
  x.document.querySelector('.eco-growth-close').dispatchEvent(event);
 }
 assert.equal(commands,0);assert.equal(x.bridge.state.visible,false);x.bridge.dispose();
});

test('real interactive story battle supplies full snapshots; growth appears only after commit and never writes saves',async()=>{
 let seed=await fixture();
 for(const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER'])await seed.world.story.runEvent(id);
 const runtime=seed.world.snapshot();runtime.party=[createCanonicalCreature(seed.world.catalog,'SPECIES_001',12)];seed.dispose();
 const storage=memory();storage.setItem('geoje.dev.interior-pilot.unified-native-r1.v1.SLOT_1','UNCHANGED');
 const {document}=parseHTML('<html><body><div id="target"></div></body></html>');
 let session,view,before,terminal,settled=false,readyCalls=0,finishedCalls=0;
 session=await fixture({initialRuntime:runtime,storage,worldOptions:{...deps.worldOptions,rng:()=>.2,hooks:{
  battleReady(snapshot){
   readyCalls++;before=structuredClone(snapshot);view.begin(session.world,1,snapshot);
   for(let i=0;i<150;i++){
    const state=session.world.story.battleSnapshot();if(state.phase==='ended')break;
    const move=state.party[state.active].moves.find(m=>m.pp>0);
    session.world.actBattle({type:'move',moveId:move?.id??'SYSTEM_STRUGGLE'});
   }
   terminal=session.world.story.battleSnapshot();assert.equal(terminal.phase,'ended');assert.equal(terminal.outcome,'won');
  },
  battleFinished(outcome){
   finishedCalls++;settled=view.settle(session.world,1,outcome,session.world.story.battleSnapshot());
   assert.equal(view.tick(),false,'story operation has not committed yet');
  }
 }}});
 view=mountBattleGrowth({target:document.querySelector('#target'),getWorld:()=>session.world,ready:()=>true});
 try{
  await session.world.story.runTrainer('RIVAL_00',session.world.options());
  assert.equal(readyCalls,1);assert.equal(finishedCalls,1);assert(settled);
  const current=session.world.snapshot(),bytes=[...storage.m];assert(view.tick());
  assert.equal(view.state.receipt.rows[0].gained,current.party[0].totalExp-before.party[0].totalExp);
  assert.equal(view.state.receipt.rows[0].toLevel,current.party[0].level);
  assert(view.state.receipt.rows[0].gained>0);assert.equal(terminal.events.at(-1).type,'end');
  document.querySelector('.eco-growth-close').click();view.tick();document.querySelector('.eco-growth-reopen').click();
  assert.deepEqual(session.world.snapshot(),current);assert.deepEqual([...storage.m],bytes);
  assert.equal(storage.getItem('geoje.dev.interior-pilot.unified-native-r1.v1.SLOT_1'),'UNCHANGED');
  assert(storage.getItem(nativeSlotKey('SLOT_1')));view.dispose();session.dispose();
  const resumed=await fixture({storage});const empty=mountBattleGrowth({target:document.createElement('div'),getWorld:()=>resumed.world,ready:()=>true});
  assert.equal(empty.tick(),false);assert.equal(empty.state.receipt,null);empty.dispose();resumed.dispose();
 }finally{view.dispose();session.dispose()}
});

test('explicit native launch, live hooks, safe region, teardown and separate save keys are connected',async()=>{
 const entry=await fs.readFile(new URL('world/entry.mjs',source),'utf8'),launch=await fs.readFile(new URL('native-connected/game-entry.mjs',source),'utf8');
 for(const text of ['growthReceipt?.begin(world,ownedBattleToken,s)','growthReceipt?.settle(world,ownedBattleToken,outcome,world.story.battleSnapshot()??battle)','function frame(now){growthReceipt?.tick()','growthReceipt?.dispose()','growthReceipt?.reset()','growthTarget?.contains(document.activeElement)'])assert(entry.includes(text),text);
 assert(launch.includes('nativeCandidateUI:true,growthReceiptCandidate:true,ecologyCandidate:true'));
 assert(launch.includes("import '../ui/growth/growth-receipt.css'"));
 assert.equal(nativeSlotKey('SLOT_1'),'geoje.dev.interior-pilot.gameplay-patrol-r1.v1.SLOT_1');assert.equal(SESSION_REVISION,'BETA05_GAMEPLAY_PATROL_CANDIDATE_R1');
 assert((await fs.readFile(new URL('beta05-gameplay-patrol-candidate.html',source),'utf8')).includes('./native-connected/game-entry.mjs'));
});
