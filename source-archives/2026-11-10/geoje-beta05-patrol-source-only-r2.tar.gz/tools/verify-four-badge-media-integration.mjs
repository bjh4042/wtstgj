// Post-build audit only. Never invokes Vite or overwrites a generated bundle.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {parseAst} from 'rolldown/parseAst';
const project=fileURLToPath(new URL('../',import.meta.url));
const workspace=path.resolve(project,'../..');
const report=path.join(workspace,'beta_four_badge_media_integration');
const output=path.join(project,'build-beta05-four-badge-media-r1');
const source=path.join(project,'dist/native_world_selected_s9_boss_source_r3/source');
const hash=file=>createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const json=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const preflight=json(path.join(report,'component-preflight.json'));
for(const record of preflight.verifiedFiles)assert.equal(hash(path.join(project,record.file)),record.sha256,record.file);
const baseline=json(path.join(workspace,'opening_sequence_r2/baseline.json'));
const changed=baseline.filter(record=>hash(path.join(project,record.file))!==record.sha256).map(record=>record.file).sort();
const prefix='dist/native_world_selected_s9_boss_source_r3/source/';
assert.deepEqual(changed,[
 'ui/beta05-title-menu.mjs','ui/beta05-opening-scenes.mjs','ui/beta05-completion.mjs',
 'presentation/original-sfx-manifest.mjs','presentation/ordinary-original-sfx.mjs','presentation/original-sfx-routing.mjs'
].map(file=>prefix+file).sort(),'unexpected source change since component baseline');
const protectedSources=json(path.join(workspace,'beta_four_badge_integration/protected-baseline.json'));
for(const record of protectedSources)assert.equal(hash(path.join(source,record.file)),record.sha256,record.file);
const oldManifest=json(path.join(workspace,'beta_four_badge_integration/generated-manifest.json'));
for(const record of oldManifest)assert.equal(hash(path.join(project,'build-beta05-four-badge-candidate',record.file)),record.sha256,record.file);

const entries=['beta05-four-badge-candidate.html','beta05-start.html','beta05-s2-dev.html','beta05-s3-dev.html','beta05-s4-dev.html'];
const generated=[];
function recordGenerated(dir){for(const name of fs.readdirSync(dir)){const file=path.join(dir,name),stat=fs.lstatSync(file);if(stat.isSymbolicLink())continue;if(stat.isDirectory())recordGenerated(file);else generated.push({file:path.relative(output,file),bytes:stat.size,sha256:hash(file)})}}
recordGenerated(output);
const compiled=new Map(generated.filter(record=>record.file.endsWith('.js')).map(record=>[record.file,fs.readFileSync(path.join(output,record.file),'utf8')]));
const roots=[...fs.readFileSync(path.join(output,entries[0]),'utf8').matchAll(/<script\b[^>]*\bsrc="\/wtstgj\/([^"?#]+\.js)"/g)].map(match=>match[1]);
assert(roots.length);
const reachable=new Set(),edges=[];
const literal=node=>node?.type==='Literal'?node.value:node?.type==='TemplateLiteral'&&!node.expressions.length?node.quasis[0].value.cooked:null;
function visit(file){
 if(reachable.has(file))return;reachable.add(file);assert(compiled.has(file),'missing chunk '+file);
 const imports=[];
 function walk(node){
  if(!node||typeof node!=='object')return;
  if(['ImportDeclaration','ExportNamedDeclaration','ExportAllDeclaration','ImportExpression'].includes(node.type)){
   const value=literal(node.source);if(typeof value==='string')imports.push(value);
  }
  for(const value of Object.values(node)){if(Array.isArray(value))for(const child of value)walk(child);else if(value&&typeof value==='object')walk(value)}
 }
 walk(parseAst(compiled.get(file)));
 for(const specifier of imports){assert(specifier.startsWith('.'),'unexpected external chunk import '+specifier);const target=path.posix.normalize(path.posix.join(path.posix.dirname(file),specifier));edges.push({from:file,to:target});visit(target)}
}
for(const root of roots)visit(root);
const joined=[...reachable].map(file=>compiled.get(file)).join('\n');
const markers=[
 '작은 생명, 커다란 모험','너와 함께할 작은 친구','섬의 변화를 살펴보자','길 위에서 만나는 거제','함께라서 더 넓어지는 세상',
 '네 배지 여정 돌아보기','geoje-closing','beta05-four-badge','film-presentation','우리의 모험은 계속됩니다',
 'UIFIELD_14_STEP_GRASS.wav','UIFIELD_20_RECOVERY.wav','BATTLE_13_STATUS_CURED.wav','BATTLE_14_MOVE_LEARNED.wav','BATTLE_15_RESIDUAL_DAMAGE.wav',
 'ost-19.mp3','ost-20.mp3'
];
for(const marker of markers)assert(joined.includes(marker),'missing bundled marker '+marker);

let resourceLinks=0,readableResources=0;
function linkResources(src,dst){
 if(!fs.existsSync(dst)){fs.symlinkSync(path.relative(path.dirname(dst),src),dst);resourceLinks++;return}
 if(fs.statSync(src).isDirectory()&&fs.statSync(dst).isDirectory()){for(const name of fs.readdirSync(src))linkResources(path.join(src,name),path.join(dst,name))}
 else assert.equal(hash(src),hash(dst),'resource collision '+src);
}
const resources=path.join(project,'public-resources');
for(const name of fs.readdirSync(resources))linkResources(path.join(resources,name),path.join(output,name));
function verifyResources(src,dst){
 if(fs.statSync(src).isDirectory()){for(const name of fs.readdirSync(src))verifyResources(path.join(src,name),path.join(dst,name));return}
 assert.equal(fs.realpathSync(src),fs.realpathSync(dst));fs.accessSync(dst,fs.constants.R_OK);readableResources++;
}
verifyResources(resources,output);
const provenance=json(path.join(source,'presentation/original-sfx/gameplay-sfx-r2-provenance.json'));
for(const asset of provenance.assets)assert.equal(hash(path.join(output,'__source_layout/native_world_selected_s9_boss_source_r3/source/presentation/original-sfx',asset.file)),asset.sha256);
for(const entry of entries){
 const urls=[...fs.readFileSync(path.join(output,entry),'utf8').matchAll(/(?:src|href)="(\/wtstgj\/[^"?#]+)"/g)].map(match=>match[1]);
 assert(urls.some(url=>url.endsWith('.js')));for(const url of urls)assert(fs.statSync(path.join(output,url.slice('/wtstgj/'.length))).isFile());
}
for(const record of generated)assert.equal(hash(path.join(output,record.file)),record.sha256,'bundle changed during verification');
const log=fs.readFileSync(path.join(report,'build.log'),'utf8');
assert.equal((log.match(/building client environment for production/g)??[]).length,1);
assert.match(log,/✓ 406 modules transformed/);assert.match(log,/✓ built in/);
const verification={
 pass:true,created:new Date().toISOString(),componentVersions:{opening:'R2',closing:'R1',gameplaySfx:'R2'},
 buildInvocations:1,transformedModules:406,entry:entries[0],entries,
 componentFilesMatched:preflight.verifiedFiles.length,baselineSourcesChecked:baseline.length,expectedComponentChanges:changed,
 protectedSourcesMatched:protectedSources.length,priorCandidateGeneratedFilesMatched:oldManifest.length,
 reachableChunks:[...reachable],chunkImports:edges,bundleMarkersVerified:markers,
 resourceLinksAdded:resourceLinks,readableResources,verifiedSfx:provenance.assets.map(({role,sha256})=>({role,sha256})),
 generatedFiles:generated,generatedBytes:generated.reduce((sum,record)=>sum+record.bytes,0),
 conflictTests:{passed:1,failed:0,log:'beta_four_badge_media_integration/conflict-test.log'},
 auditCorrection:'Vite merged the HTML facade into shared S4 chunks. Initial post-build facade assertion was corrected; the already-generated HTML and its parsed static/dynamic imports were audited without a second build.',
 limits:['Local linked validation build, not portable.','Closing is replay from saved four-badge completion, not an automatic ending.','No browser, visuals, listening, full play or balance verification.','No dashboard update, upload or deployment.']
};
fs.writeFileSync(path.join(output,'media-integration-verification.json'),JSON.stringify(verification,null,2)+'\n');
fs.writeFileSync(path.join(report,'verification.json'),JSON.stringify(verification,null,2)+'\n');
console.log(JSON.stringify({pass:true,buildInvocations:1,transformedModules:406,reachableChunks:[...reachable],resourceLinksAdded:resourceLinks,readableResources,componentFilesMatched:preflight.verifiedFiles.length,generatedBytes:verification.generatedBytes},null,2));
