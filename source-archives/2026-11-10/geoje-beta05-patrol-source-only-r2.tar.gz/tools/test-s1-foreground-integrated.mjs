// Tests the actual integrated candidate modules. No overlay loader.
import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {S1_BRIDGE_LAMP as lamp, drawS1BridgeLamp, s1ForegroundLayers} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/s1-foreground.mjs';
import {prepareS1Renderer} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/s1-renderer.mjs';
import {createS1Scene} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/s1-scene.mjs';
import {S1, S1_BINDINGS, s1Safe, s1FootProvenance} from '../dist/native_world_selected_s9_boss_source_r3/source/native-connected/s1-plan.mjs';
const base = new URL('../', import.meta.url);
const bytes = await readFile(new URL('public-resources/native-restoration/s1-open.png', base));
const image = {width:S1.width,height:S1.imageHeight};
const hash = b => createHash('sha256').update(b).digest('hex');
function context({failDraw=false}={}) {
  const calls = [], ctx = {canvas:{width:500,height:500},calls,
    save(){calls.push(['save'])},restore(){calls.push(['restore'])},
    beginPath(){calls.push(['beginPath'])},moveTo(...a){calls.push(['moveTo',...a])},
    lineTo(...a){calls.push(['lineTo',...a])},closePath(){calls.push(['closePath'])},
    clip(){calls.push(['clip'])},drawImage(...a){calls.push(['drawImage',...a]);if(failDraw)throw Error('DRAW_FAIL')},
    clearRect(){},fillRect(){},strokeRect(){},fillText(){},
  };return ctx;
}
test('foreground is pinned to existing original pixels, not new raster or collision data',()=>{
  assert.equal(lamp.sourceSHA,S1.imageSHA);assert.equal(hash(bytes),lamp.sourceSHA);
  assert.deepEqual(lamp.bounds,[1471,1415,29,161]);assert.equal(lamp.foot[1],1576);
  assert.match(lamp.provenance,/CANDIDATE/);assert(Object.isFrozen(lamp.polygons[0][0]));
});
test('all silhouette vertices stay in bounded S1 original-art crop',()=>{
  const [x,y,w,h]=lamp.bounds;
  for(const polygon of lamp.polygons){assert(polygon.length>=3);for(const [px,py]of polygon){assert(Number.isInteger(px)&&Number.isInteger(py));assert(px>=x&&px<x+w&&py>=y&&py<y+h)}}
});
test('glass windows remain open; clockwise metal contours do not cancel',()=>{
  const inside=(p,polygon)=>{let yes=false;for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){
    const [x,y]=polygon[i],[X,Y]=polygon[j];if((y>p[1])!==(Y>p[1])&&p[0]<(X-x)*(p[1]-y)/(Y-y)+x)yes=!yes;
  }return yes};
  for(const p of [[1481,1440],[1489,1440]])assert(!lamp.polygons.some(poly=>inside(p,poly)));
  assert(lamp.polygons.some(poly=>inside([1485,1500],poly)));
  for(const poly of lamp.polygons){let area=0;for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length];area+=a[0]*b[1]-b[0]*a[1]}assert(area>0)}
});
test('redraw preserves 1:1 source coordinates with a nonrectangular stencil',()=>{
  const c=context();assert.equal(drawS1BridgeLamp(c,image,[1300,1300]),true);
  assert.equal(c.calls.filter(x=>x[0]==='closePath').length,lamp.polygons.length);
  assert(c.calls.findIndex(x=>x[0]==='clip')<c.calls.findIndex(x=>x[0]==='drawImage'));
  assert.deepEqual(c.calls.find(x=>x[0]==='drawImage').slice(2),[1471,1415,29,161,171,115,29,161]);
  assert.deepEqual(c.calls.at(-1),['restore']);
});
test('offscreen foreground does not call drawing APIs',()=>{
  for(const origin of [[0,0],[1500,1300],[1300,1576],[1300,900]]){const c=context();assert.equal(drawS1BridgeLamp(c,image,origin),false);assert.equal(c.calls.length,0)}
});
test('invalid camera origins reject before drawing',()=>{
  for(const origin of [null,[],[1],[NaN,0],[0,Infinity],[0,1,2]]){const c=context();assert.throws(()=>drawS1BridgeLamp(c,image,origin),/ORIGIN/);assert.equal(c.calls.length,0)}
});
test('context restored even when redraw throws',()=>{
  const c=context({failDraw:true});assert.throws(()=>drawS1BridgeLamp(c,image,[1300,1300]),/DRAW_FAIL/);assert.deepEqual(c.calls.at(-1),['restore']);
});
test('layer snapshots its camera origin instead of retaining caller mutation',()=>{
  const c=context(),origin=[1300,1300],layers=s1ForegroundLayers(c,image,origin);origin[0]=0;layers[0].renderForeground();
  assert.equal(c.calls.find(x=>x[0]==='drawImage')[6],171);
});
test('real S1 renderer exposes foreground and owns bitmap disposal',async()=>{
  let closed=0;const r=await prepareS1Renderer({readBytes:async()=>bytes,decodeImage:async()=>({...image,close(){closed++}})}),c=context();
  r.drawPose(c,{mapId:S1.mapId,revision:S1.revision,foot:[1480,1510]});
  assert.equal(r.foregroundLayers(c,[1300,1300])[0].id,lamp.id);
  const pending=r.foregroundLayers(c,[1300,1300])[0];r.dispose();r.dispose();assert.equal(closed,1);
  assert.throws(()=>r.foregroundLayers(c,[1300,1300]),/CANCELLED/);
  assert.throws(()=>pending.renderForeground(),/CANCELLED/);
});
test('aborted render lifetime blocks queued foreground without drawing',async()=>{
  const controller=new AbortController(),c=context();const r=await prepareS1Renderer({readBytes:async()=>bytes,decodeImage:async()=>image,signal:controller.signal});
  const layer=r.foregroundLayers(c,[1300,1300])[0];controller.abort();assert.throws(()=>layer.renderForeground(),/CANCELLED/);assert.equal(c.calls.length,0);r.dispose();
});
function definition(){
  const points={};for(const id of Object.keys(S1_BINDINGS))points[id]={id,kind:'test',label:id};
  return {maps:{[S1.mapId]:{points:Object.keys(S1_BINDINGS),actors:[]}},points};
}
function makeScene(c,{foreground=true,drawPlayer=()=>c.calls.push(['player'])}={}){
  return createS1Scene({definition:definition(),renderer:{s1:{drawPose:()=>({origin:[1300,1300]}),...(foreground?{foregroundLayers:(ctx,origin)=>s1ForegroundLayers(ctx,image,origin)}:{})}},drawPlayer,snapshot:()=>({}),current:()=>true});
}
test('actual scene paints safe actor behind lamp, then foreground',()=>{
  assert(s1Safe([1480,1510]));assert.equal(s1FootProvenance([1480,1510]),'OFFICIAL_LOCAL_MASK');
  const c=context(),scene=makeScene(c);scene.arrival([1480,1510]);const before=scene.capture();scene.draw(c);
  assert(c.calls.findIndex(x=>x[0]==='player')<c.calls.findIndex(x=>x[0]==='drawImage'));assert.deepEqual(scene.capture(),before);
});
test('actual scene paints actor in front of lamp after foreground',()=>{
  assert(s1Safe([1480,1590]));const c=context(),scene=makeScene(c);scene.arrival([1480,1590]);scene.draw(c);
  assert(c.calls.findIndex(x=>x[0]==='player')>c.calls.findIndex(x=>x[0]==='drawImage'));
});
test('equal foot depth sorts foreground first, keeping actor readable at crossing',()=>{
  const c=context(),scene=makeScene(c);scene.arrival([1447,1576]);scene.draw(c);
  assert(c.calls.findIndex(x=>x[0]==='player')>c.calls.findIndex(x=>x[0]==='drawImage'));
});
test('repeated draws and restore preserve native pose and patrol bytes',()=>{
  const c=context(),scene=makeScene(c);scene.arrival([1480,1510]);const pose=scene.capture();
  for(let i=0;i<4;i++)scene.draw(c);assert.deepEqual(scene.capture(),pose);scene.arrival([1480,1590]);scene.restore(pose);assert.deepEqual(scene.capture(),pose);
});
test('fixture renderer without foreground API remains supported',()=>{
  const c=context(),scene=makeScene(c,{foreground:false});scene.draw(c);assert.equal(c.calls.filter(x=>x[0]==='player').length,1);assert.equal(c.calls.filter(x=>x[0]==='drawImage').length,0);
});
test('official lamp obstruction remains blocked; presentation does not widen collision',()=>{
  for(const p of [[1485,1510],[1485,1540],[1485,1576]])assert.equal(s1Safe(p),false);
  for(const p of [[1480,1510],[1447,1576],[1480,1590]])assert.equal(s1Safe(p),true);
});
