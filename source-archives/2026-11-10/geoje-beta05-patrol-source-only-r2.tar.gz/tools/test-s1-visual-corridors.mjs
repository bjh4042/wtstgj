import test from'node:test';import assert from'node:assert/strict';
import {s1Safe,S1_BINDINGS}from'../dist/native_world_selected_s9_boss_source_r3/source/native-connected/s1-plan.mjs';
test('Lower candidate no longer crosses rice-water gap',()=>{for(let x=3240;x<3700;x++)for(let y=1360;y<1431;y++)assert.equal(s1Safe([x,y]),false);});
test('East bridge uses existing visible north-south dirt path instead',()=>{for(let y=1010;y<=1530;y++)assert.equal(s1Safe([4190,y]),true);});
test('Shop and gym approach feet stay below drawn thresholds',()=>{assert.equal(s1Safe([1135,900]),false);assert.equal(s1Safe([4190,850]),false);assert.deepEqual(S1_BINDINGS['interior-entry:S1:shop'].foot,[1135,950]);assert.deepEqual(S1_BINDINGS['gym-entry:1'].foot,[4190,890]);});
test('Bridge candidate avoids selected railing-edge pixels while preserving centerline',()=>{assert.equal(s1Safe([3040,1530]),false);assert.equal(s1Safe([4235,1530]),false);assert.equal(s1Safe([2990,1530]),true);assert.equal(s1Safe([4200,1530]),true);});
