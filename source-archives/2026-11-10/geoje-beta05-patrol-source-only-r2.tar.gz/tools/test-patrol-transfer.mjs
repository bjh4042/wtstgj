import test from 'node:test';import assert from 'node:assert/strict';
import {fixture,memory,load,deps,hash,stable,BINDINGS} from './forest-test-fixture.mjs';
import {s1ReadyRuntime} from './s1-native-test-fixture.mjs';
const {nativeSlotKey}=await load('native-connected/session.mjs'),{importNativeSave}=await load('native-connected/file-import.mjs');
const {encodePCSave,decodePCSave}=await load('beta05-interior-dev/file-save.mjs');
const {S1_NATIVE_WORLD_OPTIONS}=await load('native-connected/s1-service-policy.mjs');
test('new patrol pose survives actual STM import and cold restore; foreign feedback revision cannot overwrite',async()=>{
 const storage=memory();let a=await fixture({storage,initialRuntime:await s1ReadyRuntime()});
 try{if(a.exterior.kind!=='s1'){a.exterior.arrival(BINDINGS['route:PROLOGUE:S1'].foot);await a.world.interact('route:PROLOGUE:S1');a.sync()}for(let i=0;i<167;i++)a.exterior.tick(1000/60);const pose=a.exterior.capture();await a.save();a.dispose();const raw=storage.getItem(nativeSlotKey('SLOT_1')),other=memory();
 importNativeSave({raw:decodePCSave(encodePCSave(raw)),storage:other,slot:'SLOT_1',ownerCurrent:()=>true,dependencies:{...deps,worldOptions:{...deps.worldOptions,...S1_NATIVE_WORLD_OPTIONS}}});
 a=await fixture({storage:other});assert.deepEqual(a.exterior.capture(),pose);assert.equal(other.getItem(nativeSlotKey('SLOT_1')),raw);
 const foreign=JSON.parse(raw);foreign.data.nativeCandidateRevision='BETA05_GAMEPLAY_FEEDBACK_CANDIDATE_R1';foreign.sha256=hash(stable(foreign.data));const empty=memory();empty.setItem('legacy-source','KEEP');assert.throws(()=>importNativeSave({raw:JSON.stringify(foreign),storage:empty,slot:'SLOT_1',ownerCurrent:()=>true,dependencies:deps}));assert.deepEqual([...empty.m],[['legacy-source','KEEP']]);
 }finally{a.dispose()}
});
