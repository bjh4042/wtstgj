import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
const base=new URL('../',import.meta.url);
const {fixture}=await import(new URL('tools/forest-test-fixture.mjs',base));
const source=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const {S1,S1_BINDINGS,S1_PATROLS,S1_CORRIDORS,s1Safe,s1FootProvenance}=await import(new URL('native-connected/s1-plan.mjs',source));
const {OFFICIAL_LOCAL_DOMAIN,inOfficialLocalDomain,officialLocalSafe}=await import(new URL('native-connected/s1-official-local-mask.mjs',source));
const {createS1Scene}=await import(new URL('native-connected/s1-scene.mjs',source));
const session=await fixture();
try{
 const s=createS1Scene({definition:session.world.definition,snapshot:()=>session.world.snapshot(),story:session.world.host.story,current:()=>true});
 const actors=s.actors(),residents=actors.filter(n=>session.world.definition.points[n.pointId].kind==='town-npc');
 assert.equal(residents.length,4);

 const [w,h]=[S1.width,S1.height],floor=new Uint8Array(w*h);
 for(const [x,y,X,Y] of S1_CORRIDORS)for(let yy=y;yy<Y;yy++)for(let xx=x;xx<X;xx++)floor[yy*w+xx]=1;
 const [ox,oy,oX,oY]=OFFICIAL_LOCAL_DOMAIN;
 let domainPixels=0;for(let y=oy;y<oY;y++)for(let x=ox;x<oX;x++){floor[y*w+x]=+officialLocalSafe([x,y]);assert.equal(s1Safe([x,y]),officialLocalSafe([x,y]));domainPixels++}
 for(const a of actors){const route=S1_PATROLS[a.pointId]??[a.foot,a.foot];for(let X=route[0][0];X<=route[1][0];X++){const foot=[X,a.foot[1]];assert(s1Safe(foot));for(let y=foot[1]-19;y<=foot[1]+19;y++)for(let x=foot[0]-19;x<=foot[0]+19;x++)if(Math.hypot(x-foot[0],y-foot[1])<20)floor[y*w+x]=0}}
 for(let i=0;i<actors.length;i++)for(let j=i+1;j<actors.length;j++)assert(Math.hypot(actors[i].foot[0]-actors[j].foot[0],actors[i].foot[1]-actors[j].foot[1])>=20);
 const seen=new Uint8Array(w*h),queue=new Int32Array(w*h);let rd=0,wr=1;queue[0]=S1.landing[1]*w+S1.landing[0];seen[queue[0]]=1;assert(floor[queue[0]]);
 while(rd<wr){const i=queue[rd++],x=i%w,y=Math.floor(i/w);for(const n of [x?i-1:-1,x<w-1?i+1:-1,y?i-w:-1,y<h-1?i+w:-1])if(n>=0&&floor[n]&&!seen[n]){seen[n]=1;queue[wr++]=n}}
 const approaches=[];
 for(const n of residents){const [x,y]=n.foot;let approach=null;for(let yy=y-48;yy<=y+48&&!approach;yy++)for(let xx=x-48;xx<=x+48;xx++){if(xx<0||yy<0||xx>=w||yy>=h||!seen[yy*w+xx])continue;s.arrival([xx,yy]);if(s.near(n.pointId)){approach=[xx,yy];break}}assert(approach,n.pointId+' unreachable');approaches.push({id:n.pointId,foot:n.foot,provenance:s1FootProvenance(n.foot),reachableTalkFoot:approach});s.arrival([x-20,y]);assert.equal(s.move('right',16),false);assert.deepEqual(s.player,[x-20,y]);}
 const endpoints=[];for(const b of Object.values(S1_BINDINGS)){if(!b.returnFoot)continue;assert(seen[b.foot[1]*w+b.foot[0]],b.id);assert(seen[b.returnFoot[1]*w+b.returnFoot[0]],b.id+' return');endpoints.push(b.id)}
 const files=['native-connected/s1-scene.mjs','native-connected/s1-plan.mjs','native-connected/s1-official-local-mask.mjs'];const hashes=Object.fromEntries(files.map(p=>[p,createHash('sha256').update(fs.readFileSync(new URL(p,source))).digest('hex')]));
 const result={base:'beta05_gameplay_feedback_candidate_r1',pass:true,nativePatrolImplemented:true,blockedAllPatrolSweptFootprints:true,residents:approaches,reachablePairedEndpoints:endpoints,officialDomainPixelsVerified:domainPixels,reachableUnoccupiedPixels:wr,hashes,sourceModified:true,patchCreated:true,actualBrowserQA:'NOT_RUN'};
 fs.writeFileSync(new URL('PATH_RESULT.json',import.meta.url),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
}finally{session.dispose()}
