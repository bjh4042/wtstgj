import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root = new URL('../dist/native_world_selected_s9_boss_source_r3/source/', import.meta.url);
const {GRASS_SWAY_RECT,grassSwayRows,drawForestGrassSway} = await import(new URL('native-connected/forest-grass-sway.mjs', root));
const {FOREST_GRASS,FOREST,FOREST_BINDINGS} = await import(new URL('native-connected/forest-plan.mjs', root));
const {createForestScene} = await import(new URL('native-connected/forest-scene.mjs', root));
test('visual footprint stays inside unchanged grass candidate; deterministic bounded animation',()=>{
 assert.deepEqual(FOREST_GRASS,[620,102,780,190]);
 assert(GRASS_SWAY_RECT[0]>FOREST_GRASS[0]&&GRASS_SWAY_RECT[1]>FOREST_GRASS[1]&&GRASS_SWAY_RECT[2]<FOREST_GRASS[2]&&GRASS_SWAY_RECT[3]<FOREST_GRASS[3]);
 assert.notDeepEqual(grassSwayRows(800),grassSwayRows(1600));
 assert.deepEqual(grassSwayRows(800),grassSwayRows(800));
 for(let t=1;t<10000;t+=37)for(const row of grassSwayRows(t))assert(Math.abs(row.dx)<=2);
});
test('reduced motion and invalid clocks render original art only',()=>{
 for(const t of [0,-1,NaN,Infinity]) assert.deepEqual(grassSwayRows(t),[]);
 assert.deepEqual(grassSwayRows(800,true),[]);
});
test('clipped strips use original image, camera origin, balanced context, and offscreen culling',()=>{
 const calls=[],image={};const ctx={canvas:{width:400,height:250},save(){calls.push('save')},restore(){calls.push('restore')},beginPath(){},rect(...r){calls.push(r)},clip(){calls.push('clip')},drawImage(...r){assert.equal(r[0],image);calls.push('draw')}};
 assert(drawForestGrassSway(ctx,image,[500,50],{elapsedMs:800})>0);
 assert.deepEqual(calls[1],[124,56,152,76]);assert.equal(calls[0],'save');assert.equal(calls.at(-1),'restore');
 assert.equal(drawForestGrassSway(ctx,image,[1200,500],{elapsedMs:800}),0);
});
test('live scene forwards time, freezes while paused, and never changes capture or encounter movement',()=>{
 const poses=[];const reverseId='forest-forward';
 const points=Object.fromEntries(Object.keys(FOREST_BINDINGS).map(id=>[id,{id,label:id}]));
 Object.assign(points['area-entry:P_ECO_CENTER_EDGE:return'],{reverseId,targetMapId:'placeholder'});
 const {mapId}=FOREST;
 // Read the canonical reverse target from the scene contract.
 return import(new URL('native-restoration/r2-scene.mjs',root)).then(({PROLOGUE_SCENE})=>{
 points['area-entry:P_ECO_CENTER_EDGE:return'].targetMapId=PROLOGUE_SCENE.mapId;
 points[reverseId]={targetMapId:mapId,reverseId:'area-entry:P_ECO_CENTER_EDGE:return'};
 let current=true;
 const scene=createForestScene({definition:{maps:{[mapId]:{points:Object.keys(FOREST_BINDINGS)}},points},renderer:{forest:{drawPose(ctx,pose,options){poses.push(options);return{origin:[0,0]}}}},current:()=>current});
 const ctx={canvas:{width:1000},save(){},restore(){},fillRect(){},fillText(){}};
 const before=scene.capture();scene.tick(50);scene.draw(ctx);assert.equal(poses.at(-1).elapsedMs,50);
 scene.tick(100,{paused:true});scene.draw(ctx);assert.equal(poses.at(-1).elapsedMs,50);
 scene.tick(1000);scene.draw(ctx);assert.equal(poses.at(-1).elapsedMs,150);
 current=false;scene.tick(100);scene.draw(ctx);assert.equal(poses.at(-1).elapsedMs,150);
 assert.deepEqual(scene.capture(),before);assert.equal(scene.takeEncounterMovement(),null);
 });
});
