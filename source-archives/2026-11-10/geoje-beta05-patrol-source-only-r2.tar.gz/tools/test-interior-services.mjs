import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {loadApprovedLatestRuntimeAdapter} from '../dist/native_world_selected_s9_boss_source_r3/source/compatibility/approved-latest-runtime-adapter.mjs';
import {createWorldDefinition,cellPosition} from '../dist/native_world_selected_s9_boss_source_r3/source/world/definition.mjs';
import {NativeInterior} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/reuse/native-interior.mjs';
import {createInteriorController} from '../dist/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/entry-pilot/controller.mjs';
import {bindInteriorAuthority,interiorPointNear} from '../dist/native_world_selected_s9_boss_source_r3/source/world/interior-pilot-authority.mjs';
import {fieldInteractionPoints} from '../dist/native_world_selected_s9_boss_source_r3/source/world/field-interaction-points.mjs';
import {CanonicalWorld} from '../dist/native_world_selected_s9_boss_source_r3/source/world/service.mjs';
import {createInteriorSession} from '../dist/native_world_selected_s9_boss_source_r3/source/beta05-interior-dev/interior-session.mjs';
import * as authority from '../dist/native_world_selected_s9_boss_source_r3/source/world/interior-pilot-authority.mjs';
import {validateCanonicalStorySave as validateCanonical} from '../dist/native_world_selected_s9_boss_source_r3/source/story/save.mjs';
import {validateWorldLocation as validateLocation} from '../dist/native_world_selected_s9_boss_source_r3/source/world/state.mjs';
import {sha256 as hash,stableJSON as stable} from '../dist/native_world_selected_s9_boss_source_r3/source/compatibility/codec.mjs';

const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const read=dir=>async file=>new TextDecoder('utf-8',{ignoreBOM:true}).decode(await readFile(new URL(`data/${dir}/${file}`,root)));
const adapter=await loadApprovedLatestRuntimeAdapter({historicalOptions:{readText:read('canonical-handoff-v1')},stagedOptions:{readStaging:read('staging-20260927')}});
const stages=['PROLOGUE','S2','S3','S4'];
const definition=createWorldDefinition(adapter,{interiorPilot:true,interiorPilotStages:stages});
const resource=new URL('../public-resources/__source_layout/native_world_selected_s9_boss_source_r3/source/world/internal-interiors/reuse/',import.meta.url);
const configs={};
for(const kind of ['center','shop']){
 const dir=kind==='center'?'center/assets/':'shop/';
 configs[kind]={registration:JSON.parse(await readFile(new URL(kind==='center'?'center/layout.json':'shop/REGISTRATION.json',resource))),floor:new Uint8Array(await readFile(new URL(dir+(kind==='center'?'player_floor.u8':'floor.u8'),resource))),staffFloor:kind==='center'?new Uint8Array(await readFile(new URL(dir+'doctor_support.u8',resource))):null};
}

// Isolated adapter fixtures. Stage progression, battle balance, and browser visuals are not exercised.
for(const stage of stages)for(const kind of ['center','shop'])test(`${stage} ${kind}: measured counter selects and invokes only its own service`,async()=>{
 const map=definition.maps[`world:interior:${stage}:${kind}`],point=definition.points[(kind==='center'?'heal:':'shop:')+stage];
 const scene=new NativeInterior({kind,...configs[kind],partySnapshot:()=>({party:[{}]})});
 const state={position:cellPosition(map.id,...map.spawn)},calls=[];
 let owner=true,allowInput=true;
 const world={definition,map,host:{world:definition},busy:false,snapshot:()=>state,nearby(){throw Error('Native service choices must not query the grid');},async interact(id,request){const selected=definition.points[id];assert.equal(interiorPointNear(this.host,state,selected),true);calls.push({id,request});return {ok:true};}};
 const port=bindInteriorAuthority(world,scene);
 const session={world,scene,sync(){},service:request=>port.run(kind,request),dispose(){port.dispose();}};
 const controller=createInteriorController({session,assets:{},drawActor(){},current:()=>owner,canInput:()=>allowInput});
 try{
  assert.equal(controller.servicePoint(),null,'entry is not the counter');
  assert.deepEqual(fieldInteractionPoints(world,controller),[]);
  scene.player=[...(kind==='center'?scene.r.servicePoint:scene.r.points.counter_front)];
  assert.equal(scene.support(scene.player),true);
  assert.equal(controller.servicePoint(),point);
  const selected=fieldInteractionPoints(world,controller).find(p=>p.id===point.id);
  assert.equal(selected,point,'the render choice lookup must retain the selected counter');
  const request=kind==='center'?{type:'heal',transactionId:'test:'+stage}:{itemId:'ecology_ball',quantity:1,transactionId:'test:'+stage};
  assert.deepEqual(await controller.service(request),{ok:true});
  assert.deepEqual(calls,[{id:point.id,request}]);
  allowInput=false;assert.equal(controller.servicePoint(),null);allowInput=true;
  world.busy=true;assert.equal(controller.servicePoint(),null);world.busy=false;
  scene.healing.running=true;assert.equal(controller.servicePoint(),null);scene.healing.running=false;
  const oldMapId=state.position.scene;try{state.position.scene='world:interior:WRONG:'+kind;assert.equal(controller.servicePoint(),null)}finally{state.position.scene=oldMapId}
  scene.player=[...scene.r.points.entry];assert.equal(controller.servicePoint(),null);
  await assert.rejects(controller.service(request),/INTERIOR_PROXIMITY/);
  owner=false;assert.equal(controller.servicePoint(),null);
 }finally{controller.dispose()}
});

test('outdoor choices remain unchanged and blocked native choices do not fall back to grid',()=>{
 const points=[{id:'outdoor'}],world={nearby:()=>points};
 assert.equal(fieldInteractionPoints(world),points);
 assert.equal(fieldInteractionPoints(world,{active:false}),points);
 assert.deepEqual(fieldInteractionPoints(world,{active:true,servicePoint:()=>null}),[]);
});

test('the real field renderer uses the native choice adapter',async()=>{
 const source=await readFile(new URL('world/entry.mjs',root),'utf8');
 assert.match(source,/import \{fieldInteractionPoints\} from '\.\/field-interaction-points\.mjs'/);
 assert.match(source,/const near=fieldInteractionPoints\(world,interiorController\);for\(const p of near\.filter/);
 assert.match(source,/const selected=near\.find\(p=>p\.id===choice\)/);
});

for(const kind of ['center','shop'])test(`${kind}: counter choice completes the real canonical transaction and isolated save`,async()=>{
 const seed=new CanonicalWorld({adapter,beta05:true,interiorPilot:true});let runtime;
 try{for(const id of ['P00_HOME_START','P01_ECO_CENTER','P02_FIRST_PARTNER'])await seed.story.runEvent(id);runtime=seed.snapshot();const entry=seed.definition.points['interior-entry:PROLOGUE:'+kind];runtime.position=cellPosition(entry.mapId,entry.x,entry.y);}finally{seed.dispose()}
 runtime.party[0].hp--;runtime.party[0].moves[0].pp--;
 const values=new Map,storage={getItem:k=>values.get(k)??null,setItem:(k,v)=>values.set(k,v)},key='geoje.dev.interior-pilot.beta05.v1.SLOT_1';
 const session=createInteriorSession({World:CanonicalWorld,worldOptions:{beta05:true},initialRuntime:runtime,adapter,configs,storage,key,ownerCurrent:()=>true,authority,validateCanonical,validateLocation,hash,stable});
 const controller=createInteriorController({session,assets:{},drawActor(){}});
 try{
  await session.world.interact('interior-entry:PROLOGUE:'+kind);session.sync();
  session.scene.player=[...(kind==='center'?session.scene.r.servicePoint:session.scene.r.points.counter_front)];
  const point=fieldInteractionPoints(session.world,controller)[0];assert.equal(point.id,(kind==='center'?'heal:':'shop:')+'PROLOGUE');
  const before=session.world.snapshot();
  await controller.service(kind==='center'?{type:'heal',transactionId:'counter-heal'}:{itemId:'ecology_ball',quantity:1,transactionId:'counter-purchase'});
  const after=session.world.snapshot();
  if(kind==='center'){
   assert.equal(after.party[0].hp,before.party[0].hp+1);
   assert.equal(after.party[0].moves[0].pp,before.party[0].moves[0].pp+1);
   assert.equal(session.scene.healing.running,true);
  }else{
   assert.equal(after.inventory.ecology_ball,before.inventory.ecology_ball+1);
   assert.equal(after.economy.money,before.economy.money-session.world.catalog.itemContract.ecology_ball.price);
  }
  assert.deepEqual(JSON.parse(values.get(key)).data.canonical,after);
  assert.equal(values.size,1);
 }finally{controller.dispose()}
});
