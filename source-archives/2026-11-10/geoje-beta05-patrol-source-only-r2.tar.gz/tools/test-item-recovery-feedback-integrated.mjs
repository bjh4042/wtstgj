import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {decorateItemRecoveryFeedback as decorate,itemRecoveryFeedbackFrame as feedback,drawItemRecoveryFeedback as draw} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/item-recovery-feedback.mjs';
const base=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const {createBattleHPTimeline}=await import(new URL('battle-v3/hp-timeline.mjs',base));
const {createSharedBattleSequences}=await import(new URL('battle-v3/shared-battle-sequences.mjs',base));
const {moveAnimationFrame}=await import(new URL('battle-v3/move-animation.mjs',base));
const layout={width:432,height:240,player:{x:115,y:228,size:125},enemy:{x:320,y:145,size:110}};
const opts={itemContract:{heal:{name:'회복약',effect:{hp_restore:20}},full:{name:'완전회복약',effect:{hp_restore:'full'}},cure:{effect:{cure:['poison']}},revive:{effect:{revive_hp_percent:50}},pp:{effect:{pp_restore:10}}}};
const before=()=>({kind:'wild',active:0,enemyActive:0,party:[{instanceId:'ally',speciesId:'SPECIES_001',namespace:'canonical',level:50,hp:5},{instanceId:'reserve',speciesId:'SPECIES_001',namespace:'canonical',level:50,hp:5}],opponents:[{instanceId:'enemy',speciesId:'SPECIES_001',namespace:'canonical',level:50,hp:50}],events:[],background:{assetId:'test-no-art'}});
const item=(id='ally',itemId='heal')=>({type:'item',instanceId:id,itemId});
const attack=()=>({type:'move',side:'opponent',instanceId:'enemy',targetId:'ally',moveId:'MV010',hit:true});
const damage=(hp=15)=>({type:'damage',targetId:'ally',amount:10,actualDamage:10,hp});
function flow({events=[item(),attack(),damage()],hp=15,reducedMotion=false,reserveHP=5}={}){
 const old=before(),next=structuredClone(old);next.party[0].hp=hp;next.party[1].hp=reserveHP;next.events=events;
 const sequence=createSharedBattleSequences({reducedMotion}),timeline=createBattleHPTimeline();
 timeline.decorate(old,sequence.consume(old,opts));
 const raw=timeline.decorate(next,sequence.consume(next,opts)),cues=decorate(raw,opts);
 return {old,next,cues,raw,sequence,timeline};
}
function sample(f,cue,progress){
 const moveFrame=moveAnimationFrame(cue,progress*(cue.reducedMotion?260:cue.duration),layout);
 const hudActors=f.timeline.sample(cue,{progress,moveFrame},{player:f.next.party[0],opponent:f.next.opponents[0]});
 return {hudActors,result:feedback(cue,{progress,moveFrame,hudActors})};
}
function canvas(){
 let depth=0;const texts=[],rects=[],attributes={};
 const ctx=new Proxy({canvas:{setAttribute:(k,v)=>attributes[k]=v},save(){depth++},restore(){assert.ok(depth>0);depth--},measureText(text){return {width:[...text].length*8}},fillText(...args){texts.push(args)},roundRect(...args){rects.push(args)}},{get(o,k){return k in o?o[k]:(...args)=>{for(const x of args)if(typeof x==='number')assert.ok(Number.isFinite(x))}}});
 return {ctx,texts,rects,attributes,get depth(){return depth}};
}
async function presentationModule(url,changed=false){
 let source=fs.readFileSync(url,'utf8');
 source=source.replace(/from '(\.\.?\/[^']+)'/g,(_,name)=>`from '${new URL(name,name.includes('item-recovery-feedback')&&changed?url:new URL('battle-v3/presentation.mjs',base)).href}'`);
 return import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
}
const baseline=await presentationModule(new URL('../../battle-recovery-feedback-integration-r1/preimage/battle-v3/presentation.mjs',import.meta.url));
const candidate=await presentationModule(new URL('battle-v3/presentation.mjs',base),true);

test('recovery then response keeps unknown HP until the existing exact impact checkpoint',()=>{
 const f=flow(),[use,response]=f.cues;
 assert.equal(use.kind,'item-use');assert.equal(response.kind,'move');
 assert.equal(f.cues.length,f.raw.length);assert.equal(use.hpTimeline.after.ally.hp,null);
 assert.equal(sample(f,use,.1).result.stage,'use');
 const pending=sample(f,use,.75);assert.equal(pending.hudActors.player.hp,null);assert.equal(pending.result.label,'HP 확인 중');
 assert.ok(pending.result.pulse>1);
 assert.equal(sample(f,response,.1).result.label,'반격 · HP 확인 중');
 const impact=sample(f,response,response.profile.contact);
 assert.equal(impact.hudActors.player.hp,15);assert.equal(impact.result.stage,'confirmed');assert.equal(impact.result.label,'HP 반영 완료');
 assert.equal(sample(f,response,1).hudActors.player.hp,15);
 assert.equal(f.timeline.sample(null,{}, {player:f.next.party[0]}).player.hp,15);
});

test('no counterattack or a miss uses the exact item checkpoint without inventing a missing heal amount',()=>{
 for(const events of [[item()],[item(),{...attack(),hit:false},{type:'miss',instanceId:'enemy'}]]){
  const f=flow({events,hp:25});assert.equal(sample(f,f.cues[0],.75).result.stage,'confirmed');
  assert.equal(f.cues[0].hpTimeline.after.ally.hp,25);
  assert.equal(f.cues.filter(c=>c.itemRecovery).length,1);
 }
});

test('reserve target, PP/status/revive tools, unknown item contracts and absent checkpoints are untouched',()=>{
 const reserve=flow({events:[item('reserve'),attack(),damage(0)],hp:0,reserveHP:25});
 assert.ok(reserve.cues.every(c=>!c.itemRecovery));
 for(const itemId of ['cure','revive','pp','unknown']){const f=flow({events:[item('ally',itemId),attack(),damage()]});assert.ok(f.cues.every(c=>!c.itemRecovery))}
 const f=flow();assert.equal(decorate([{...f.raw[0],hpTimeline:null}],opts)[0].itemRecovery,undefined);
 const full=flow({events:[item('ally','full')]});assert.equal(full.cues[0].itemRecovery.phase,'item');
});

test('reduced motion is static and uses the same midpoint as the existing HP display',()=>{
 const f=flow({reducedMotion:true}),[use,response]=f.cues;
 for(const p of [.5,.6,.75,.99])assert.equal(sample(f,use,p).result.pulse,1);
 assert.equal(sample(f,response,.49).result.stage,'response');
 const hit=sample(f,response,.5);assert.equal(hit.result.stage,'confirmed');assert.equal(hit.hudActors.player.hp,15);
});

test('unknown after a non-damaging response remains pending until the resolved residual checkpoint',()=>{
 const f=flow({events:[item(),{...attack(),moveId:'STATUS_ONLY',hit:false},{type:'miss'}, {type:'residual',instanceId:'ally',status:'poison',amount:3}],hp:22});
 const [use,response,residual]=f.cues;assert.equal(use.hpTimeline.after.ally.hp,null);
 sample(f,use,1);assert.equal(sample(f,response,1).result.stage,'response');
 assert.equal(sample(f,residual,.75).result.stage,'confirmed');
 assert.equal(f.cues.length,f.raw.length);
});

test('decoration preserves all original labels, durations, event objects and checkpoint values',()=>{
 const f=flow(),input=JSON.stringify([f.raw,opts]);
 const decorated=decorate(f.raw,opts);assert.deepEqual(decorated.map(({itemRecovery,...cue})=>cue),f.raw);
 assert.equal(JSON.stringify([f.raw,opts]),input);
 assert.deepEqual(decorate([],opts),[]);assert.deepEqual(f.sequence.consume(f.next,opts),[]);
 const switched=structuredClone(f.raw[1]);switched.actors.player.instanceId='reserve';
 assert.equal(decorate([f.raw[0],switched],opts)[1].itemRecovery,undefined);
});

test('invalid, stale or mismatched HP samples never claim confirmation',()=>{
 const f=flow(),cue=f.cues[1],actor={...f.next.party[0]};
 for(const hp of [null,5,NaN,Infinity,-1])assert.notEqual(feedback(cue,{progress:1,hudActors:{player:{...actor,hp}}})?.stage,'confirmed');
 assert.equal(feedback(null),null);assert.equal(feedback(cue,{progress:NaN}),null);
 assert.equal(feedback(cue,{progress:1,hudActors:{player:{...actor,instanceId:'reserve'}}}),null);
});

test('one badge has bounded geometry, balanced Canvas state and no duplicate HP number',()=>{
 for(const k of [.5,1,2])for(const side of ['player','opponent'])for(const stage of ['use','pending','response','confirmed']){
  const f={side,stage,label:{use:'회복 도구 사용',pending:'HP 확인 중',response:'반격 · HP 확인 중',confirmed:'HP 반영 완료'}[stage],pulse:1.1},c=canvas(),l={width:432*k,height:240*k,player:{x:115*k,y:228*k,size:125*k},enemy:{x:320*k,y:145*k,size:110*k}};
  draw(c.ctx,f,l);assert.equal(c.depth,0);assert.equal(c.texts.length,1);assert.ok(!/\d/.test(c.texts[0][0]));
  const [x,y,w,h]=c.rects[0];assert.ok(x>=0&&y>=0&&x+w<=l.width&&y+h<=l.height);
 }
 for(const l of [null,{...layout,width:0},{...layout,player:{x:NaN,y:1,size:1}}]){const c=canvas();draw(c.ctx,{side:'player',stage:'use',label:'회복 도구 사용',pulse:1},l);assert.equal(c.texts.length,0)}
});

test('live presentation keeps HP, timings, histories, attack frames and audio identical across speed/reduced-motion modes',()=>{
 for(const reducedMotion of [false,true])for(const speed of [.5,1,4]){
  const f=flow({reducedMotion}),audio=[[],[]],visuals=[baseline,candidate].map((m,i)=>m.createBattlePresentation({drawSpecies:()=>({accessibleLabel:'생태몬'}),audio:{emit:(...args)=>audio[i].push(args)},reducedMotion,playbackSpeed:speed}));
  for(const v of visuals){v.consume(f.old,opts);v.consume(f.next,opts);v.consume(f.next,opts)}
  const evidence=[];
  for(let now=0;now<=6000;now+=20){
   const contexts=[canvas(),canvas()],results=visuals.map((v,i)=>v.draw(contexts[i].ctx,f.next,now,layout));
   const {recoveryFeedback,...rest}=results[1];assert.deepEqual(rest,results[0]);assert.deepEqual(audio[1],audio[0]);
   for(const c of contexts)assert.equal(c.depth,0);
   if(recoveryFeedback)evidence.push(recoveryFeedback.stage);
  }
  assert.ok(evidence.includes('use')&&evidence.includes('pending')&&evidence.includes('response')&&evidence.includes('confirmed'));
  assert.equal(visuals[0].busy,false);assert.equal(visuals[1].busy,false);
  for(const v of visuals)v.stop();
  assert.deepEqual(visuals[1].draw(canvas().ctx,f.next,8000,layout),visuals[0].draw(canvas().ctx,f.next,8000,layout));
 }
});

test('restored event history never replays recovery or produces an extra cue',()=>{
 const f=flow(),v=candidate.createBattlePresentation({drawSpecies:()=>({}),audio:{emit(){}},reducedMotion:true});
 v.consume(f.next,{...opts,restoring:true});assert.equal(v.busy,false);
 const c=canvas(),result=v.draw(c.ctx,f.next,0,layout);assert.equal(result.recoveryFeedback,null);assert.equal(c.texts.length,0);v.stop();
});

test('real engine recovery shows all four phases, preserves single consumption and ends at actual HP',async()=>{
 const {fixture,load,deps,BINDINGS}=await import('./forest-test-fixture.mjs');
 const {createCanonicalCreature}=await load('canonical-session.mjs');
 let a=await fixture(),runtime=a.world.snapshot(),checked=false;
 runtime.party=[createCanonicalCreature(a.world.catalog,'SPECIES_001',50)];runtime.party[0].hp=5;
 const chosen=Object.values(a.world.catalog.itemContract).find(i=>i.pocket==='items'&&Number.isInteger(i.effect?.hp_restore)&&i.effect.hp_restore>0);runtime.progress.items[chosen.id]=2;a.dispose();
 a=await fixture({initialRuntime:runtime,worldOptions:{...deps.worldOptions,rng:()=>0,battleDriver:b=>{
  const prior=b.snapshot(),options={itemContract:a.world.catalog.itemContract},v=candidate.createBattlePresentation({drawSpecies:()=>({}),audio:{emit(){}},reducedMotion:false});
  v.consume(prior,{...options,restoring:true});
  const action={type:'item',itemId:chosen.id,instanceId:prior.party[0].instanceId,transactionId:'recovery-badge-test'};
  b.act(action);const after=b.snapshot();b.act(action);assert.deepEqual(b.snapshot(),after);assert.equal(after.bagItems[chosen.id],prior.bagItems[chosen.id]-1);
  v.consume(after,options);v.consume(after,options);const stages=new Set();let final;
  for(let now=0;now<6000;now+=20){final=v.draw(canvas().ctx,after,now,layout);if(final.recoveryFeedback)stages.add(final.recoveryFeedback.stage);if(!v.busy){final=v.draw(canvas().ctx,after,now+20,layout);break}}
  assert.deepEqual([...stages],['use','pending','response','confirmed']);assert.equal(final.hudActors.player.hp,after.party[0].hp);assert.equal(final.recoveryFeedback,null);assert.deepEqual(b.snapshot(),after);v.stop();checked=true;if(after.phase!=='ended')b.act({type:'flee'});
 }}});
 try{a.exterior.arrival(BINDINGS['area-entry:P_ECO_CENTER_EDGE'].foot);await a.world.interact('area-entry:P_ECO_CENTER_EDGE');a.sync();a.exterior.arrival([650,150]);for(let i=0;i<4;i++)await a.moveExterior('right');assert.equal(checked,true)}finally{a.dispose()}
});
