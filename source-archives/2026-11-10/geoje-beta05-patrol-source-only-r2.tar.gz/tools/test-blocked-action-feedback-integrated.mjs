import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {blockedActionMarker,drawBlockedActionFeedback} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/blocked-action-feedback.mjs';
const base=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const layout={width:432,height:240,player:{x:115,y:228,size:125},enemy:{x:320,y:145,size:110}};
const actors={player:{instanceId:'ally',namespace:'canonical',speciesId:'SPECIES_001',level:30,hp:50},opponent:{instanceId:'enemy',namespace:'canonical',speciesId:'SPECIES_001',level:20,hp:30}};
const snapshot=(events=[])=>({kind:'wild',active:0,enemyActive:0,party:[structuredClone(actors.player)],opponents:[structuredClone(actors.opponent)],events,background:{assetId:'no-test-art'}});
const event=(reason='sleep',side='player')=>({type:'cannot-act',instanceId:actors[side].instanceId,reason});
const originalURL=new URL('../../battle-blocked-action-integration-r1/preimage/battle-v3/shared-battle-sequences.mjs',import.meta.url),changedURL=new URL('battle-v3/shared-battle-sequences.mjs',base);
function sharedURL(url){const source=fs.readFileSync(url,'utf8').replace(/from '(\.\/[^']+)'/g,(_,name)=>`from '${new URL(name,name.includes('blocked-action-feedback')?url:new URL('battle-v3/shared-battle-sequences.mjs',base)).href}'`);return 'data:text/javascript;base64,'+Buffer.from(source).toString('base64')}
const original=await import(sharedURL(originalURL)),changed=await import(sharedURL(changedURL));
function cue(reason='sleep',side='player',reducedMotion=false){const seq=changed.createSharedBattleSequences({reducedMotion});return seq.consume(snapshot([event(reason,side)]))[0]}
function frame(c,t=.5){return changed.sharedBattleCueFrame(c,c.duration*t)}
function canvas(){let depth=0,draws=0;const attributes={};const ctx=new Proxy({canvas:{setAttribute:(k,v)=>attributes[k]=v},save(){depth++},restore(){assert.ok(depth>0);depth--},measureText(text){return{width:[...text].length*8}}},{get(o,k){return k in o?o[k]:(...args)=>{draws++;for(const v of args)if(typeof v==='number')assert.ok(Number.isFinite(v))}}});return {ctx,attributes,get depth(){return depth},get draws(){return draws}}}
async function presentation(useChanged){const file=new URL('battle-v3/presentation.mjs',base),source=fs.readFileSync(file,'utf8').replace(/from '(\.\.?\/[^']+)'/g,(_,name)=>`from '${name==='./shared-battle-sequences.mjs'?sharedURL(useChanged?changedURL:originalURL):new URL(name,file).href}'`);return import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'))}
const oldPresentation=await presentation(false),newPresentation=await presentation(true);

test('current baseline has no cannot-act Canvas feedback; patch adds only the missing marker',()=>{
 const c=cue(),f=frame(c),old=canvas(),next=canvas();
 assert.deepEqual(original.drawSharedBattleCue(old.ctx,c,c.duration*.5,layout),changed.drawSharedBattleCue(next.ctx,c,c.duration*.5,layout));
 assert.equal(old.draws,0);assert.ok(next.draws>0);assert.equal(next.depth,0);
 const text=fs.readFileSync(changedURL,'utf8').replace("import {drawBlockedActionFeedback} from './blocked-action-feedback.mjs';\n",'').replace(" if(cue.kind==='cannot-act'){drawBlockedActionFeedback(c,cue,frame,layout);return frame}\n",'');assert.equal(text,fs.readFileSync(originalURL,'utf8'));
});

test('all four real blocking reasons mark the correct side without actor or cue changes',()=>{
 for(const reason of ['sleep','paralysis','freeze','flinch'])for(const side of ['player','opponent']){
  const c=cue(reason,side),f=frame(c),before=JSON.stringify([c,f,layout]),marker=blockedActionMarker(c,f,layout);assert(marker);assert.equal(c.duration,900);
  const anchor=side==='player'?layout.player:layout.enemy;assert.ok(Math.abs(marker.x-anchor.x)<anchor.size);
  const out=canvas();drawBlockedActionFeedback(out.ctx,c,f,layout);assert.ok(out.draws>0);assert.equal(out.depth,0);assert.equal(JSON.stringify([c,f,layout]),before);
 }
});

test('only the existing action interval is used; normal motion fades once and reduced motion is static',()=>{
 const c=cue(),reduced=cue('sleep','player',true);
 for(const p of [0,1,2])assert.equal(blockedActionMarker(c,frame(c,p),layout),null);
 const start=blockedActionMarker(c,frame(c,.001),layout),middle=blockedActionMarker(c,frame(c,.5),layout),end=blockedActionMarker(c,frame(c,.999),layout);assert.ok(start.alpha<.01&&end.alpha<.01&&middle.alpha===1);
 const first=blockedActionMarker(reduced,frame(reduced,0),layout);for(const p of [.01,.25,.5,.75,.999])assert.deepEqual(blockedActionMarker(reduced,frame(reduced,p),layout),first);assert.equal(blockedActionMarker(reduced,frame(reduced,1),layout),null);
});

test('wake-up followed by a lost action gets one neutral pause, not a false sleeping status',()=>{
 const events=[{type:'status-cured',instanceId:'ally',status:'sleep'},event()],s=snapshot(events);s.party[0].status=null;
 const a=original.createSharedBattleSequences(),b=changed.createSharedBattleSequences(),old=a.consume(s),next=b.consume(s);
 assert.deepEqual(next,old);assert.equal(next.length,1);assert.equal(next[0].kind,'cannot-act');assert.match(next[0].label,/잠에서 깨어났지만/);assert.equal(next[0].actors.player.status,null);
 assert(blockedActionMarker(next[0],frame(next[0]),layout));assert.deepEqual(b.consume(s),[]);
});

test('other cues, unknown reasons, hidden/mismatched actors and invalid geometry do not draw',()=>{
 const c=cue(),f=frame(c);assert.equal(blockedActionMarker(),null);
 for(const x of [{...c,kind:'status-cured'},{...c,kind:'residual'},{...c,kind:'item-use'},{...c,kind:'move-result'},{...c,event:{...c.event,reason:'other'}},{...c,event:{...c.event,type:'status'}},{...c,event:{...c.event,instanceId:'reserve'}}])assert.equal(blockedActionMarker(x,f,layout),null);
 for(const x of [{...f,done:true},{...f,kind:'move'},{...f,progress:NaN},{...f,opacity:{player:0}},{...f,opacity:{player:Infinity}},{...f,actors:{player:{instanceId:'other'}}}])assert.equal(blockedActionMarker(c,x,layout),null);
 for(const l of [null,{...layout,width:NaN},{...layout,height:0},{...layout,player:{x:0,y:0,size:0}}])assert.equal(blockedActionMarker(c,f,l),null);
});

test('small, large and edge anchors are bounded and Canvas state is balanced',()=>{
 for(const size of [.25,.5,1,2,5])for(const side of ['player','opponent'])for(const edge of [false,true])for(const progress of [.01,.2,.5,.9,.99]){
  const c=cue('paralysis',side),l={width:432*size,height:240*size,player:{x:(edge?-100:115)*size,y:(edge?1000:228)*size,size:125*size},enemy:{x:(edge?2000:320)*size,y:(edge?-100:145)*size,size:110*size}},f=frame(c,progress),m=blockedActionMarker(c,f,l);assert(m);assert.ok(m.x-m.radius>=0&&m.y-m.radius>=0&&m.x+m.radius<=l.width&&m.y+m.radius<=l.height);
  const out=canvas();drawBlockedActionFeedback(out.ctx,c,f,l);assert.equal(out.depth,0);
 }
});

test('all live presentation outputs, HP, text, audio and durations remain identical',()=>{
 for(const reason of ['sleep','paralysis','freeze','flinch'])for(const reducedMotion of [false,true])for(const speed of [.5,1,4]){
  const start=snapshot(),after=snapshot([event(reason)]),audio=[[],[]],v=[oldPresentation,newPresentation].map((m,i)=>m.createBattlePresentation({drawSpecies:()=>({accessibleLabel:'생태몬'}),audio:{emit:(...args)=>audio[i].push(args)},reducedMotion,playbackSpeed:speed}));
  for(const p of v){p.consume(start,{restoring:true});p.consume(after);p.consume(after)}
  let added=false;for(let time=0;time<2500;time+=25){const contexts=[canvas(),canvas()],result=v.map((p,i)=>p.draw(contexts[i].ctx,after,time,layout));assert.deepEqual(result[1],result[0]);assert.deepEqual(audio[1],audio[0]);added||=contexts[1].draws>contexts[0].draws;contexts.forEach(c=>assert.equal(c.depth,0))}assert(added);assert.equal(v[1].busy,false);v.forEach(p=>p.stop());
  assert.deepEqual(v[1].draw(canvas().ctx,after,3000,layout),v[0].draw(canvas().ctx,after,3000,layout));
 }
});

test('restore never replays previous blocked actions or markers',()=>{
 const s=snapshot([event()]),a=changed.createSharedBattleSequences();assert.deepEqual(a.consume(s,{restoring:true}),[]);assert.deepEqual(a.consume(s),[]);
 const views=[oldPresentation,newPresentation].map(m=>m.createBattlePresentation({drawSpecies:()=>({}),audio:{emit(){}}})),contexts=[canvas(),canvas()];for(const v of views){v.consume(s,{restoring:true});assert.equal(v.busy,false)}const frames=views.map((v,i)=>v.draw(contexts[i].ctx,s,0,layout));assert.deepEqual(frames[1],frames[0]);assert.equal(contexts[1].draws,contexts[0].draws);views.forEach(v=>v.stop());
});

test('real sleeping actor wakes but loses one action without a repeated cue or changed battle state',async()=>{
 const {fixture,load,deps,BINDINGS}=await import('./forest-test-fixture.mjs');const {createCanonicalCreature}=await load('canonical-session.mjs');
 let a=await fixture(),runtime=a.world.snapshot(),checked=false;runtime.party=[createCanonicalCreature(a.world.catalog,'SPECIES_001',50)];runtime.party[0].status='sleep';runtime.party[0].statusState={sleepTurns:1,freezeTurns:0,toxicTurns:1};a.dispose();
 a=await fixture({initialRuntime:runtime,worldOptions:{...deps.worldOptions,rng:()=>0,battleDriver:b=>{const before=b.snapshot(),o=original.createSharedBattleSequences(),n=changed.createSharedBattleSequences();o.consume(before,{restoring:true});n.consume(before,{restoring:true});b.act({type:'move',moveId:before.party[0].moves[0].id});const after=b.snapshot(),old=o.consume(after),next=n.consume(after);assert.deepEqual(next,old);const blocked=next.filter(c=>c.kind==='cannot-act');assert.equal(blocked.length,1);assert.match(blocked[0].label,/잠에서 깨어났지만/);assert(blockedActionMarker(blocked[0],frame(blocked[0]),layout));assert.deepEqual(n.consume(after),[]);assert.deepEqual(b.snapshot(),after);assert.equal(after.party[0].status,null);checked=true;if(after.phase!=='ended')b.act({type:'flee'})}}});
 try{a.exterior.arrival(BINDINGS['area-entry:P_ECO_CENTER_EDGE'].foot);await a.world.interact('area-entry:P_ECO_CENTER_EDGE');a.sync();a.exterior.arrival([650,150]);for(let i=0;i<4;i++)await a.moveExterior('right');assert(checked)}finally{a.dispose()}
});
