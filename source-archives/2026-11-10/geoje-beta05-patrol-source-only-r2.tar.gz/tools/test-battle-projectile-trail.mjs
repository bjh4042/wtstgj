import {test} from 'node:test';
import assert from 'node:assert/strict';
import {moveProjectileTrail} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-projectile-trail.mjs';
import {MOVE_ANIMATION_PROFILES} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation-profiles.mjs';
import {buildMoveAnimationPayloads,moveAnimationFrame,drawMoveAnimation} from '../dist/native_world_selected_s9_boss_source_r3/source/battle-v3/move-animation.mjs';

const layout={width:432,height:240,player:{x:115,y:228,size:125},enemy:{x:320,y:145,size:110}};
const profile={target:'opponent',count:3,spread:14,arc:-21,size:18.2,phase:.5};
const frame={phase:'travel',from:{x:115,y:178},endpoint:{x:320,y:101},travel:.75,scale:1};
const close=(actual,expected,message)=>assert.ok(Math.abs(actual-expected)<1e-9,`${message??'close'}: ${actual} vs ${expected}`);
function cue(moveId='MV010',side='player',outcome='hit'){
 const event={type:'move',moveId,side,instanceId:'actor',targetId:'target',hit:outcome!=='miss'};
 const following=outcome==='immune'?[{type:'immune'}]:outcome==='miss'?[{type:'miss'}]:[{type:'damage',targetId:'target',actualDamage:12}];
 return buildMoveAnimationPayloads(event,following)[0];
}
function recordingContext(){
 const translations=[];let depth=0;
 const ctx=new Proxy({globalAlpha:1,save(){depth++},restore(){depth--},translate(x,y){translations.push({x,y})}},
  {get(target,key){if(key in target)return target[key];return (...args)=>{for(const arg of args)if(typeof arg==='number')assert.ok(Number.isFinite(arg),`nonfinite canvas ${String(key)}`)}}});
 return {ctx,translations,get depth(){return depth}};
}

test('authored spread fans trailing particles onto both sides while leaving the head unchanged',()=>{
 const samples=moveProjectileTrail(profile,frame),straight=moveProjectileTrail({...profile,spread:0},frame);
 assert.equal(samples.length,profile.count+2);assert.equal(samples.at(-1).index,0);
 assert.deepEqual(samples.at(-1),straight.at(-1));
 assert.ok(samples.some(p=>p.lateral>0));assert.ok(samples.some(p=>p.lateral<0));
 const dx=frame.endpoint.x-frame.from.x,dy=frame.endpoint.y-frame.from.y;
 samples.forEach((p,i)=>{
  const offset={x:p.x-straight[i].x,y:p.y-straight[i].y};
  close(offset.x*dx+offset.y*dy,0,'perpendicular offset');
  close(Math.hypot(offset.x,offset.y),Math.abs(p.lateral));
  assert.ok(Math.abs(p.lateral)<=profile.spread);
 });
});

test('zero spread preserves the previous trail path, density, size and opacity',()=>{
 for(const count of [0,1,2,3])for(const travel of [0,.1,.5,1]){
  const samples=moveProjectileTrail({...profile,count,spread:0},{...frame,travel});
  assert.deepEqual(samples.map(p=>p.index),Array.from({length:count+2},(_,i)=>count+1-i));
  for(const p of samples){
   const t=Math.max(0,Math.min(1,travel-p.index*.07));
   close(p.x,frame.from.x+(frame.endpoint.x-frame.from.x)*t);
   close(p.y,frame.from.y+(frame.endpoint.y-frame.from.y)*t+profile.arc*Math.sin(Math.PI*t));
   close(p.size,profile.size*(p.index===0?1:.62));
   close(p.alpha,p.index===0?1:.24/(p.index*.3+1));
  }
 }
});

test('launch and leading contact are exact, with zero spread at each endpoint',()=>{
 const launch=moveProjectileTrail(profile,{...frame,travel:0});
 for(const particle of launch){assert.equal(particle.lateral,0);assert.equal(particle.x,frame.from.x);assert.equal(particle.y,frame.from.y)}
 const head=moveProjectileTrail(profile,{...frame,travel:1}).at(-1);
 assert.equal(head.lateral,0);assert.equal(head.x,frame.endpoint.x);assert.equal(head.y,frame.endpoint.y);
});

test('perpendicular spread works in either attack direction and scales with the battle layout',()=>{
 for(const endpoints of [{from:frame.from,endpoint:frame.endpoint},{from:frame.endpoint,endpoint:frame.from}]){
  const normal=moveProjectileTrail(profile,{...frame,...endpoints,scale:1});
  const large=moveProjectileTrail(profile,{...frame,...endpoints,scale:2});
  normal.forEach((p,i)=>{close(large[i].lateral,p.lateral*2);close(large[i].size,p.size*2)});
  const dx=endpoints.endpoint.x-endpoints.from.x,dy=endpoints.endpoint.y-endpoints.from.y;
  const plain=moveProjectileTrail({...profile,spread:0},{...frame,...endpoints});
  normal.forEach((p,i)=>close((p.x-plain[i].x)*dx+(p.y-plain[i].y)*dy,0));
 }
});

test('all 118 authored profiles stay finite and deterministic without changing cue or layout data',()=>{
 assert.equal(Object.keys(MOVE_ANIMATION_PROFILES).length,118);
 for(const [id,p] of Object.entries(MOVE_ANIMATION_PROFILES))for(const side of ['player','opponent']){
  const active=cue(id,side),before=JSON.stringify({active,layout,p});
  for(const progress of [.16,.3,.45,.6]){
   const sampled=moveAnimationFrame(active,active.duration*progress,layout);
   const particles=moveProjectileTrail(p,sampled);
   assert.deepEqual(particles,moveProjectileTrail(p,sampled),`${id} deterministic`);
   if(p.target==='self'){assert.deepEqual(particles,[]);continue}
   assert.equal(particles.length,p.count+2,id);
   for(const particle of particles)for(const value of Object.values(particle))assert.ok(Number.isFinite(value),`${id} finite`);
   close(particles.at(-1).x,sampled.point.x,`${id} aimed x`);close(particles.at(-1).y,sampled.point.y,`${id} aimed y`);
  }
  assert.equal(JSON.stringify({active,layout,p}),before,id);
 }
});

test('the existing canvas renderer draws exactly the sampled trail for distinct elemental moves',()=>{
 for(const type of ['fire','water','electric','grass','ice','rock'])for(const side of ['player','opponent']){
  const id=Object.keys(MOVE_ANIMATION_PROFILES).find(id=>MOVE_ANIMATION_PROFILES[id].type===type&&MOVE_ANIMATION_PROFILES[id].target!=='self');
  const active=cue(id,side),elapsed=active.duration*.4,sampled=moveAnimationFrame(active,elapsed,layout);
  const expected=moveProjectileTrail(active.profile,sampled),recording=recordingContext();
  drawMoveAnimation(recording.ctx,active,elapsed,layout,sampled);
  assert.deepEqual(recording.translations,expected.map(({x,y})=>({x,y})),`${id} renderer integration`);
  assert.equal(recording.depth,0);
 }
});

test('hit reaction still starts after contact only, while misses and immunity never shake',()=>{
 for(const side of ['player','opponent'])for(const outcome of ['hit','miss','immune']){
  const active=cue('MV010',side,outcome),before=moveAnimationFrame(active,active.duration*.4,layout);
  const after=moveAnimationFrame(active,active.duration*.8,layout),recipient=side==='player'?'opponent':'player';
  assert.deepEqual(before.offsets[recipient],{x:0,y:0});
  if(outcome==='hit')assert.notDeepEqual(after.offsets[recipient],{x:0,y:0});
  else assert.deepEqual(after.offsets[recipient],{x:0,y:0});
  if(outcome==='miss')assert.notDeepEqual(before.endpoint,before.to);
 }
});

test('self effects, reduced motion and completed frames never request moving trail particles',()=>{
 for(const patch of [{reducedMotion:true},{done:true},{phase:'contact'},{phase:'windup'}])assert.deepEqual(moveProjectileTrail(profile,{...frame,...patch}),[]);
 assert.deepEqual(moveProjectileTrail({...profile,target:'self'},frame),[]);
 const active={...cue(),reducedMotion:true},sampled=moveAnimationFrame(active,100,layout),recording=recordingContext();
 assert.deepEqual(sampled.offsets,{player:{x:0,y:0},opponent:{x:0,y:0}});
 assert.deepEqual(moveProjectileTrail(active.profile,sampled),[]);
 drawMoveAnimation(recording.ctx,active,100,layout,sampled);
 assert.equal(recording.translations.length,1);assert.equal(recording.depth,0);
});

test('missing input is safe and malformed authored sizes/counts cannot emit unbounded or nonfinite samples',()=>{
 assert.deepEqual(moveProjectileTrail(null,frame),[]);assert.deepEqual(moveProjectileTrail(profile,null),[]);
 assert.deepEqual(moveProjectileTrail(profile,{...frame,from:{x:NaN,y:1}}),[]);
 const particles=moveProjectileTrail({...profile,count:100000,arc:NaN,spread:Infinity,size:NaN,phase:NaN},{...frame,scale:NaN,travel:NaN});
 assert.equal(particles.length,10);
 for(const particle of particles)for(const value of Object.values(particle))assert.ok(Number.isFinite(value));
});
