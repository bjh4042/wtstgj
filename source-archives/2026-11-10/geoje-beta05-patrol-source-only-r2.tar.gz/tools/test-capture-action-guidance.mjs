import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parseHTML} from 'linkedom';
import {captureActionLabel,captureActionGuidance,appendCaptureActionGuidance} from '../dist/native_world_selected_s9_boss_source_r3/source/ui/capture-action-guidance.mjs';
const battle=(extra={})=>({kind:'wild',phase:'turn',inventory:{ecology_ball:3,geoje_ball:0},...extra});
test('button explicitly names capture, exact count and tutorial refill',()=>{
 assert.equal(captureActionLabel('생태볼',3),'포획 · 생태볼 (남은 3개)');
 assert.equal(captureActionLabel('생태볼',0,{tutorialRefill:true}),'포획 · 생태볼 (남은 0개) · 연습용 보충 후 사용');
});
test('available ball explains immediate use and failure cost without promising success',()=>{
 const s=battle(),before=JSON.stringify(s),text=captureActionGuidance(s);
 assert.match(text,/1개를 바로/);assert.match(text,/실패해도/);assert.equal(JSON.stringify(s),before);
 assert.equal(captureActionGuidance(battle({inventory:{ecology_ball:0},tutorialRefillAvailable:true})),text);
});
test('no misleading prompt during trainer, forced switch, ended or unavailable inventory',()=>{
 for(const patch of [{kind:'trainer'},{phase:'forced-switch'},{phase:'ended'},{inventory:{ecology_ball:0}},{inventory:{}},{inventory:null},{inventory:[]},{inventory:{ecology_ball:-1}},{inventory:{ecology_ball:NaN}},{inventory:{ecology_ball:1.5}},{inventory:{geoje_ball:0},tutorialRefillAvailable:true}])assert.equal(captureActionGuidance(battle(patch)),null);
 assert.equal(captureActionGuidance(null),null);
});
test('DOM guidance is readable plain text and omitted when unavailable',()=>{
 const {document}=parseHTML('<html><body><div></div></body></html>'),parent=document.querySelector('div');
 const p=appendCaptureActionGuidance({parent,battle:battle()});assert.equal(parent.children.length,1);assert.equal(p.textContent,captureActionGuidance(battle()));assert.ok(p.hasAttribute('data-capture-action-guidance'));
 assert.equal(appendCaptureActionGuidance({parent,battle:battle({kind:'trainer'})}),null);assert.equal(parent.children.length,1);
});
test('entry connects display only while retaining capture action and disabling conditions',()=>{
 const s=readFileSync(new URL('../dist/native_world_selected_s9_boss_source_r3/source/world/entry.mjs',import.meta.url),'utf8');
 assert.match(s,/captureActionLabel\(world.catalog.itemContract\[id\]/);
 assert.ok(s.includes("()=>act({type:'capture',ballId:id}),blocked||battle.phase!=='turn'||captureStorageFull||(n<1&&!(id==='ecology_ball'&&battle.tutorialRefillAvailable===true))"));
 assert.ok(s.includes('if(!blocked&&!captureStorageFull)appendCaptureActionGuidance({parent:actions,battle})'));
});
