import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const root=new URL('../dist/native_world_selected_s9_boss_source_r3/source/',import.meta.url);
const {grassForegroundRuns,drawForestGrassForeground}=await import(new URL('native-connected/forest-grass-foreground.mjs',root));
const {grassSwayRows}=await import(new URL('native-connected/forest-grass-sway.mjs',root));
const {GRASS_COLOR_RUNS}=await import(new URL('native-connected/forest-grass-mask.mjs',root));
test('no occlusion on approach, fences, edge, or malformed poses',()=>{
 for(const foot of [[570,270],[700,223],[620,130],[779,150],[700,102],[700,189],[642,150],[758,150],[700,122],[700,176],null,[700.5,150]])assert.deepEqual(grassForegroundRuns(foot),[]);
});
test('only lower 14px and narrow foot width can be covered; no torso/head occlusion',()=>{
 for(const foot of [[650,130],[700,150],[750,168]])for(const r of grassForegroundRuns(foot,{elapsedMs:800})){
 assert(r.y>=foot[1]-14&&r.y<=foot[1]);assert(r.x+r.dx>=foot[0]-18&&r.x+r.dx+r.width<=foot[0]+18);assert(r.alpha>0&&r.alpha<=.88);
 assert(GRASS_COLOR_RUNS.some(([y,x,X])=>y===r.y&&r.x>=x&&r.x+r.width<=X));
 }
 assert(grassForegroundRuns([700,150]).length>0);
});
test('foreground displacement matches background sway for each original row',()=>{
 const shifts=new Map();for(const r of grassSwayRows(800))for(let y=r.y;y<r.y+r.height;y++)shifts.set(y,r.dx);
 for(const r of grassForegroundRuns([700,150],{elapsedMs:800}))assert.equal(r.dx,shifts.get(r.y)??0);
 for(const r of grassForegroundRuns([700,150],{elapsedMs:800,reducedMotion:true}))assert.equal(r.dx,0);
});
test('boundary fade is conservative and the input pose is not mutated',()=>{
 const foot=Object.freeze([700,150]);const full=grassForegroundRuns(foot),faded=grassForegroundRuns([643,150]);
 assert(faded.every(r=>r.alpha<=.11));assert(full.some(r=>r.alpha===.88));assert.deepEqual(foot,[700,150]);
});
test('original source pixels are restored with camera translation and balanced context',()=>{
 const calls=[],image={};const ctx={globalAlpha:.5,save(){calls.push('save')},restore(){calls.push('restore')},drawImage(...args){assert.equal(args[0],image);assert.equal(args[6],args[2]-50);assert(this.globalAlpha<=.44);calls.push('draw')}};
 assert(drawForestGrassForeground(ctx,image,[500,50],[700,150],{elapsedMs:800})>0);assert.equal(calls[0],'save');assert.equal(calls.at(-1),'restore');
});
test('foreground is rendered after player and before HUD; collision data is not imported',()=>{
 const scene=fs.readFileSync(new URL('native-connected/forest-scene.mjs',root),'utf8');
 assert(scene.indexOf('drawPlayer(ctx')<scene.indexOf('renderer.forest.drawForeground'));
 assert(scene.indexOf('renderer.forest.drawForeground')<scene.indexOf("ctx.textAlign = 'left'"));
 const module=fs.readFileSync(new URL('native-connected/forest-grass-foreground.mjs',root),'utf8');
 assert(!module.includes('forest-plan'));assert(!module.includes('Math.random'));assert(!module.includes('localStorage'));
});
