import config from './vite.beta05-interior-dev.config.mjs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const project=dirname(fileURLToPath(import.meta.url));
export default {...config,build:{...config.build,outDir:resolve(project,'build-beta05-forest-growth-merged-r1'),emptyOutDir:false,copyPublicDir:false,rollupOptions:{input:resolve(config.root,'beta05-forest-growth-merged-candidate.html')}}};
